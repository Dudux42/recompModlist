# Gen1 Battle Art Replacer

Current build: **0.1.0-alpha.2**

## Alpha 2 Dramatic Shape compatibility

- Removes the incorrect manifest conflict with `DRAMATIC_SHAPE` 1.8.0.
- Lets Dramatic Shape consume the normal engine-resolved Gen 5 enemy fronts.
- Adapts Dramatic Shape's `FRONT SPRITES` player view through its exported
  `OverworldBattle.wantsFront()` contract, including the first staged frame.
- Leaves Dramatic Shape's world placement, camera, battle staging, sprite
  metrics, backs, Stadium models, and rendering pipeline untouched.

This first narrow release replaces the front battle sprites of all 151 Gen 1
Pokemon with static neutral frames composed from Pokemon Black/White-era Gen 5
art. Both normal and shiny variants are included. Shiny choice is per Pokemon
instance and supports `mon.shiny`, the native Gen 2 DV rule, and the public
Gen1 Shiny System resolver when it is installed.

## Option

- `POKEMON ART: GEN 5` uses the supplied Gen 5 front art.
- `POKEMON ART: ROM` bypasses every replacement.

## Scope and fallbacks

- Front Pokemon battle art: Gen 5 static image, then ROM if unavailable.
- Back Pokemon art: ROM.
- Opponent trainers: ROM.
- Player battle-intro/back art: ROM.
- Party/Summary portraits may consume the exported live 2D resolver.

The source files supplied for this build are 1024x512 articulated component
sheets, not animation strips. This release therefore uses validated neutral
composed frames and does not claim animation support. Drawing a component
sheet as one image would be incorrect.

## Compatibility

This build remains incompatible with `BATTLE_ART_VOXEL_FORK`, which owns the
same battle-art fields after the public resolver. It is compatible with the
separate `DRAMATIC_SHAPE` 1.8.0 release through the adapter above. The mod does
not alter world geometry, camera, collision, battle staging, HUD layout, or
shiny odds.

## Asset provenance

- Species scope: National Dex 001-151.
- Art generation: Pokemon Black/White 2 (Generation 5 presentation).
- Supplied component sheets: user-extracted from Pokemon White 2 with
  AnimaEngine v1.0.0.
- Normal neutral frames: derived from the validated local Gen 5 composed
  atlases in the user's Battle Art Voxel Fork study copy.
- Shiny colors: coordinate-derived from each supplied normal/shiny White 2
  component-sheet pair and applied to the matching neutral frame.

No ROM is included. Pokemon artwork is not covered by an open-source license;
this package is intended for the user's private mod setup. Do not redistribute
the artwork without confirming the applicable rights.

## Packaging

The release ZIP is flat: the manifest, Lua entry point, README, and all PNGs
are at archive root. Import it manually through the Gen1 Recomp launcher. The
build is never installed automatically.
