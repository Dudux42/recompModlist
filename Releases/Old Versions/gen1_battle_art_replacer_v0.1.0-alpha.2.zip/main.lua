-- Gen1 Battle Art Replacer v0.1.0-alpha.2
-- Initial narrow release: Gen 5 static front art for the 151 Gen 1 Pokemon.

local VERSION = "0.1.0-alpha.2"

return function(mod)
  local Assets = require("src.render.Assets")
  local Stats = require("src.pokemon.Stats")

  mod.options:define({
    {
      key = "pokemon_art",
      type = "choice",
      label = "POKEMON ART",
      default = "gen5",
      choices = { { "GEN 5", "gen5" }, { "ROM", "rom" } },
      help = "Use Gen 5 front sprites in battle, or retain the ROM art.",
    },
  })

  local imageCache = {}

  local function invalidate()
    imageCache = {}
  end

  local function enabled()
    return mod.options:get("pokemon_art") ~= "rom"
  end

  local function shinyArtEnabled(mon)
    if type(mon) ~= "table" then return false end
    local shinyMod = mod.find and mod:find("gen1_shiny_system")
    local resolver = shinyMod and shinyMod.exports
      and shinyMod.exports.shouldUseShinyArt
    if type(resolver) == "function" then
      local ok, value = pcall(resolver, mon)
      if ok then return value and true or false end
    end
    if mon.shiny == true then return true end
    return Stats.isShiny and Stats.isShiny(mon.dvs) and true or false
  end

  local function dexFor(data, species)
    local def = data and data.pokemon and data.pokemon[species]
    local dex = def and tonumber(def.dex)
    if dex and dex >= 1 and dex <= 151 then return math.floor(dex) end
    return nil
  end

  local function assetPath(data, mon, side)
    if not enabled() or side ~= "front" or type(mon) ~= "table" then return nil end
    local dex = dexFor(data, mon.species)
    if not dex then return nil end
    local suffix = shinyArtEnabled(mon) and "_shiny" or ""
    return mod.assets:path(string.format(
      "pokemon_static_gen5_front_%03d%s.png", dex, suffix))
  end

  -- Dramatic Shape normally consumes the battler images resolved by the
  -- engine. Its optional FRONT SPRITES player view is the one exception: the
  -- engine asks for a back, then Dramatic Shape swaps that answer to the ROM
  -- front path. Query its public exported module so our later wrapper can
  -- provide the selected front art for that exact mode without touching its
  -- camera, world placement, metrics, Stadium models, or normal back view.
  local function dramaticShapeWantsFront()
    if not mod.find then return false end
    local okFind, handle = pcall(mod.find, mod, "DRAMATIC_SHAPE")
    if not (okFind and handle) then return false end
    local exports = handle.exports or handle
    local lib = exports and exports.lib
    if not (lib and type(lib.require) == "function") then return false end
    local okModule, overworldBattle = pcall(lib.require, "OverworldBattle")
    if not (okModule and overworldBattle
        and type(overworldBattle.wantsFront) == "function") then return false end
    local okFront, wantsFront = pcall(overworldBattle.wantsFront)
    return okFront and wantsFront and true or false
  end

  local function resolvePokemonImage(game, mon, side, purpose)
    local data = game and game.data or game
    local path = assetPath(data, mon, side or "front")
    if not path then return nil end
    local cached = imageCache[path]
    if cached == false then return nil end
    if cached then return cached end
    local ok, image = pcall(Assets.image, path)
    if not (ok and image) then
      imageCache[path] = false
      return nil
    end
    if image.setFilter then image:setFilter("nearest", "nearest") end
    if image.setWrap then image:setWrap("clamp", "clamp") end
    imageCache[path] = image
    return image
  end

  -- The engine asks this resolver whenever it constructs a Pokemon picture.
  -- This release deliberately limits replacement to front sprites in battle;
  -- every unsupported side/category preserves the prior provider or ROM path.
  mod.hooks:wrap("pokemon.sprite", function(next, path, ctx)
    local original, originalTrueColor = next(path, ctx)
    if not (ctx and ctx.kind == "battle" and enabled()) then
      return original, originalTrueColor
    end
    local side = ctx.side
    if side == "back" and dramaticShapeWantsFront() then side = "front" end
    if side ~= "front" then return original, originalTrueColor end
    local mon = ctx.mon
    if type(mon) ~= "table" then mon = { species = ctx.species } end
    local replacement = assetPath(ctx.data, mon, side)
    if replacement then return replacement, true end
    return original, originalTrueColor
  end)

  -- Synchronize the first staged frame as well. This covers a loader whose
  -- hook chain was constructed before this mod registered; later switch and
  -- Transform sprite resolutions continue through the wrapper above.
  mod.events:on("battle.started", function(payload)
    if not (enabled() and dramaticShapeWantsFront()) then return end
    local battle = payload and payload.battle
    local game = battle and battle.game or payload and payload.game
    local data = game and game.data
    if not (battle and data) then return end
    for _, battler in ipairs({ battle.enemy, battle.player }) do
      local mon = battler and battler.mon
      local image = mon and resolvePokemonImage(game, mon, "front", "battle")
      if image then battler.sprite = image end
    end
  end)

  if Assets.register then Assets.register(invalidate) end
  mod.events:on("mod.options_changed", function(payload)
    if payload and payload.mod == mod.id then invalidate() end
  end)

  mod.exports.version = VERSION
  mod.exports.resolvePokemonImage = resolvePokemonImage
  mod.exports.resolvePokemonPath = assetPath
  mod.exports.resolveTrainerImage = function() return nil end
  mod.exports.resolvePlayerImage = function() return nil end
  mod.exports.mode = function() return enabled() and "static" or "rom" end
  mod.exports.isAnimated = function() return false end
  mod.exports.invalidate = invalidate

  mod.log:info("Gen1 Battle Art Replacer %s ready (Gen 5 fronts)", VERSION)
end
