# Changelog

## 0.1.0-alpha.3 - 2026-08-11

- Added a consumer-side Dramatic Shape 1.8.0 billboard adapter inside this mod; no Dramatic Shape files are edited.
- Scoped interception strictly to `gen1_character_sprite_replacer` Character Appearance API v1 definitions.
- Added authored frame-width/height UV slicing, 16x32 and 32x32 billboard geometry, bottom/center anchors, and shared solid/shadow/ghost meshes.
- Preserved original Dramatic Shape behavior for ROM sprites, NPCs, followers, other mods, invalid descriptors, and missing assets.
- Retained automatic ROM overworld fallback if the adapter cannot be installed.

## 0.1.0-alpha.2 - 2026-08-11

- Fixed corrupted/split overworld rendering when Dramatic Shape voxel mode sampled enhanced FRLG sheets with hardcoded 16x16 UVs.
- Added an active-pipeline compatibility guard: unsupported Dramatic Shape voxel presentation now uses each role's exact ROM renderer instead of emitting partial FRLG frame bands.
- Kept Red/Leaf front/back resolution active for Trainer Card, Hall of Fame, intro, and battle while the overworld safely falls back.
- Preserved enhanced FRLG dimensions in the native 2D overworld path.

## 0.1.0-alpha.1 - 2026-08-11

- Added selectable ROM, FRLG Red (male), and FRLG Leaf (female) appearances.
- Added exact, reproducibly extracted Red/Leaf walk, bike, Surf, front, back, and main-menu assets.
- Added native 2D enhanced-size player rendering with a fixed 16x16 logical footprint and bottom-center anchoring.
- Added live player front/back resolution for intro, Trainer Card, Hall of Fame, and battle.
- Added Character Appearance API v1 and explicit local ROM fallbacks.
- Documented fishing, Surfing Pikachu, Fly, NPC, and trainer exclusions for this first batch.
- Added owner-agent requests for Widescreen main-menu consumption and Dramatic Shape enhanced billboard support.
