local M = {}

local MOD_ID = "gen1_quality_of_life"
local SELECT_PATCH = "__gen1QolSelectDispatcherV1"
local RODS = { "SUPER_ROD", "GOOD_ROD", "OLD_ROD" }
local REPELS = { "REPEL", "SUPER_REPEL", "MAX_REPEL" }
local DIG_TILESETS = {
  FOREST = true, CEMETERY = true, CAVERN = true,
  FACILITY = true, INTERIOR = true,
}

local function firstOwned(game, ids)
  local inventory = game and game.save and game.save.inventory or {}
  for _, id in ipairs(ids) do
    if (tonumber(inventory[id]) or 0) > 0 then return id end
  end
end

local function itemName(game, id)
  local def = game and game.data and game.data.items and game.data.items[id]
  return def and def.name or tostring(id):gsub("_", " ")
end

function M.install(mod, options)
  local FieldDefaults = require("src.world.FieldDefaults")
  local Map = require("src.world.Map")
  local Strings = require("src.core.Strings")

  local function gameNow() return mod.world and mod.world.game end

  local function useRepel(game, id)
    local ItemEffects = require("src.inventory.ItemEffects")
    local Bag = require("src.inventory.Bag")
    local TextBox = require("src.render.TextBox")
    local result, messages = ItemEffects.use(game.data, game.save, id)
    if result ~= "consumed" then return false end
    Bag.remove(game.save, id, 1)
    if messages and #messages > 0 then
      game.stack:push(TextBox.new(game, table.concat(messages, "\f")))
    end
    return true
  end

  local function bottomMenu(game, items)
    local width = 10
    for _, item in ipairs(items) do width = math.max(width, #item.label + 4) end
    local height = #items * 2 + 2
    game.stack:push(mod.ui.Menu.new(game, items, {
      tx = 20 - width, ty = 18 - height, tw = width, th = height,
    }))
  end

  local function useCut(ow, allowGrass)
    if ow:useCutFieldMove() ~= "ok" then return false end
    local fx, fy = ow.player:facingCell()
    if not allowGrass and ow.map:isGrassCell(fx, fy) then return false end
    return ow:tryCut(fx, fy) == true
  end

  local function useSurf(ow)
    local fx, fy = ow.player:facingCell()
    ow:trySurf(fx, fy)
  end

  local function useWater(ow, mode)
    if not ow:facingIsShoreOrWater() or (ow.player and ow.player.surfing) then
      return false
    end
    local game = gameNow()
    local rod = firstOwned(game, RODS)
    local canSurf = ow:useSurfFieldMove() == "ok"
    if mode == "fish_only" then
      if not rod then return false end
      ow:goFishing(rod)
      return true
    elseif mode == "surf_only" then
      if not canSurf then return false end
      useSurf(ow)
      return true
    end
    if not rod and not canSurf then return false end
    if rod and canSurf then
      local fish = { label = "USE " .. itemName(game, rod),
        onSelect = function() ow:goFishing(rod) end }
      local surf = { label = "SURF", onSelect = function() useSurf(ow) end }
      if mode == "surf_first" then
        bottomMenu(game, { surf, fish, { label = "CANCEL" } })
      else
        bottomMenu(game, { fish, surf, { label = "CANCEL" } })
      end
    elseif rod then
      ow:goFishing(rod)
    else
      useSurf(ow)
    end
    return true
  end

  local function useStrength(ow, target)
    if not target or not Map.isPushable(target.def) or ow.strengthActive then
      return false
    end
    local mon = ow:partyKnows("STRENGTH")
    if not mon then return false end
    local game = gameNow()
    local TextBox = require("src.render.TextBox")
    if getmetatable(game.stack:top()) == TextBox then
      game.stack:pop()
      target.frozen = false
    end
    local def = game.data.pokemon[mon.species]
    local name = mon.nickname or (def and def.name) or mon.species
    ow.strengthActive = true
    local used = (game.data.text._UsedStrengthText
      or "{RAM:wNameBuffer} used\nSTRENGTH."):gsub("{RAM:wNameBuffer}", name)
    local canMove = (game.data.text._CanMoveBouldersText
      or "{RAM:wNameBuffer} can\nmove boulders."):gsub("{RAM:wNameBuffer}", name)
    game.stack:push(TextBox.new(game, used, function()
      game.stack:push(TextBox.new(game, canMove))
    end, { auto = { sound = function()
      return require("src.core.Sound").playCry(game.data, mon.species)
    end } }))
    return true
  end

  local function useFlash(ow, game)
    local TextBox = require("src.render.TextBox")
    local Transition = require("src.render.Transition")
    game.save.flashLit = true
    game.stack:push(TextBox.new(game,
      game.data.text._FlashLightsAreaText
        or Strings("A blinding FLASH\nlights the area!"), function()
        game.stack:push(Transition.whiteFlash(game, nil, function()
          ow:setDark(false)
        end))
      end))
  end

  local function openSelect(ow)
    local game = gameNow()
    if not game or not ow.map then return false end
    local outside = Map.isOutside(ow.map.def,
      FieldDefaults.field(game.data, "outsideTilesets"))
    local items = {}
    if outside and ow:partyKnows("FLY") then
      items[#items + 1] = { label = "FLY", onSelect = function()
        mod.ui.push(game, "TownMap", { fly = true, onFly = function(mapId)
          ow:flyTo(mapId)
        end })
      end }
    end
    if outside and game.save.lastHeal and ow:partyKnows("TELEPORT") then
      items[#items + 1] = { label = "TELEPORT",
        onSelect = function() ow:beginTeleportOut() end }
    end
    if ow.dark and ow:partyKnows("FLASH") then
      items[#items + 1] = { label = "FLASH",
        onSelect = function() useFlash(ow, game) end }
    end
    if game.save.lastHeal and DIG_TILESETS[ow.map.def.tileset]
        and ow.map.id ~= "AGATHAS_ROOM" and ow:partyKnows("DIG") then
      items[#items + 1] = { label = "DIG",
        onSelect = function() ow:beginTeleportOut() end }
    end
    local repel = firstOwned(game, REPELS)
    if repel then
      items[#items + 1] = { label = itemName(game, repel),
        onSelect = function() useRepel(game, repel) end }
    end
    if #items == 0 then return false end
    items[#items + 1] = { label = "CANCEL" }
    bottomMenu(game, items)
    return true
  end

  mod.events:on("world.interacted", function(event)
    local game = gameNow()
    if not game or not event or not options.value(game, "easyInteractions") then return end
    local ow = mod.world:overworld()
    if not ow or not game.stack then return end
    if event.kind == "npc" then
      useStrength(ow, event.target)
    elseif event.kind == "none" then
      if game.stack:top() ~= ow then return end
      if not useWater(ow, options.value(game, "waterAction")) then
        useCut(ow, options.value(game, "cutGrass"))
      end
    end
  end, -100)

  local OverworldController = require("src.world.OverworldController")
  local dispatcher = rawget(OverworldController, SELECT_PATCH)
  if not dispatcher then
    dispatcher = { original = OverworldController.handleInput }
    OverworldController[SELECT_PATCH] = dispatcher
    OverworldController.handleInput = function(ow, ...)
      local game = require("src.core.Game")
      local exports = game.mods and game.mods.exports and game.mods.exports[MOD_ID]
      local handler = exports and exports._handleSelect
      if handler and handler(ow) then return end
      return dispatcher.original(ow, ...)
    end
  end

  mod.exports._handleSelect = function(ow)
    local game = gameNow()
    if not game or not options.value(game, "easyInteractions")
        or not game.stack or game.stack:top() ~= ow
        or not ow.player or ow.player.moving
        or not game.input:wasPressed("select") then return false end
    return openSelect(ow)
  end

  local pendingWearOff = setmetatable({}, { __mode = "k" })
  mod.events:on("world.stepped", function()
    local game = gameNow()
    if not game then return end
    pendingWearOff[game] = options.value(game, "easyInteractions")
      and options.value(game, "repelPrompt")
      and (tonumber(game.save.repelSteps) or 0) == 1 or nil
  end, -100)

  mod.events:on("screen.pushed", function(event)
    local game = gameNow()
    if not game or not pendingWearOff[game]
        or (tonumber(game.save.repelSteps) or 0) ~= 0 then return end
    local TextBox = require("src.render.TextBox")
    local box = event and event.state
    if getmetatable(box) ~= TextBox then return end
    pendingWearOff[game] = nil
    local oldDone = box.onDone
    box.onDone = function(...)
      if oldDone then oldDone(...) end
      local repel = firstOwned(game, REPELS)
      if not repel then return end
      game.stack:push(TextBox.new(game,
        "Use another\n" .. itemName(game, repel) .. "?", nil,
        { choice = function(yes) if yes then useRepel(game, repel) end end }))
    end
  end, -100)

  mod.exports.strongestRod = function(game) return firstOwned(game, RODS) end
  mod.exports.weakestRepel = function(game) return firstOwned(game, REPELS) end
end

return M
