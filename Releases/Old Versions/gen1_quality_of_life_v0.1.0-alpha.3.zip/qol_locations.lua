local M = {}

local SUPPRESSED = { ROCK_TUNNEL_POKECENTER = true }

local function locationName(game, mapId, map)
  local townMap = game and game.data and game.data.field and game.data.field.townMap
  local locations = townMap and (townMap.locations or townMap)
  local entry = type(locations) == "table" and locations[mapId]
  local name = type(entry) == "table" and (entry.name or entry.label)
  local def = map and map.def or (game and game.data and game.data.maps
    and game.data.maps[mapId])
  if not name and def and type(def.label) == "string" then
    name = def.label:gsub("(%l)(%u)", "%1 %2")
  end
  name = name or tostring(mapId or "UNKNOWN"):gsub("_", " ")
  return name:upper()
end

function M.install(mod, options)
  local active = setmetatable({}, { __mode = "k" })
  local lastName = setmetatable({}, { __mode = "k" })

  mod.events:on("map.entered", function(event)
    local game = mod.world and mod.world.game
    if not game or not event or not event.mapId then return end
    if SUPPRESSED[event.mapId] then active[game] = nil return end
    local duration = options.value(game, "locationBanners")
    if type(duration) ~= "number" or duration <= 0 then return end
    local name = locationName(game, event.mapId, event.map)
    if lastName[game] == name then return end
    lastName[game] = name
    active[game] = { name = name, expires = love.timer.getTime() + duration }
  end, 100)

  mod.events:on("save.loaded", function()
    local game = mod.world and mod.world.game
    if game then active[game], lastName[game] = nil, nil end
  end, 100)

  mod.hooks:wrap("render.hud", function(next, game, viewport)
    next(game, viewport)
    local state = active[game]
    if not state then return end
    if options.value(game, "locationBanners") <= 0
        or love.timer.getTime() >= state.expires then
      active[game] = nil
      return
    end
    local ow = mod.world and mod.world:overworld()
    if not ow or not game.stack or game.stack:top() ~= ow then return end
    local renderer = game.renderer
    local uiw, uih = 160, 144
    if renderer and renderer.uiSize then uiw, uih = renderer:uiSize() end
    local sx = viewport and viewport.gameWidth and viewport.gameWidth / uiw or 1
    local sy = viewport and viewport.gameHeight and viewport.gameHeight / uih or sx
    local x = viewport and viewport.gameX or 0
    local y = viewport and viewport.gameY or 0
    local g = love.graphics
    local ok = pcall(g.push, "all")
    if not ok then g.push() end
    g.translate(x, y)
    g.scale(sx, sy)
    local tileY = math.max(0, math.floor((uih - 32) / 8))
    local tileW = math.max(20, math.floor(uiw / 8))
    mod.ui.Font.drawBox(0, tileY, tileW, 4)
    g.setColor(0, 0, 0, 1)
    local width = mod.ui.Font.width(state.name)
    mod.ui.Font.draw(state.name, math.max(8, math.floor((uiw - width) / 2)),
      tileY * 8 + 16)
    g.pop()
  end, 100)

  mod.exports.locationName = locationName
end

return M
