# Changelog

## 0.1.0-alpha.2

- Replaced the inherited seven-pocket plan with six original pockets.
- Removed Favorites, pins, search, filters, preference persistence, and every
  automatic-sorting path.
- Added explicit START sorting: Alphabetical, Type, and Quantity.
- Added persistent vanilla-style SELECT swapping through `Bag.order`.
- Locked TM/HM to HMs-first numerical order followed by numerical TMs.
- Added plain-language right-panel item, machine, and battle availability data.
- Built and audited 70 individual icons plus shared TM/HM icons.
- Retained safe large finite stacks and engine-owned item actions.
- Migrated to Bag Provider API v2 for visible, validated modal focus and
  screen-aware input routing.

## 0.1.0-alpha.1

- Added the initial provider and inventory-semantic foundation.
