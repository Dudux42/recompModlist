# Changelog

## 0.1.0-alpha.1 — 2026-08-11

- Implemented the read-only semantic provider, research models, navigation,
  privacy policy, live cry dispatch, and native Habitat fallback.
- Added Lua 5.1 contract tests.
- Integrated with Widescreen Pokedex Provider API v2 from alpha 14.1.
- Verified bounded long-entry focus and scrolling through Widescreen's
  controller and pointer-owned input paths.
