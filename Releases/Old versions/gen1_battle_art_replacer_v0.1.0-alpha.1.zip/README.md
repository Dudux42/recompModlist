# Gen1 Battle Art Replacer

Current build: **0.1.0-alpha.1**

This first narrow release replaces the front battle sprites of all 151 Gen 1
Pokemon with static neutral frames composed from Pokemon Black/White-era Gen 5
art. Both normal and shiny variants are included. Shiny choice is per Pokemon
instance and supports `mon.shiny`, the native Gen 2 DV rule, and the public
Gen1 Shiny System resolver when it is installed.

## Option

- `POKEMON ART: GEN 5` uses the supplied Gen 5 front art.
- `POKEMON ART: ROM` bypasses every replacement.

## Scope and fallbacks

- Front Pokemon battle art: Gen 5 static image, then ROM if unavailable.
- Back Pokemon art: ROM.
- Opponent trainers: ROM.
- Player battle-intro/back art: ROM.
- Party/Summary portraits may consume the exported live 2D resolver.

The source files supplied for this build are 1024x512 articulated component
sheets, not animation strips. This release therefore uses validated neutral
composed frames and does not claim animation support. Drawing a component
sheet as one image would be incorrect.

## Compatibility

This build declares a temporary conflict with `BATTLE_ART_VOXEL_FORK` and
`DRAMATIC_SHAPE`. Those packages currently own the same battler sprite fields
after the public `pokemon.sprite` resolver runs, so coexistence cannot be
claimed safely without a provider/adapter contract. The mod does not alter
world geometry, camera, collision, battle staging, HUD layout, or shiny odds.

## Asset provenance

- Species scope: National Dex 001-151.
- Art generation: Pokemon Black/White 2 (Generation 5 presentation).
- Supplied component sheets: user-extracted from Pokemon White 2 with
  AnimaEngine v1.0.0.
- Normal neutral frames: derived from the validated local Gen 5 composed
  atlases in the user's Battle Art Voxel Fork study copy.
- Shiny colors: coordinate-derived from each supplied normal/shiny White 2
  component-sheet pair and applied to the matching neutral frame.

No ROM is included. Pokemon artwork is not covered by an open-source license;
this package is intended for the user's private mod setup. Do not redistribute
the artwork without confirming the applicable rights.

## Packaging

The release ZIP is flat: the manifest, Lua entry point, README, and all PNGs
are at archive root. Import it manually through the Gen1 Recomp launcher. The
build is never installed automatically.
