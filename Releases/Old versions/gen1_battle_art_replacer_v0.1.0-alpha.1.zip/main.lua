-- Gen1 Battle Art Replacer v0.1.0-alpha.1
-- Initial narrow release: Gen 5 static front art for the 151 Gen 1 Pokemon.

local VERSION = "0.1.0-alpha.1"

return function(mod)
  local Assets = require("src.render.Assets")
  local Stats = require("src.pokemon.Stats")

  mod.options:define({
    {
      key = "pokemon_art",
      type = "choice",
      label = "POKEMON ART",
      default = "gen5",
      choices = { { "GEN 5", "gen5" }, { "ROM", "rom" } },
      help = "Use Gen 5 front sprites in battle, or retain the ROM art.",
    },
  })

  local imageCache = {}

  local function invalidate()
    imageCache = {}
  end

  local function enabled()
    return mod.options:get("pokemon_art") ~= "rom"
  end

  local function shinyArtEnabled(mon)
    if type(mon) ~= "table" then return false end
    local shinyMod = mod.find and mod:find("gen1_shiny_system")
    local resolver = shinyMod and shinyMod.exports
      and shinyMod.exports.shouldUseShinyArt
    if type(resolver) == "function" then
      local ok, value = pcall(resolver, mon)
      if ok then return value and true or false end
    end
    if mon.shiny == true then return true end
    return Stats.isShiny and Stats.isShiny(mon.dvs) and true or false
  end

  local function dexFor(data, species)
    local def = data and data.pokemon and data.pokemon[species]
    local dex = def and tonumber(def.dex)
    if dex and dex >= 1 and dex <= 151 then return math.floor(dex) end
    return nil
  end

  local function assetPath(data, mon, side)
    if not enabled() or side ~= "front" or type(mon) ~= "table" then return nil end
    local dex = dexFor(data, mon.species)
    if not dex then return nil end
    local suffix = shinyArtEnabled(mon) and "_shiny" or ""
    return mod.assets:path(string.format(
      "pokemon_static_gen5_front_%03d%s.png", dex, suffix))
  end

  local function resolvePokemonImage(game, mon, side, purpose)
    local data = game and game.data or game
    local path = assetPath(data, mon, side or "front")
    if not path then return nil end
    local cached = imageCache[path]
    if cached == false then return nil end
    if cached then return cached end
    local ok, image = pcall(Assets.image, path)
    if not (ok and image) then
      imageCache[path] = false
      return nil
    end
    if image.setFilter then image:setFilter("nearest", "nearest") end
    if image.setWrap then image:setWrap("clamp", "clamp") end
    imageCache[path] = image
    return image
  end

  -- The engine asks this resolver whenever it constructs a Pokemon picture.
  -- This release deliberately limits replacement to front sprites in battle;
  -- every unsupported side/category preserves the prior provider or ROM path.
  mod.hooks:wrap("pokemon.sprite", function(next, path, ctx)
    local original, originalTrueColor = next(path, ctx)
    if not (ctx and ctx.kind == "battle" and ctx.side == "front" and enabled()) then
      return original, originalTrueColor
    end
    local mon = ctx.mon
    if type(mon) ~= "table" then mon = { species = ctx.species } end
    local replacement = assetPath(ctx.data, mon, "front")
    if replacement then return replacement, true end
    return original, originalTrueColor
  end)

  if Assets.register then Assets.register(invalidate) end
  mod.events:on("mod.options_changed", function(payload)
    if payload and payload.mod == mod.id then invalidate() end
  end)

  mod.exports.version = VERSION
  mod.exports.resolvePokemonImage = resolvePokemonImage
  mod.exports.resolvePokemonPath = assetPath
  mod.exports.resolveTrainerImage = function() return nil end
  mod.exports.resolvePlayerImage = function() return nil end
  mod.exports.mode = function() return enabled() and "static" or "rom" end
  mod.exports.isAnimated = function() return false end
  mod.exports.invalidate = invalidate

  mod.log:info("Gen1 Battle Art Replacer %s ready (Gen 5 fronts)", VERSION)
end
