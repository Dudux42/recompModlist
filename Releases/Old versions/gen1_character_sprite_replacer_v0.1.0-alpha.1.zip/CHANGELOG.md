# Changelog

## 0.1.0-alpha.1 - 2026-08-11

- Added selectable ROM, FRLG Red (male), and FRLG Leaf (female) appearances.
- Added exact, reproducibly extracted Red/Leaf walk, bike, Surf, front, back, and main-menu assets.
- Added native 2D enhanced-size player rendering with a fixed 16x16 logical footprint and bottom-center anchoring.
- Added live player front/back resolution for intro, Trainer Card, Hall of Fame, and battle.
- Added Character Appearance API v1 and explicit local ROM fallbacks.
- Documented fishing, Surfing Pikachu, Fly, NPC, and trainer exclusions for this first batch.
- Added owner-agent requests for Widescreen main-menu consumption and Dramatic Shape enhanced billboard support.
