-- Gen1 Character Sprite Replacer v0.1.0-alpha.2
-- First player-only batch: selectable FRLG Red/Leaf appearance.

local VERSION = "0.1.0-alpha.2"

return function(mod)
  local Assets = require("src.render.Assets")
  local Game = require("src.core.Game")
  local PaletteFX = require("src.render.PaletteFX")
  local Pipelines = require("src.render.Pipelines")

  local compile = loadstring or load
  local function loadModule(path)
    local source, readError = mod:read(path)
    if not source then error("cannot read " .. path .. ": " .. tostring(readError), 0) end
    local chunk, compileError = compile(source, "@" .. tostring(mod.path or mod.id) .. "/" .. path)
    if not chunk then error("cannot compile " .. path .. ": " .. tostring(compileError), 0) end
    return chunk()
  end

  local PACKS = loadModule("character_packs.lua")
  local ROLE_MAP = loadModule("player_role_map.lua")
  local STAND = { down = 0, up = 1, left = 2, right = 2 }
  local WALK = { down = 3, up = 4, left = 5, right = 5 }

  mod.options:define({
    {
      key = "character_pack",
      type = "choice",
      label = "CHARACTER SPRITE",
      default = "frlg_red",
      choices = {
        { "FRLG RED (MALE)", "frlg_red" },
        { "FRLG LEAF (FEMALE)", "frlg_leaf" },
        { "ROM", "rom" },
      },
      help = "Choose Red, Leaf, or the original ROM player appearance. This is visual only and does not alter save gender or identity.",
    },
  })

  local imageCache = {}
  local quadCache = {}
  local warnedDramaticShape = false
  local dramaticShapeHandle

  local function findDramaticShape()
    if dramaticShapeHandle then return dramaticShapeHandle end
    if not mod.find then return nil end
    local ok, handle = pcall(mod.find, mod, "DRAMATIC_SHAPE")
    if ok and handle then dramaticShapeHandle = handle end
    return dramaticShapeHandle
  end

  local function dramaticShapeSupportsEnhancedCharacters()
    local handle = findDramaticShape()
    local exports = handle and (handle.exports or handle)
    local version = exports and (exports.characterAppearanceBillboardApiVersion
      or exports.enhancedCharacterSpriteApiVersion)
    return tonumber(version) and tonumber(version) >= 1 or false
  end

  local function incompatibleVoxelActive()
    if not findDramaticShape() or dramaticShapeSupportsEnhancedCharacters() then
      return false
    end
    local ok, level = pcall(Pipelines.level, "voxel")
    return ok and (tonumber(level) or 0) > 0
  end

  local function activePackId()
    local id = mod.options:get("character_pack")
    return PACKS[id] and id or "rom"
  end

  local function activePack()
    return PACKS[activePackId()] or PACKS.rom
  end

  local function descriptor(role)
    local pack = activePack()
    local source = pack and pack.player and pack.player[role]
    if not source then return nil end
    return {
      owner = mod.id,
      apiVersion = 1,
      packId = pack.id,
      subjectId = "PLAYER",
      role = role,
      imagePath = mod.assets:path(source.path),
      trueColor = true,
      frameW = source.frameW,
      frameH = source.frameH,
      frameCount = source.frames,
      layout = source.frames == 6 and "gen1-six-pose" or "static",
      anchorX = source.anchorX,
      anchorY = source.anchorY,
      logicalFootprintW = 16,
      logicalFootprintH = 16,
      fallback = false,
      genderPresentation = pack.genderPresentation,
    }
  end

  local function imageFor(desc)
    if not desc then return nil end
    local path = desc.imagePath
    if imageCache[path] == nil then
      local ok, image = pcall(Assets.image, path)
      if ok and image then
        image:setFilter("nearest", "nearest")
        if image.setWrap then image:setWrap("clamp", "clamp") end
        imageCache[path] = image
      else
        imageCache[path] = false
        mod.log:warn("Character Sprite Replacer: missing player asset %s; using ROM fallback", tostring(path))
      end
    end
    return imageCache[path] or nil
  end

  local function invalidate()
    imageCache = {}
    quadCache = {}
  end
  if Assets.register then Assets.register(invalidate) end

  local RoleSprite = {}
  RoleSprite.__index = function(self, key)
    -- Dramatic Shape reads sprite.def BEFORE resolveImage(). Make the public
    -- definition itself dynamic so its first voxel frame sees the matching
    -- ROM definition and ROM texture together, never an enhanced definition
    -- paired with a fallback texture.
    if key == "def" then
      if incompatibleVoxelActive() then
        return self.rom and self.rom.def or rawget(self, "_def")
      end
      return rawget(self, "_def") or (self.rom and self.rom.def)
    end
    return RoleSprite[key]
  end

  function RoleSprite.new(role, rom)
    return setmetatable({ role = role, rom = rom, _def = rom and rom.def }, RoleSprite)
  end

  function RoleSprite:selection()
    -- Dramatic Shape 1.8.0 slices and sizes every billboard as 16x16. Giving
    -- it an enhanced texture produces detached frame fragments (most visibly
    -- the player's cap below the Surf mount). Until its owner publishes the
    -- requested descriptor contract, keep its voxel path on the exact ROM
    -- renderer. The native 2D path continues using authored FRLG dimensions.
    if incompatibleVoxelActive() then
      self._def = self.rom and self.rom.def or self._def
      return nil, nil
    end
    local desc = descriptor(self.role)
    local image = imageFor(desc)
    if not (desc and image) then
      self._def = self.rom and self.rom.def or self._def
      return nil, nil
    end
    self._def = {
      id = "GEN1_CHARACTER_PLAYER_" .. self.role:upper(),
      image = desc.imagePath,
      frames = desc.frameCount,
      walker = true,
      trueColor = true,
      frameWidth = desc.frameW,
      frameHeight = desc.frameH,
      frameW = desc.frameW,
      frameH = desc.frameH,
      anchorX = desc.anchorX,
      anchorY = desc.anchorY,
      logicalFootprintW = 16,
      logicalFootprintH = 16,
      characterAppearanceApiVersion = 1,
      characterAppearanceOwner = mod.id,
    }
    return desc, image
  end

  function RoleSprite:resolveImage()
    local _, image = self:selection()
    if image then return image end
    return self.rom and self.rom.resolveImage and self.rom:resolveImage() or nil
  end

  local function frameQuad(desc, image, frame)
    local key = desc.imagePath .. "#" .. tostring(frame)
    if not quadCache[key] then
      local iw, ih = image:getDimensions()
      quadCache[key] = love.graphics.newQuad(0, frame * desc.frameH,
        desc.frameW, desc.frameH, iw, ih)
    end
    return quadCache[key]
  end

  function RoleSprite:draw(px, py, camX, camY, facing, walkPhase, stepFlip, topHalf)
    -- Fishing is a ROM-local composition: an 8px hand tile plus a separately
    -- positioned rod effect. The supplied FRLG frames include a full rod, so
    -- replacing only one half would either double or sever it.
    if topHalf then
      if self.rom and self.rom.draw then
        return self.rom:draw(px, py, camX, camY, facing, walkPhase, stepFlip, topHalf)
      end
      return
    end
    local desc, image = self:selection()
    if not (desc and image) then
      if self.rom and self.rom.draw then
        return self.rom:draw(px, py, camX, camY, facing, walkPhase, stepFlip, topHalf)
      end
      return
    end
    local tableForPose = walkPhase == 1 and WALK or STAND
    local frame = tableForPose[facing] or 0
    local flip = facing == "right"
      or (walkPhase == 1 and stepFlip and (facing == "up" or facing == "down"))
    local cellX = math.floor(px - camX)
    local cellBottom = math.floor(py - camY) + 12
    local x = cellX + math.floor((16 - desc.frameW) / 2)
    local y = cellBottom - desc.frameH
    local quad = frameQuad(desc, image, frame)
    love.graphics.setColor(1, 1, 1, 1)
    if flip then
      love.graphics.draw(image, quad, x + desc.frameW, y, 0, -1, 1)
    else
      love.graphics.draw(image, quad, x, y)
    end
    if PaletteFX and PaletteFX.markTrueColor then
      PaletteFX.markTrueColor(x, y, desc.frameW, desc.frameH)
    end
  end

  function RoleSprite:drawTile(path, x, y, flip)
    if self.rom and self.rom.drawTile then return self.rom:drawTile(path, x, y, flip) end
  end

  local function wrapRole(player, key, role)
    local current = player and player[key]
    if not current then return end
    if getmetatable(current) == RoleSprite then return end
    player[key] = RoleSprite.new(role, current)
  end

  local function installPlayerRenderers()
    local player = Game and Game.overworld and Game.overworld.player
    if not player then return false end
    wrapRole(player, "sprite", "walk")
    wrapRole(player, "bikeSprite", "bike")
    wrapRole(player, "surfSprite", "surf")
    -- surfPikachuSprite, Fly bird, and fishing composition keep their owner.
    return true
  end

  local function checkDramaticShape()
    if warnedDramaticShape or activePackId() == "rom" then return end
    if incompatibleVoxelActive() then
      warnedDramaticShape = true
      mod.log:warn("Character Sprite Replacer: Dramatic Shape voxel mode lacks enhanced player-frame support; overworld roles are using ROM art until its owner-side descriptor integration is available")
    end
  end

  mod.hooks:wrap("player.sprite", function(next, path, ctx)
    local original = next(path, ctx)
    if activePackId() == "rom" or not ctx or ctx.demo or ctx.oakDemo then
      return original
    end
    local role = ctx.side == "back" and "back" or "front"
    local desc = descriptor(role)
    if not (desc and imageFor(desc)) then return original end
    ctx.trueColor = true
    return desc.imagePath
  end)

  if mod.events and mod.events.on then
    mod.events:on("mods.loaded", checkDramaticShape)
    mod.events:on("game.ready", function()
      installPlayerRenderers()
      checkDramaticShape()
    end)
    mod.events:on("map.entered", installPlayerRenderers)
    mod.events:on("mod.options_changed", function(payload)
      if payload and payload.mod == mod.id then
        invalidate()
        installPlayerRenderers()
        checkDramaticShape()
      end
    end)
  end

  mod.exports.version = VERSION
  mod.exports.characterAppearanceApiVersion = 1
  mod.exports.activePack = activePackId
  mod.exports.resolvePlayerOverworld = function(role)
    if role == "fishing" or role == "surfPikachu" or role == "fly" then return nil end
    return descriptor(role)
  end
  mod.exports.resolveNpcOverworld = function() return nil end
  mod.exports.resolveTrainerOverworld = function() return nil end
  mod.exports.resolveTrainerBattle = function() return nil end
  mod.exports.resolvePlayerBattle = function(role)
    if role ~= "front" and role ~= "back" then return nil end
    return descriptor(role)
  end
  mod.exports.resolvePlayerPresentation = function(role)
    if role == "main_menu" or role == "start_menu" or role == "continue" then
      return descriptor("main_menu")
    end
    if role == "trainer_card" or role == "hall_of_fame" or role == "intro" then
      return descriptor("front")
    end
    return nil
  end
  mod.exports.invalidate = invalidate
  mod.exports.auditCoverage = function()
    return {
      packId = activePackId(),
      player = ROLE_MAP,
      supported = { "walk", "bike", "surf", "front", "back", "main_menu_provider" },
      fallback = { "fishing", "surfPikachu", "fly" },
      excluded = { "npc", "trainer_overworld", "trainer_battle" },
    }
  end

  mod.log:info("Gen1 Character Sprite Replacer %s ready (ROM / FRLG Red / FRLG Leaf)", VERSION)
end
