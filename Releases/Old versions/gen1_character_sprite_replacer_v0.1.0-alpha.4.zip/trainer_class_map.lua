-- First batch contains no enemy trainer portraits.
return {}
