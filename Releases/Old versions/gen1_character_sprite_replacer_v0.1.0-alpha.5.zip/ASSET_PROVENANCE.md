# Asset provenance

## FRLG player batch

- Source supplied by the user: `Game Boy Advance - Pokemon FireRed _ LeafGreen - Playable Characters - Player Sprites.png`.
- Source dimensions: 673x638 RGBA.
- Depicted game/source: Pokemon FireRed and Pokemon LeafGreen (Game Boy Advance).
- Sheet compiler/ripper: not identified in the supplied file. The filename and sheet labeling are preserved here; no unsupported author attribution is invented.
- Transformation: exact reviewed rectangles were cropped; the sheet's orange `#ff7f27` and green `#22b14c` matte colors were converted to transparent alpha; walk and bicycle frames were reordered from the source's `step A | neutral idle | step B` columns into a twelve-pose idle/step-A/step-B sequence covering down/up/left/right, while Surf retains its six-pose source coverage. No interpolation, recoloring, generative processing, or ROM content outside this supplied sheet was used.
- Reproduction tool: `tools/extract_frlg_player_batch.py` in the editable source tree.
- Machine-readable dimensions and SHA-256 hashes: `FRLG_EXTRACTION_REPORT.json`.
- Output assets: Red/Leaf walk, bicycle, Surf composition, player front, battle back, and main-menu presentation images.
- Rights: these are game-derived graphics supplied by the user for this mod. They are not covered by the code license. No ROM is included.

The full source sheet is intentionally not packaged in the release.
