# Gen1 Unified Quality of Life

Current build: **0.1.0-alpha.1**

One configurable Gen1Recomp mod for optional battle information, explicit
battle rules, location banners, and field shortcuts. It replaces the ownership
of Quality of Life, Catch Helper, and EXP Share Modes without silently changing
catch or leveling rules.

## Defaults

Gameplay-changing settings default to vanilla:

- EXP Bar: Off
- Owned Indicator: Off
- Catch Odds: Off
- Ultra Ball Rule: Vanilla
- EXP Distribution: Vanilla
- Location Banners: Off
- Easy Interactions: Off
- Repel Prompt: On, but inactive while Easy Interactions is Off

Open **OPTIONS → QUALITY OF LIFE** for the grouped interface. The Mod Manager
also exposes the complete flat option schema.

## Battle Display

- Animated EXP progress bar.
- One owned-species marker with Gen 2, red, and grey styles.
- Signed X/Y marker offsets.
- Whole-number Poke/Great/Ultra or Safari catch probabilities.
- Exact enumeration of the stock two-roll check using live HP, status, catch
  rate, and merged ball/status records.
- A custom ball with its own `attempt` function displays unknown odds instead
  of an invented value.

## Battle Rules

**Ultra Ball Rule**

- `VANILLA`: the engine's merged Ultra Ball behavior is untouched.
- `CORRECTED`: stock Ultra Ball uses HP factor 8 while retaining its stronger
  first roll. A third-party custom `attempt` remains authoritative.

**EXP Distribution**

- `VANILLA`: engine behavior is unchanged, including EXP.ALL.
- `PARTICIPANTS`: living participants split one full pool; EXP.ALL is ignored
  for this award.
- `ALL EVEN`: all living party members split one full pool.
- `MODERN 50%`: living participants split the full pool and living bench
  Pokemon split a separate half pool.

All custom awards use the engine's native award continuation. Trainer/traded
bonuses, stat EXP, happiness, level messages, stat screens, move learning,
evolution scheduling, events, and Yellow Legacy's `exp.gain` cap remain live.
Integer floors and the engine's minimum-one rule can make totals differ
slightly from the headline percentages.

## World Convenience

When Easy Interactions is enabled:

- A prioritizes NPCs, scripts, signs, followers, and visible wild entities.
- A can then use Strength on genuine boulders, Cut on valid targets, or
  Surf/fish at water according to the selected Water Action.
- Fishing uses the strongest owned rod and is unavailable while surfing.
- Select offers eligible Fly, Teleport, Flash, Dig, and the weakest owned
  Repel.
- The optional renewal prompt appears only after the wear-off message is
  acknowledged.

Location banners are independent and can remain enabled while Easy
Interactions is off.

## Compatibility and conflicts

Do not enable this mod with:

- `quality_of_life`
- `catch_helper`
- `exp_share_modes`

The manifest declares those conflicts. The mod does not own battle art, shiny
state, followers, visible-wild entities, encounter tables, world geometry,
camera behavior, or full UI layouts. Integrations with Widescreen UI, Dramatic
Shape/Battle Art Voxel Fork, Shiny System, HGSS icons/follower, Wilds, and
Yellow Legacy are optional and fail open.

The Dramatic Shape snapped-HUD interface is not public in the audited versions.
This alpha uses a narrow version-guarded observer for that path and otherwise
falls back to the engine's public `battle.overlay` hook.

## Legacy migration

If this mod has no settings yet, it migrates compatible settings from the three
superseded mods once. It never deletes their option buckets and never infers
that Catch Helper's unconditional Ultra correction should remain enabled.

## Installation

Import the flat release ZIP using the Gen1Recomp launcher. Do not extract it
over another mod and do not enable the three conflicting reference mods.

## Attribution

- Quality of Life by unxpected-uxp: behavioral reference only; its audited
  package/repository did not declare a license, so its source is not copied.
- Catch Helper 1.4.0 and EXP Share Modes 1.0.0: MIT-licensed behavioral and
  algorithmic references. The retained notice is in
  `THIRD_PARTY_LICENSES.txt`.

No ROM is included.
