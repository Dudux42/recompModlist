local M = {}

local BAR_UNITS = 67

local function livingParty(battle)
  local out = {}
  local party = battle and battle.game and battle.game.save and battle.game.save.party or {}
  for _, mon in ipairs(party) do
    if (tonumber(mon.hp) or 0) > 0 then out[#out + 1] = mon end
  end
  return out
end

local function recipientPlan(ctx, mode)
  local plan = {}
  local participants = ctx.alive or {}
  if mode == "participants" then
    local split = math.max(1, #participants)
    for _, mon in ipairs(participants) do
      plan[#plan + 1] = { mon = mon, split = split, announce = true, group = "participant" }
    end
  elseif mode == "all_even" then
    local living = livingParty(ctx.battle)
    local split = math.max(1, #living)
    for _, mon in ipairs(living) do
      plan[#plan + 1] = { mon = mon, split = split, announce = true, group = "all" }
    end
  elseif mode == "modern_50" then
    local participantSet = {}
    local participantSplit = math.max(1, #participants)
    for _, mon in ipairs(participants) do
      participantSet[mon] = true
      plan[#plan + 1] = {
        mon = mon, split = participantSplit, announce = true, group = "participant",
      }
    end
    local bench = {}
    for _, mon in ipairs(livingParty(ctx.battle)) do
      if not participantSet[mon] then bench[#bench + 1] = mon end
    end
    local benchSplit = math.max(1, #bench * 2)
    for _, mon in ipairs(bench) do
      plan[#plan + 1] = {
        mon = mon, split = benchSplit, announce = true, group = "bench",
      }
    end
  end
  return plan
end

local function expUnits(battle)
  local mon = battle and battle.player and battle.player.mon
  local def = mon and battle.data and battle.data.pokemon
    and battle.data.pokemon[mon.species]
  if not mon or not def then return 0 end
  local cap = battle.data.constants and battle.data.constants.levelCap or 100
  if mon.level >= cap then return BAR_UNITS end
  local Growth = require("src.pokemon.Growth")
  local current = Growth.expForLevel(def.growthRate, mon.level, battle.data.growth_rates)
  local nextLevel = Growth.expForLevel(def.growthRate, mon.level + 1,
    battle.data.growth_rates)
  local needed = nextLevel - current
  if needed <= 0 then return 0 end
  local progress = math.max(0, math.min(needed, (tonumber(mon.exp) or current) - current))
  return math.floor(progress * BAR_UNITS / needed)
end

local function animatedUnits(battle, state)
  local mon = battle and battle.player and battle.player.mon
  local target = expUnits(battle)
  if state.mon ~= mon or state.units == nil then
    state.mon, state.units = mon, target
    state.level = mon and mon.level
    state.phase, state.pendingLevels = nil, 0
    state.frame = battle and battle.frame
    return target
  end
  if state.frame == battle.frame then return state.units end
  state.frame = battle.frame

  local level = mon and mon.level or state.level
  if level and state.level and level > state.level then
    state.pendingLevels = (state.pendingLevels or 0) + level - state.level
    state.phase = state.phase or "fill"
  end
  state.level = level

  if state.phase == "fill" then
    state.units = math.min(BAR_UNITS, state.units + 1)
    if state.units >= BAR_UNITS then
      state.phase, state.hold = "hold", 12
    end
  elseif state.phase == "hold" then
    state.hold = state.hold - 1
    if state.hold <= 0 then
      state.pendingLevels = math.max(0, (state.pendingLevels or 1) - 1)
      state.units = 0
      state.phase = state.pendingLevels > 0 and "fill" or "settle"
    end
  elseif state.phase == "settle" then
    state.units = math.min(target, state.units + 1)
    if state.units >= target then state.phase = nil end
  elseif state.units < target then
    state.units = state.units + 1
  elseif state.units > target then
    state.units = state.units - 1
  end
  return state.units
end

local function drawBar(battle, units, context)
  if units <= 0 then return end
  local g = love.graphics
  local voxel, scale = context.voxel, 1
  local ox, oy = 0, 0
  if voxel then
    g.setCanvas(voxel.canvas)
    scale, ox, oy = voxel.scale, voxel.lx, voxel.ly
  end
  if g.origin then g.origin() end
  if g.setShader then g.setShader() end
  local okPalette, PaletteFX = pcall(require, "src.render.PaletteFX")
  local colorMode = okPalette and PaletteFX.mode
  local colored = colorMode == "ogred" or colorMode == "gbc" or colorMode == "redpp"
  if colored then
    g.setColor(50 / 255, 150 / 255, 250 / 255, 1)
  else
    g.setColor(0, 0, 0, 1)
  end
  local x, y, width
  if context.wide then
    width = math.floor(units * 80 / BAR_UNITS)
    x, y = 208 + 80 - width, 91
  else
    width = units
    x, y = 80 + BAR_UNITS - width, 89
  end
  x = ox + (x + context.sx) * scale
  y = oy + (y + context.sy) * scale
  g.rectangle("fill", math.floor(x), math.floor(y), width * scale, 2 * scale)
  if not voxel then
    if okPalette and PaletteFX.markTrueColor then
      PaletteFX.markTrueColor(math.floor(x), math.floor(y), width, 2)
    end
  end
end

function M.install(mod, options, overlay)
  mod.hooks:wrap("battle.exp_award", function(next, ctx)
    local mode = options.value(ctx and ctx.battle and ctx.battle.game, "expDistribution")
    if mode ~= "participants" and mode ~= "all_even" and mode ~= "modern_50" then
      return next(ctx)
    end
    if not ctx or type(ctx.applyShare) ~= "function" then
      return next(ctx)
    end
    local plan = recipientPlan(ctx, mode)
    for _, award in ipairs(plan) do
      ctx.applyShare(award.mon, award.split, award.announce)
    end
  end, 100)

  overlay:add({
    id = "experience bar",
    draw = function(battle, state, context)
      if not options.value(battle.game, "expBar") then return end
      if not battle.player or battle.safari or battle.demo or battle.showPlayerBack
          or context.intro then return end
      drawBar(battle, animatedUnits(battle, state), context)
    end,
  })

  mod.exports.expRecipientPlan = recipientPlan
  mod.exports.expUnits = expUnits
  mod.exports.animatedExpUnits = animatedUnits
end

return M
