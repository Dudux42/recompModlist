# Gen1 Widescreen UI

Current build: **0.1.0-alpha.10**

## Alpha 10 presentation-only Pokedex

- Restyles the native Pokedex list, option menus and entry page with the same
  cream, charcoal, red-accent, panel and typography system as the other
  converted screens.
- Presents the installed Pokedex+ main list, search, stats, habitat and nested
  list screens through its published read-only semantic models when available.
- Leaves all navigation, discovery flags, DATA, CRY, AREA, search, habitat,
  stats, evolution and move callbacks with their existing owner.
- Publishes no new Pokedex gameplay behavior. The planned dedicated Widescreen
  Pokedex mod remains responsible for future layout and functionality changes.

## Alpha 9.1 full-height battle anchoring

- Battle HUD panels now use the full visible window height while preserving
  the world's uniform scale and geometry.
- The enemy panel anchors to the real top edge, and command, message, and move
  panels anchor to the real bottom edge on 4:3 displays.
- Voxel battle HUD providers are patched at battle creation, before their
  private native-HUD snapshot is captured, with a first-overlay fallback for
  unusual load orders.
- 16:9 presentation is unchanged, and the Alpha 9 Move Inspector contract is
  retained.

## Alpha 9 Move Inspector provider API

- Publishes generic Battle Move Inspector API v1 through
  `registerBattleMoveInspector`, `unregisterBattleMoveInspector`, and
  `activeBattleMoveInspectorOwner`.
- Accepts one immutable semantic snapshot provider at a time. Re-registering
  the same owner replaces it safely; a different owner is rejected.
- Validates every snapshot, deduplicates provider errors, and keeps the basic
  move panel usable if a provider fails.
- Extends the existing 2x2 move panel with type, PP, power, accuracy, type-chart
  matchup, STAB, and disabled state when a compatible provider is active.
- Keeps Mimic on the basic detail panel because its copied move has no verified
  target/user semantics at selection time.
- A registered provider forces WIDESCREEN BATTLE HUD on. If its saved toggle is
  off, Widescreen logs one explicit warning and ignores that setting until the
  provider is removed.

Provider contract:

```lua
local ok, reason = widescreen.exports.registerBattleMoveInspector({
  owner = "compatible_mod_id",
  apiVersion = 1,
  snapshot = function(battle)
    return immutableSchemaV1SnapshotOrNil
  end,
})
```

Widescreen never discovers providers by manifest ID and never calls a provider
outside normal `moveSelect` presentation.

## Alpha 8.2 provider and grid corrections

- Suppresses captured native HUD layers from both Dramatic Shape and Battle
  Art Voxel Fork; either provider may own the active 3D battle pipeline.
- Docks the player status panel immediately above the bottom command panel,
  right-aligns both, and keeps the enemy status panel in the upper-left. During
  move selection it lifts above the taller inspector panel to prevent overlap.
- Up/Down changes grid rows while preserving the column. Left/Right changes
  columns while preserving the row, for both normal moves and Mimic.

## Alpha 8.1 battle HUD corrections

- Installs the Dramatic Shape adapter before its world-composition pass, so
  the captured native status HUD is no longer visible behind Widescreen.
- Reduces status, command, message and move-panel dimensions and typography.
- Restores horizontal 2x2 move-grid navigation while retaining the classic
  battlefield layer used to suppress native battle chrome.

## Alpha 8 battle HUD

- Adds a final-resolution 640x360 Battle HUD with enemy/player status panels,
  exact player HP, status conditions and a blue current-level EXP bar.
- Replaces battle messages, the FIGHT/POKEMON/BAG/RUN prompt, Safari commands,
  the scripted Old Man prompt, the 2x2 move menu and Mimic selection.
- The move panel shows live PP, disabled/swap state and the same color-coded
  type badges used by Party and Summary.
- Dramatic Shape integration suppresses only its native snapped HUD and glass
  panels. Its arena, camera, battlers, animations, Stadium models and world
  composition remain untouched.
- Disabling WIDESCREEN BATTLE HUD restores the engine's selected battle layout
  and Dramatic Shape's native HUD presentation.

## Alpha 7.12 direct shiny-system integration

- Party icons and 2D detail/summary portraits consult the shared Gen1 Shiny
  System at draw time, so its master/color options apply without stale caches.

## Alpha 7.11 Shiny Pokemon flag compatibility

- Party icons now honor the explicit `mon.shiny` flag used by the installed
  Shiny Pokemon mod as well as the engine's native shiny-DV calculation.

## Alpha 7.10 shiny icon compatibility

- Standard 32x64 icon descriptors may now provide a `shinyImage` sheet.
- The widescreen party list selects that sheet using the engine's native
  shiny-DV check, matching the standalone HGSS Menu Icons mod.

## Alpha 7.9 icon-provider compatibility

- The widescreen party screen now prefers an active standard 32x64 icon
  descriptor, allowing the standalone `hgss_menu_icons` mod to replace its
  row artwork.
- If no compatible icon provider is active, the existing bundled HGSS atlas
  remains the fallback. The widescreen UI therefore has no new mandatory
  dependency.

## Alpha 7.6 party icons

- The widescreen party screen now bundles its own animated true-colour HGSS
  icons for all 151 Pokemon. It no longer depends on `new_icons`, Wilds, or a
  follower mod to supply its six row icons.
- The icons are stored in one atlas, avoiding the launcher's large-file-count
  import failure.
- The release archive is intentionally flat: no recursive asset directories
  are exposed to Gen1Recomp's fragile ZIP copy routine.

## Alpha 7.5 sprite-quality compatibility

- Modern 32x32 party icons are drawn at native detail on the widescreen
  surface instead of being reduced to the stock 16x16 icon canvas first.
- Overworld follower rendering belongs exclusively to the standalone follower
  mod. The widescreen package no longer patches Wilds or Dramatic Shape.

This package returns to the last confirmed-working alpha 7 baseline and adds
the widescreen Summary/Stats and dialogue-overlap changes. It
replaces the START, Pokemon party, two-page stat-screen and battle-HUD
presentation while
leaving Gen1Recomp's native menu logic and Dramatic Shape's world renderer
intact.

## Current scope

- 640x360 virtual 16:9 layout rendered at final window resolution.
- Responsive integer-perfect scaling at 1080p, 1440p, and 4K.
- Native START menu input, callbacks, cursor persistence, and mod-added rows.
- Independent presentation scrolling so more entries fit on screen.
- Bundled Pixelify Sans UI font, including its SIL Open Font License.
- Pixelify Sans sizes aligned to a 16/12-unit pixel grid for crisper 1080p
  rasterization with nearest-neighbor filtering and integer positioning.
- 22-unit START-menu row rhythm and a two-pass label renderer, preventing
  selection bands from painting over text in adjacent rows.
- Widescreen Pokemon party list with all six members visible, HP bars,
  TM/HM compatibility labels, selected-mon details, and a dedicated action
  panel that never opens over the party list.
- The selected-mon detail panel first consults
  `game.mods.exports.BATTLE_ART_VOXEL_FORK.lib`: STATIC uses that mod's
  `BattleArt.image`, while ANIMATED uses its `AnimatedBattleArt` atlas decoder
  and selected generation. ROM or missing art falls back to
  `Sprites.path(..., "front", { kind = "battle" })`.
- ANIMATED Battle Art advances through the mod's own atlas frames and duration
  metadata in the Pokemon menu. The shared 2D portrait resolver/drawer is
  exported for every subsequent converted UI screen; it deliberately never
  attempts to flatten Dramatic Shape Stadium models.
- The portrait is unframed, long Pokemon names use the smaller UI font when
  necessary, and the quick-info panel shows HP, level, ATK, DEF, SPD, SPC and
  four move names without PP.
- The quick-info panel also shows the selected Pokemon's color-coded type
  capsules and an unlabeled blue current-level EXP bar beneath its HP bar.
- Compact-panel battle portraits receive a bounded aspect-aware size boost,
  improving wide silhouettes such as Kadabra without species-specific rules;
  the move list is compressed slightly so its fourth row clears the border.
- Party icons are still drawn through `PartyMenu.drawIcon`, preserving icon
  replacements and follower-mod draw hooks.
- Non-opaque states above PartyMenu (follower confirmations, field-move
  messages, YES/NO choices and visual overlays) are composed over the
  widescreen presenter. Opaque destinations still replace Party normally.
  This removes the former native-menu fallback path rather than special-casing
  only FOLLOW.
- The original `SummaryMenu` constructor is wrapped once, so every normal
  entry path (Party, PC/Box, scripts, and mod callers) opens the same responsive
  two-page stat screen. Page one shows identity, animated/static 2D Battle Art,
  HP, status, types and the four Gen 1 stats; page two shows experience and all
  four moves with PP.
- Species and move types use compact color-coded capsules for all eighteen
  modern type names. The experience page includes a blue bar calculated from
  the active species growth curve and the current level's exact EXP bounds.
- Widescreen Party and Summary messages suppress the original 160x144
  TextBox/ChoiceBox draw and recompose those overlays in the 640x360 UI. This
  removes the duplicate dialogue that previously remained visible below the
  converted screen.
- The Widescreen Battle HUD keeps battle simulation, timing and input native,
  but draws one final-resolution presentation for status, messages, commands
  and moves. Intro/fainted party markers, Safari, Old Man and Mimic states are
  included instead of falling back to the native HUD.
- No `Renderer:setUISize`, `render.compose`, camera, zoom, voxel, or tilt
  modifications.

## Bundled font

Pixelify Sans is Copyright 2021 The Pixelify Sans Project Authors and is
redistributed under the SIL Open Font License 1.1. Its license is included at
`assets/fonts/pixelify_sans/OFL.txt`.

## Compatibility notes

The Gen 3 Inspired UI mod also replaces the START, Pokemon and battle screens. This
prototype uses instance-level presentation suppression so only one final-pass
presenter is visible. For the cleanest configuration, disable Gen 3 Inspired
UI's **OVERWORLD MENUS**, **POKEMON MENU** and **BATTLE UI** options while
testing this build. Two mods must not own the same final battle presenter.

Battle Art Voxel's STATIC front source is
`assets/battle/front-static/<species>.png`. Its ANIMATED source is the selected
`assets/battle/front-animated/<generation>` collection plus the mod's metadata.
The integration uses the mod's exported loaders rather than reconstructing
those paths, preserving its shiny, transparency, palette and fallback rules.
Dramatic Shape's 2D-3D arenas continue to use these battler images. STADIUM
mode uses live 3D model packs and therefore has no 2D front-image equivalent;
the panel uses the selected Battle Art image or engine front sprite in that
case instead of attempting to flatten a model.

## Planned conversion order

0. START, Party, action overlays and both Summary pages (implemented)
1. Battle HUD, command menu and move selection (implemented in Alpha 8)
2. Presentation-only native/Pokedex+ styling (implemented in Alpha 10)
3. Options and contextual help
4. Dialogue and remaining global-font migration
5. Full transition, fallback, input and resolution audit

Pokedex/Pokedex Plus now receive a presentation-only compatibility skin. The
planned dedicated Pokedex mod will define the future master/detail layout and
new research functions. Bag conversion remains deferred until its dedicated
gameplay mod defines the data and action contract Widescreen must present.

The Widescreen Dex Radar is a separate dependent mod. This project owns the
semantic Start-menu/presentation API it consumes, but not its encounter data
or radar screen implementation.
