-- Gen1 Widescreen UI
-- Version 0.1.0-alpha.11.3.2
--
-- The world renderer deliberately remains on its normal 160x144 logical
-- surface.  Converted screens are presented in render.hud, after Gen1Recomp
-- and Dramatic Shape have finished composing the world.  This avoids the
-- camera/zoom changes caused by asking Renderer for a wider UI canvas while
-- the overworld is visible.

local DESIGN_W, DESIGN_H = 640, 360
local FONT_PATH = "PixelifySans-VariableFont_wght.ttf"
local PokemonSprites, Assets, PaletteFX, Stats, BattleState
local ShinyArtResolver, ShinyBattleImage
local EngineFont, TextBoxClass, ChoiceBoxClass
local ListMenuClass, MenuClass, PokedexMenuClass, DexEntryMenuClass
local TitleStateClass, QuarantineReportClass
local partyBattleSpriteCache = {}
local partyIconSheetCache = {}
local titlePresentationCycles = setmetatable({}, { __mode = "k" })
local levelExpProgress
local battleMoveInspectorProvider
local battleMoveInspectorLogError
local BATTLE_MOVE_INSPECTOR_API_VERSION = 1
local pokedexProvider
local pokedexProviderLogError
local POKEDEX_PROVIDER_API_VERSION = 1
local battleHudOverlayProviders = {}
local battleHudOverlayLogError
local BATTLE_HUD_OVERLAY_API_VERSION = 1
local worldHudOverlayProviders = {}
local worldHudOverlayLogError
local WORLD_HUD_OVERLAY_API_VERSION = 1

local PARTY_ICON_SPECIES = {
  "BULBASAUR","IVYSAUR","VENUSAUR","CHARMANDER","CHARMELEON","CHARIZARD",
  "SQUIRTLE","WARTORTLE","BLASTOISE","CATERPIE","METAPOD","BUTTERFREE",
  "WEEDLE","KAKUNA","BEEDRILL","PIDGEY","PIDGEOTTO","PIDGEOT","RATTATA",
  "RATICATE","SPEAROW","FEAROW","EKANS","ARBOK","PIKACHU","RAICHU",
  "SANDSHREW","SANDSLASH","NIDORANF","NIDORINA","NIDOQUEEN","NIDORANM",
  "NIDORINO","NIDOKING","CLEFAIRY","CLEFABLE","VULPIX","NINETALES",
  "JIGGLYPUFF","WIGGLYTUFF","ZUBAT","GOLBAT","ODDISH","GLOOM","VILEPLUME",
  "PARAS","PARASECT","VENONAT","VENOMOTH","DIGLETT","DUGTRIO","MEOWTH",
  "PERSIAN","PSYDUCK","GOLDUCK","MANKEY","PRIMEAPE","GROWLITHE","ARCANINE",
  "POLIWAG","POLIWHIRL","POLIWRATH","ABRA","KADABRA","ALAKAZAM","MACHOP",
  "MACHOKE","MACHAMP","BELLSPROUT","WEEPINBELL","VICTREEBEL","TENTACOOL",
  "TENTACRUEL","GEODUDE","GRAVELER","GOLEM","PONYTA","RAPIDASH","SLOWPOKE",
  "SLOWBRO","MAGNEMITE","MAGNETON","FARFETCHD","DODUO","DODRIO","SEEL",
  "DEWGONG","GRIMER","MUK","SHELLDER","CLOYSTER","GASTLY","HAUNTER",
  "GENGAR","ONIX","DROWZEE","HYPNO","KRABBY","KINGLER","VOLTORB",
  "ELECTRODE","EXEGGCUTE","EXEGGUTOR","CUBONE","MAROWAK","HITMONLEE",
  "HITMONCHAN","LICKITUNG","KOFFING","WEEZING","RHYHORN","RHYDON","CHANSEY",
  "TANGELA","KANGASKHAN","HORSEA","SEADRA","GOLDEEN","SEAKING","STARYU",
  "STARMIE","MRMIME","SCYTHER","JYNX","ELECTABUZZ","MAGMAR","PINSIR",
  "TAUROS","MAGIKARP","GYARADOS","LAPRAS","DITTO","EEVEE","VAPOREON",
  "JOLTEON","FLAREON","PORYGON","OMANYTE","OMASTAR","KABUTO","KABUTOPS",
  "AERODACTYL","SNORLAX","ARTICUNO","ZAPDOS","MOLTRES","DRATINI","DRAGONAIR",
  "DRAGONITE","MEWTWO","MEW",
}
local PARTY_ICON_DEX = {}
for dex, species in ipairs(PARTY_ICON_SPECIES) do PARTY_ICON_DEX[species] = dex end

local COLORS = {
  shadow = { 0.02, 0.025, 0.03, 0.72 },
  paper = { 0.965, 0.965, 0.93, 0.97 },
  paper2 = { 0.88, 0.89, 0.84, 0.97 },
  ink = { 0.055, 0.065, 0.07, 1.0 },
  selected = { 0.075, 0.10, 0.12, 1.0 },
  selectedText = { 1.0, 1.0, 0.96, 1.0 },
  accent = { 0.82, 0.16, 0.11, 1.0 },
  muted = { 0.25, 0.27, 0.27, 1.0 },
}

local function setColor(c)
  love.graphics.setColor(c[1], c[2], c[3], c[4])
end

local function topState(game)
  if not (game and game.stack) then return nil end
  if type(game.stack.top) == "function" then return game.stack:top() end
  local states = game.stack.states
  return type(states) == "table" and states[#states] or nil
end

local function stateInStack(game, wanted)
  local states = game and game.stack and game.stack.states
  if type(states) ~= "table" or wanted == nil then return false end
  for _, state in ipairs(states) do
    if state == wanted then return true end
  end
  return false
end

local function drawPanel(x, y, w, h)
  local g = love.graphics
  setColor(COLORS.shadow)
  g.rectangle("fill", x + 4, y + 5, w, h)
  setColor(COLORS.ink)
  g.rectangle("fill", x, y, w, h)
  setColor(COLORS.paper)
  g.rectangle("fill", x + 2, y + 2, w - 4, h - 4)
  setColor(COLORS.ink)
  g.rectangle("fill", x + 6, y + 6, w - 12, 2)
  g.rectangle("fill", x + 6, y + h - 8, w - 12, 2)
end

local function loadFont(size)
  local g = love and love.graphics
  if not g then return nil end
  local ok, font = pcall(g.newFont, FONT_PATH, size, "mono")
  if not ok or not font then
    ok, font = pcall(g.newFont, size)
  end
  if ok and font and font.setFilter then
    pcall(font.setFilter, font, "nearest", "nearest")
  end
  return ok and font or nil
end

local function cleanLabel(value)
  local text = tostring(value or "")
  -- Menu labels should be one line even when supplied by an external mod.
  text = text:gsub("[\r\n]+", " ")
  return text
end

local function fitLabel(font, value, maxWidth)
  local text = cleanLabel(value)
  if not font or font:getWidth(text) <= maxWidth then return text end
  local suffix = ".."
  while #text > 1 and font:getWidth(text .. suffix) > maxWidth do
    text = text:sub(1, -2)
  end
  return text .. suffix
end

local function updatePresentationScroll(menu, visible)
  local count = #(menu.items or {})
  local index = math.max(1, math.min(tonumber(menu.index) or 1,
                                    math.max(1, count)))
  local maxScroll = math.max(0, count - visible)
  local scroll = math.max(0, math.min(tonumber(menu.__wideUiScroll) or 0,
                                     maxScroll))
  if index <= scroll then
    scroll = index - 1
  elseif index > scroll + visible then
    scroll = index - visible
  end
  menu.__wideUiScroll = math.max(0, math.min(scroll, maxScroll))
  return menu.__wideUiScroll
end

local function drawStartMenu(menu, fonts)
  local g = love.graphics
  -- Keep a generous row pitch so proportional fonts and accented labels have
  -- room at every output resolution. The two-pass row renderer below is also
  -- intentional: every highlight is painted before any label, so a glyph that
  -- extends outside its nominal font box can never be overpainted by the next
  -- row's selection band.
  local x, y, w, h = DESIGN_W - 224, 5, 212, DESIGN_H - 10
  local headerH, footerH, rowH = 31, 24, 22
  local contentTop = y + headerH + 3
  local contentBottom = y + h - footerH - 3
  local visible = math.max(1, math.floor((contentBottom - contentTop) / rowH))
  local items = menu.items or {}
  local scroll = updatePresentationScroll(menu, visible)

  drawPanel(x, y, w, h)

  setColor(COLORS.ink)
  g.setFont(fonts.title)
  g.print("START", x + 14, y + 10)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 83, y + 17, w - 99, 3)

  g.setFont(fonts.body)
  -- Pass 1: selection decoration.
  for slot = 1, visible do
    local itemIndex = scroll + slot
    local item = items[itemIndex]
    if not item then break end
    local ry = contentTop + (slot - 1) * rowH
    if itemIndex == menu.index then
      setColor(COLORS.selected)
      g.rectangle("fill", x + 9, ry + 2, w - 18, rowH - 2)
      setColor(COLORS.accent)
      g.rectangle("fill", x + 9, ry + 2, 4, rowH - 2)
    end
  end

  -- Pass 2: labels. Center using the selected font's actual line height
  -- instead of relying on font-specific baseline offsets.
  local textOffsetY = math.floor((rowH - fonts.body:getHeight()) / 2)
  for slot = 1, visible do
    local itemIndex = scroll + slot
    local item = items[itemIndex]
    if not item then break end
    local ry = contentTop + (slot - 1) * rowH
    if itemIndex == menu.index then
      setColor(COLORS.selectedText)
    else
      setColor(COLORS.ink)
    end
    g.print(cleanLabel(item.label), x + 20, ry + textOffsetY)
  end

  g.setFont(fonts.small)
  if scroll > 0 then
    setColor(COLORS.muted)
    g.print("MORE", x + w - 51, y + headerH - 1)
    g.polygon("fill", x + w - 19, y + headerH + 5,
              x + w - 13, y + headerH + 5,
              x + w - 16, y + headerH + 1)
  end
  if scroll + visible < #items then
    setColor(COLORS.muted)
    g.print("MORE", x + w - 51, y + h - footerH - 12)
    g.polygon("fill", x + w - 19, y + h - footerH - 8,
              x + w - 13, y + h - footerH - 8,
              x + w - 16, y + h - footerH - 4)
  end

  setColor(COLORS.paper2)
  g.rectangle("fill", x + 8, y + h - footerH, w - 16, footerH - 8)
  setColor(COLORS.muted)
  g.print("A  SELECT", x + 14, y + h - footerH + 3)
  local closeText = "B / START  CLOSE"
  g.print(closeText, x + w - 14 - fonts.small:getWidth(closeText),
          y + h - footerH + 3)
end

local function clamp(value, low, high)
  return math.max(low, math.min(high, value))
end

local function monDefinition(game, mon)
  local pokemon = game and game.data and game.data.pokemon
  return pokemon and mon and pokemon[mon.species] or nil
end

local function monName(game, mon)
  local def = monDefinition(game, mon)
  return cleanLabel(mon and (mon.nickname or (def and def.name) or mon.species)
                    or "POKEMON")
end

local function shownHP(menu, mon)
  if menu.heal and menu.heal.mon == mon then
    return math.floor(menu.heal.shown or mon.hp or 0)
  end
  return math.floor(mon.hp or 0)
end

local function hpColor(hp, maximum)
  local ratio = clamp(hp / math.max(1, maximum), 0, 1)
  if ratio <= 0.20 then return { 0.78, 0.15, 0.12, 1 } end
  if ratio <= 0.50 then return { 0.86, 0.62, 0.08, 1 } end
  return { 0.12, 0.62, 0.25, 1 }
end

local function drawHPBar(x, y, w, hp, maximum)
  local g = love.graphics
  local ratio = clamp(hp / math.max(1, maximum), 0, 1)
  setColor(COLORS.ink)
  g.rectangle("fill", x, y, w, 6)
  setColor(COLORS.paper2)
  g.rectangle("fill", x + 1, y + 1, w - 2, 4)
  local fill = math.floor((w - 2) * ratio + 0.5)
  if fill > 0 then
    setColor(hpColor(hp, maximum))
    g.rectangle("fill", x + 1, y + 1, fill, 4)
  end
end

local TYPE_COLORS = {
  NORMAL   = { 0.66, 0.65, 0.48, 1 },
  FIRE     = { 0.93, 0.51, 0.19, 1 },
  WATER    = { 0.39, 0.56, 0.94, 1 },
  ELECTRIC = { 0.97, 0.82, 0.17, 1 },
  GRASS    = { 0.48, 0.78, 0.30, 1 },
  ICE      = { 0.59, 0.85, 0.84, 1 },
  FIGHTING = { 0.76, 0.18, 0.16, 1 },
  POISON   = { 0.64, 0.24, 0.63, 1 },
  GROUND   = { 0.89, 0.75, 0.40, 1 },
  FLYING   = { 0.66, 0.56, 0.95, 1 },
  PSYCHIC  = { 0.98, 0.33, 0.53, 1 },
  BUG      = { 0.65, 0.73, 0.10, 1 },
  ROCK     = { 0.71, 0.63, 0.21, 1 },
  GHOST    = { 0.45, 0.34, 0.59, 1 },
  DRAGON   = { 0.44, 0.21, 0.99, 1 },
  DARK     = { 0.44, 0.34, 0.27, 1 },
  STEEL    = { 0.72, 0.72, 0.81, 1 },
  FAIRY    = { 0.84, 0.52, 0.68, 1 },
}

local LIGHT_TYPE_TEXT = {
  NORMAL = true, ELECTRIC = true, GRASS = true, ICE = true,
  GROUND = true, ROCK = true, STEEL = true,
}

local function normalizedType(typeId)
  return tostring(typeId or "-"):gsub("_TYPE$", ""):gsub("_", " "):upper()
end

local function drawTypeBadge(typeId, fonts, x, y, w, h)
  local g = love.graphics
  local label = normalizedType(typeId)
  local color = TYPE_COLORS[label] or { 0.40, 0.43, 0.45, 1 }
  local badgeFont = (h <= 18 and fonts.tiny) or fonts.small
  setColor(COLORS.ink)
  g.rectangle("fill", x, y, w, h, math.floor(h / 2), math.floor(h / 2))
  setColor(color)
  g.rectangle("fill", x + 1, y + 1, w - 2, h - 2,
              math.floor((h - 2) / 2), math.floor((h - 2) / 2))
  -- Small upper highlight gives the capsule the polished newer-game look
  -- without requiring additional image assets.
  setColor({ 1, 1, 1, 0.22 })
  g.rectangle("fill", x + 4, y + 3, w - 8, 2, 1, 1)
  g.setFont(badgeFont)
  setColor(LIGHT_TYPE_TEXT[label] and COLORS.ink or COLORS.selectedText)
  local tx = x + math.floor((w - badgeFont:getWidth(label)) / 2)
  local ty = y + math.floor((h - badgeFont:getHeight()) / 2)
  g.print(label, tx, ty)
end

local function drawXPBar(x, y, w, ratio)
  local g = love.graphics
  ratio = clamp(tonumber(ratio) or 0, 0, 1)
  setColor(COLORS.ink)
  g.rectangle("fill", x, y, w, 7)
  setColor(COLORS.paper2)
  g.rectangle("fill", x + 1, y + 1, w - 2, 5)
  local fill = math.floor((w - 2) * ratio + 0.5)
  if fill > 0 then
    setColor({ 0.18, 0.52, 0.94, 1 })
    g.rectangle("fill", x + 1, y + 1, fill, 5)
  end
end

-- -------------------------------------------------------------------------
-- Battle HUD
-- -------------------------------------------------------------------------

local function battleShownHP(battler)
  if not battler then return 0 end
  return math.max(0, math.floor(tonumber(battler.shownHP)
    or tonumber(battler.mon and battler.mon.hp) or 0))
end

local function battleMaxHP(battler)
  return math.max(1, math.floor(tonumber(battler and battler.mon
    and battler.mon.stats and battler.mon.stats.hp) or 1))
end

local function battleName(battler)
  return cleanLabel(battler and (battler.name
    or (battler.mon and battler.mon.nickname)
    or (battler.mon and battler.mon.species)) or "POKEMON")
end

local function battleStatus(battle, battler)
  if not (battler and battler.shownStatus) then return nil end
  if battle and type(battle.statusLabel) == "function" then
    local ok, label = pcall(battle.statusLabel, battle,
                            { status = battler.shownStatus })
    if ok and label and label ~= "" then return cleanLabel(label):upper() end
  end
  return cleanLabel(battler.shownStatus):upper()
end

local BATTLE_STATUS_COLORS = {
  PSN = { 0.58, 0.20, 0.68, 1 }, TOX = { 0.58, 0.20, 0.68, 1 },
  PAR = { 0.88, 0.63, 0.06, 1 }, BRN = { 0.88, 0.28, 0.08, 1 },
  FRZ = { 0.16, 0.57, 0.82, 1 }, SLP = { 0.35, 0.38, 0.43, 1 },
}

local function battleStatusColor(label)
  label = tostring(label or ""):upper()
  for key, color in pairs(BATTLE_STATUS_COLORS) do
    if label:find(key, 1, true) then return color end
  end
  return COLORS.muted
end

local function battleEnemyVisible(battle)
  if not (battle and battle.enemy) or battle.showEnemyTrainer
      or battle.enemySendingOut or battle.enemy.fainted
      or battle.introBalls then return false end
  if battle.growInScale then
    local ok, scale = pcall(battle.growInScale, battle, battle.enemy)
    if ok and scale then return false end
  end
  return (tonumber(battle.introSlide) or 0) == 0
end

local function battlePlayerVisible(battle)
  return battle and battle.player and not battle.safari and not battle.demo
    and not battle.showPlayerBack and (tonumber(battle.introSlide) or 0) == 0
end

local function battleExpRatio(battle, battler)
  local mon = battler and battler.mon
  local def = mon and battle and battle.data and battle.data.pokemon
    and battle.data.pokemon[mon.species]
  if not (mon and def) then return 0 end
  return levelExpProgress(battle.game, mon, def)
end

local function drawBattleStatusPanel(battle, battler, fonts,
                                    x, y, w, h, player)
  local g = love.graphics
  drawPanel(x, y, w, h)
  local hp, maximum = battleShownHP(battler), battleMaxHP(battler)

  g.setFont(fonts.small)
  setColor(COLORS.ink)
  local displayName = fitLabel(fonts.small, battleName(battler), w - 76)
  g.print(displayName, x + 13, y + 9)
  local level = tostring((battler.mon and battler.mon.level) or "?")
  local levelText = "Lv." .. level
  g.print(levelText, x + w - 13 - fonts.small:getWidth(levelText), y + 9)

  local status = battleStatus(battle, battler)
  if status then
    local color = battleStatusColor(status)
    setColor(color)
    g.rectangle("fill", x + 13, y + 28, 34, 12, 6, 6)
    g.setFont(fonts.tiny)
    setColor(COLORS.selectedText)
    g.print(fitLabel(fonts.tiny, status, 28), x + 16, y + 29)
  else
    g.setFont(fonts.tiny)
    setColor(COLORS.muted)
    g.print("HP", x + 13, y + 29)
  end

  drawHPBar(x + 50, y + 32, w - 63, hp, maximum)
  if player then
    g.setFont(fonts.small)
    setColor(COLORS.ink)
    local hpText = tostring(hp) .. "/" .. tostring(maximum)
    g.print(hpText, x + w - 13 - fonts.small:getWidth(hpText), y + 42)
    -- Leave a full separator row between EXP and the panel's lower rule.
    -- This avoids the same bottom-edge collision corrected in the Party UI.
    drawXPBar(x + 13, y + h - 18, w - 26, battleExpRatio(battle, battler))
  end
  return {
    x = x, y = y, w = w, h = h,
    name = displayName, nameX = x + 13, nameY = y + 9,
    nameWidth = fonts.small:getWidth(displayName),
  }
end

local function drawBattleHudExtensions(battle, fonts, layout)
  for _, provider in ipairs(battleHudOverlayProviders) do
    if not provider.failed then
      local ok, err = pcall(provider.draw, battle, {
        apiVersion = BATTLE_HUD_OVERLAY_API_VERSION,
        fonts = fonts,
        layout = layout,
        colors = COLORS,
        drawPanel = drawPanel,
      })
      if not ok then
        provider.failed = true
        if battleHudOverlayLogError then
          battleHudOverlayLogError(provider.owner .. ": " .. tostring(err))
        end
      end
    end
  end
end

local function drawWorldHudExtensions(game, fonts, viewW, viewH)
  for _, provider in ipairs(worldHudOverlayProviders) do
    if not provider.failed then
      local ok, err = pcall(provider.draw, game, {
        apiVersion = WORLD_HUD_OVERLAY_API_VERSION,
        fonts = fonts,
        viewW = viewW,
        viewH = viewH,
        colors = COLORS,
        drawPanel = drawPanel,
      })
      if not ok then
        provider.failed = true
        if worldHudOverlayLogError then
          worldHudOverlayLogError(provider.owner .. ": " .. tostring(err))
        end
      end
    end
  end
end

local function drawBattlePartyPips(party, x, y, direction)
  local g = love.graphics
  for i = 1, math.min(6, #(party or {})) do
    local mon = party[i]
    local px = x + (i - 1) * 14 * direction
    setColor(COLORS.ink)
    g.circle("fill", px, y, 5)
    if (tonumber(mon and mon.hp) or 0) <= 0 then
      setColor({ 0.40, 0.41, 0.40, 1 })
    elseif mon and mon.status then
      setColor({ 0.86, 0.52, 0.10, 1 })
    else
      setColor({ 0.82, 0.16, 0.11, 1 })
    end
    g.circle("fill", px, y, 3)
    setColor(COLORS.paper)
    g.rectangle("fill", px - 3, y - 1, 6, 2)
  end
end

local function battleMessageLines(battle)
  if battle and battle.current and battle.current.text then
    battle.__widescreenUiLastMessage = tostring(battle.current.text)
  end
  local text = tostring(battle and battle.__widescreenUiLastMessage or "")
  text = text:gsub("\v", "\n")
  local lines = {}
  for line in (text .. "\n"):gmatch("(.-)\n") do
    lines[#lines + 1] = cleanLabel(line)
  end
  return lines
end

local function drawBattleMessage(battle, fonts, viewW, viewH)
  local g = love.graphics
  local x, y, w, h = 8, viewH - 72, viewW - 16, 64
  drawPanel(x, y, w, h)
  g.setFont(fonts.small)
  setColor(COLORS.ink)
  local lines = battleMessageLines(battle)
  for i = 1, math.min(2, #lines) do
    g.print(fitLabel(fonts.small, lines[i], w - 48), x + 20, y + 10 + (i - 1) * 20)
  end
  if (battle.msgWaiting or battle.msgPrompt)
      and (tonumber(battle.frame) or 0) % 60 < 30 then
    setColor(COLORS.accent)
    g.polygon("fill", x + w - 25, y + h - 24,
              x + w - 13, y + h - 24, x + w - 19, y + h - 16)
  end
end

local function drawBattleChoiceCell(fonts, label, selected, x, y, w, h)
  local g = love.graphics
  setColor(selected and COLORS.selected or COLORS.paper2)
  g.rectangle("fill", x, y, w, h)
  if selected then
    setColor(COLORS.accent)
    g.rectangle("fill", x, y, 5, h)
  end
  g.setFont(fonts.small)
  setColor(selected and COLORS.selectedText or COLORS.ink)
  local text = fitLabel(fonts.small, label, w - 22)
  g.print(text, x + 12, y + math.floor((h - fonts.small:getHeight()) / 2))
end

local function drawBattleCommand(battle, fonts, viewW, viewH)
  local g = love.graphics
  local promptX, menuW, y, h = 8, 382, viewH - 72, 64
  local menuX = viewW - menuW - 8
  local promptW = menuX - promptX - 8
  drawPanel(promptX, y, promptW, h)
  drawPanel(menuX, y, menuW, h)

  if not battle.demo then
    g.setFont(fonts.small)
    setColor(COLORS.ink)
    if battle.safari then
      g.print("SAFARI ZONE", promptX + 16, y + 10)
      g.setFont(fonts.small)
      g.print("BALLS  " .. tostring(battle.safari.balls or 0),
              promptX + 16, y + 34)
    else
      g.print("What will", promptX + 16, y + 10)
      g.print(fitLabel(fonts.small, battleName(battle.player) .. " do?", promptW - 32),
              promptX + 16, y + 34)
    end
  end

  local labels = battle.safari and { "BALL", "BAIT", "ROCK", "RUN" }
    or { "FIGHT", "POKEMON", "BAG", "RUN" }
  local selected = tonumber(battle.menuIndex) or 1
  if battle.demo then
    labels = { "FIGHT", "POKEMON", "BAG", "RUN" }
    selected = (tonumber(battle.demoTimer) or 0) <= 80 and 1 or 3
  end
  local gap, pad = 4, 10
  local cellW = math.floor((menuW - pad * 2 - gap) / 2)
  local cellH = 21
  for i, label in ipairs(labels) do
    local col, row = (i - 1) % 2, math.floor((i - 1) / 2)
    drawBattleChoiceCell(fonts, label, i == selected,
      menuX + pad + col * (cellW + gap), y + 9 + row * (cellH + 4),
      cellW, cellH)
  end
end

local function battleMoveMaxPP(move, def)
  if move and move.maxPP then return tonumber(move.maxPP) or 0 end
  local base = tonumber(def and def.pp) or tonumber(move and move.pp) or 0
  return base + (tonumber(move and move.ppUps) or 0) * math.floor(base / 5)
end

local SNAPSHOT_POWER_KINDS = {
  base = true, status = true, fixed = true, special = true,
}
local SNAPSHOT_ACCURACY_KINDS = {
  percent = true, always = true, unavailable = true,
}

local function validateMoveInspectorSnapshot(value)
  if type(value) ~= "table" then return nil, "snapshot must be a table" end
  if value.schemaVersion ~= 1 then return nil, "unsupported snapshot schemaVersion" end
  if value.phase ~= "moveSelect" then return nil, "snapshot phase must be moveSelect" end
  if type(value.selectedIndex) ~= "number" then return nil, "selectedIndex must be numeric" end
  if type(value.moveId) ~= "string" or type(value.moveName) ~= "string" then
    return nil, "moveId and moveName must be strings"
  end
  if type(value.typeId) ~= "string" then return nil, "typeId must be a string" end
  if type(value.pp) ~= "table" or type(value.pp.current) ~= "number"
      or type(value.pp.maximum) ~= "number" then
    return nil, "pp.current and pp.maximum must be numeric"
  end
  if type(value.power) ~= "table" or not SNAPSHOT_POWER_KINDS[value.power.kind]
      or type(value.power.label) ~= "string" then
    return nil, "invalid power descriptor"
  end
  if type(value.accuracy) ~= "table"
      or not SNAPSHOT_ACCURACY_KINDS[value.accuracy.kind]
      or type(value.accuracy.label) ~= "string" then
    return nil, "invalid accuracy descriptor"
  end
  if type(value.matchup) ~= "table" or type(value.matchup.factor) ~= "number"
      or type(value.matchup.label) ~= "string"
      or type(value.matchup.multiplierLabel) ~= "string" then
    return nil, "invalid matchup descriptor"
  end
  if type(value.stab) ~= "table" or type(value.stab.applies) ~= "boolean" then
    return nil, "invalid STAB descriptor"
  end
  if type(value.disabled) ~= "boolean" then return nil, "disabled must be boolean" end
  return value
end

local function activeMoveInspectorSnapshot(battle)
  local provider = battleMoveInspectorProvider
  if not provider then return nil end
  local ok, value, reason = pcall(provider.snapshot, battle)
  if not ok then
    if battleMoveInspectorLogError then
      battleMoveInspectorLogError("provider exception: " .. tostring(value))
    end
    return nil
  end
  if value == nil then
    if reason and battleMoveInspectorLogError then
      battleMoveInspectorLogError("provider returned no snapshot: " .. tostring(reason))
    end
    return nil
  end
  local snapshot, invalid = validateMoveInspectorSnapshot(value)
  if not snapshot and battleMoveInspectorLogError then
    battleMoveInspectorLogError("invalid provider snapshot: " .. tostring(invalid))
  end
  return snapshot
end

local function drawBattleMoves(battle, fonts, moves, selected, allowInspector,
                               viewW, viewH)
  local g = love.graphics
  local x, y, w, h = 8, viewH - 116, viewW - 16, 108
  drawPanel(x, y, w, h)
  local detailW, gap = 150, 5
  local listX, listY, cellH = x + 12, y + 12, 38
  local detailX = x + w - detailW - 12
  local listW = detailX - listX - 18
  local cellW = math.floor((listW - gap) / 2)
  selected = clamp(tonumber(selected) or 1, 1, math.max(1, #(moves or {})))
  for i = 1, 4 do
    local move = moves and moves[i]
    local col, row = (i - 1) % 2, math.floor((i - 1) / 2)
    local cx, cy = listX + col * (cellW + gap), listY + row * (cellH + gap)
    local def = move and battle.data and battle.data.moves
      and battle.data.moves[move.id]
    local label = def and def.name or (move and move.id) or "-"
    drawBattleChoiceCell(fonts, label, i == selected, cx, cy, cellW, cellH)
    if battle.moveSwapIndex == i and i ~= selected then
      setColor(COLORS.accent)
      g.rectangle("line", cx + 2, cy + 2, cellW - 4, cellH - 4)
    end
  end

  local snapshot = allowInspector and activeMoveInspectorSnapshot(battle) or nil
  local move = moves and moves[selected]
  local def = move and battle.data and battle.data.moves
    and battle.data.moves[move.id]
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print(snapshot and "MOVE INSPECTOR" or "MOVE INFO", detailX, y + 8)
  if snapshot then
    drawTypeBadge(snapshot.typeId, fonts, detailX, y + 25, 132, 16)
    g.setFont(fonts.tiny)
    setColor(COLORS.ink)
    g.print("PP  " .. tostring(snapshot.pp.current) .. "/"
      .. tostring(snapshot.pp.maximum), detailX, y + 45)
    local stats = "POW " .. snapshot.power.label
      .. "  ACC " .. snapshot.accuracy.label
    g.print(fitLabel(fonts.tiny, stats, 150), detailX, y + 59)
    local matchup = snapshot.matchup.label .. " "
      .. snapshot.matchup.multiplierLabel
    g.print(fitLabel(fonts.tiny, matchup, 150), detailX, y + 73)
    local flags = {}
    if snapshot.stab.applies then flags[#flags + 1] = snapshot.stab.label or "STAB" end
    if snapshot.disabled then flags[#flags + 1] = "DISABLED" end
    if #flags > 0 then
      setColor(snapshot.disabled and COLORS.accent or COLORS.muted)
      g.print(table.concat(flags, "  "), detailX, y + 87)
    end
  elseif def then
    drawTypeBadge(def.type, fonts, detailX, y + 28, 132, 16)
    g.setFont(fonts.small)
    setColor(COLORS.ink)
    local pp = "PP  " .. tostring(move.pp or 0) .. "/" .. tostring(battleMoveMaxPP(move, def))
    g.print(pp, detailX, y + 51)
    if battle.player and battle.player.disabledSlot == selected then
      setColor(COLORS.accent)
      g.print("DISABLED", detailX, y + 72)
    end
  end
end

local function drawBattleHUD(battle, fonts, viewW, viewH)
  if not battle or battle.blankForAskName then return end
  local layout = { viewW = viewW, viewH = viewH }
  if battleEnemyVisible(battle) then
    layout.enemy = drawBattleStatusPanel(
      battle, battle.enemy, fonts, 12, 10, 190, 52, false)
  end
  if battlePlayerVisible(battle) then
    -- Alpha 8.2 docks this panel above the command area. Move selection uses a
    -- taller inspector surface, so lift it without changing arena ownership.
    local panelLift = (battle.phase == "moveSelect" or battle.phase == "mimicSelect")
      and 192 or 148
    drawBattleStatusPanel(battle, battle.player, fonts,
                          viewW - 198, viewH - panelLift, 190, 72, true)
  end
  if battle.introBalls then
    drawBattlePartyPips(battle.enemyParty, 94, 82, -1)
    drawBattlePartyPips(battle.playerParty
      or (battle.game and battle.game.save and battle.game.save.party),
      viewW - 94, viewH - 204, 1)
  elseif battle.showEnemyBalls then
    drawBattlePartyPips(battle.enemyParty, 94, 25, -1)
  end

  if battle.phase == "messages"
      and (battle.current or battle.animPlaying or battle.msgHold
        or battle.__widescreenUiLastMessage) then
    drawBattleMessage(battle, fonts, viewW, viewH)
  elseif battle.phase == "menu" then
    drawBattleCommand(battle, fonts, viewW, viewH)
  elseif battle.phase == "moveSelect" then
    drawBattleMoves(battle, fonts,
      battle.player and battle.player.curMoves, battle.moveIndex, true,
      viewW, viewH)
  elseif battle.phase == "mimicSelect" then
    drawBattleMoves(battle, fonts, battle.mimicMoves, battle.mimicIndex, false,
                    viewW, viewH)
  end
  if layout.enemy then drawBattleHudExtensions(battle, fonts, layout) end
end

local function wrapRenderedText(font, text, maxWidth)
  text = tostring(text or ""):gsub("\v", "\n"):gsub("\f", "\n")
  local lines = {}
  for paragraph in (text .. "\n"):gmatch("(.-)\n") do
    local line = ""
    for word in paragraph:gmatch("%S+") do
      local candidate = line == "" and word or (line .. " " .. word)
      if line ~= "" and font:getWidth(candidate) > maxWidth then
        lines[#lines + 1] = line
        line = word
      else
        line = candidate
      end
    end
    if line ~= "" then lines[#lines + 1] = line end
  end
  return lines
end

local function drawPokedexHeader(fonts, title, page)
  local g = love.graphics
  setColor({ COLORS.paper[1], COLORS.paper[2], COLORS.paper[3], 1 })
  g.rectangle("fill", 0, 0, DESIGN_W, DESIGN_H)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print(cleanLabel(title or "POKEDEX"), 20, 14)
  setColor(COLORS.accent)
  g.rectangle("fill", 184, 30, 270, 3)
  if page then
    g.setFont(fonts.small)
    setColor(COLORS.muted)
    g.print(page, DESIGN_W - 20 - fonts.small:getWidth(page), 17)
  end
end

local function drawPokedexList(state, fonts, model)
  local g = love.graphics
  local rows = model and model.rows or state.items or {}
  local index = tonumber(model and model.index or state.index) or 1
  local scroll = tonumber(model and model.scroll or state.scroll) or 0
  local title = model and model.title or state.title or "POKEDEX"
  drawPokedexHeader(fonts, title)
  local x, y, w, h = 20, 52, 600, 266
  drawPanel(x, y, w, h)
  local visible, rowH = 7, 34
  for row = 1, visible do
    local i = scroll + row
    local item = rows[i]
    if not item then break end
    local ry = y + 11 + (row - 1) * rowH
    local selected = i == index
    setColor(selected and COLORS.selected or COLORS.paper2)
    g.rectangle("fill", x + 10, ry, w - 20, rowH - 4)
    if selected then
      setColor(COLORS.accent)
      g.rectangle("fill", x + 10, ry, 5, rowH - 4)
    end
    g.setFont(fonts.small)
    setColor(selected and COLORS.selectedText or COLORS.ink)
    local label = cleanLabel(item.label or "")
    g.print(fitLabel(fonts.small, label, w - 150), x + 25, ry + 6)
    local value = item.value or item.right
    if value ~= nil and type(value) ~= "table" then
      local valueText = cleanLabel(value)
      g.print(valueText, x + w - 26 - fonts.small:getWidth(valueText), ry + 6)
    end
    if item.marker or item.ball then
      local bx, by = x + w - 112, ry + 14
      setColor(selected and COLORS.selectedText or COLORS.ink)
      g.circle("line", bx, by, 5)
      g.rectangle("fill", bx - 5, by - 1, 10, 2)
      g.circle("fill", bx, by, 2)
    end
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  local footer = model and model.footer or state.footer
  if type(footer) == "table" then footer = table.concat(footer, "     ") end
  footer = cleanLabel(footer or "A OPEN     B BACK")
  g.print(fitLabel(fonts.tiny, footer, DESIGN_W - 40), 20, 334)
end

local function drawWithPalette(image, palette, drawFn, keyed)
  local g = love.graphics
  local applied = false
  local shaderFactory = keyed and PaletteFX and PaletteFX.keyedShader
    or PaletteFX and PaletteFX.shader
  if palette and type(shaderFactory) == "function"
      and type(PaletteFX.sendColors) == "function"
      and type(g.setShader) == "function" then
    local okShader, shader = pcall(shaderFactory)
    if okShader and shader then
      local ok = pcall(PaletteFX.sendColors, shader, palette)
      if ok then
        g.setShader(shader)
        applied = true
      end
    end
  end
  drawFn()
  if applied then g.setShader() end
end

local function drawPokedexEntry(state, fonts)
  local g = love.graphics
  local def = state.def or {}
  local game = state.game or {}
  local entry = def.dexEntry or {}
  local digits = game.data and game.data.constants
    and game.data.constants.dexDigits or 3
  drawPokedexHeader(fonts, "POKEMON DATA")
  drawPanel(20, 52, 228, 266)
  drawPanel(260, 52, 360, 266)

  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print(fitLabel(fonts.body, def.name or "UNKNOWN", 196), 36, 68)
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print(("No.%0" .. tostring(digits) .. "d"):format(def.dex or 0), 36, 96)
  if state.sprite and type(state.sprite.getDimensions) == "function" then
    local sw, sh = state.sprite:getDimensions()
    if sw > 0 and sh > 0 then
      local scale = math.min(176 / sw, 156 / sh)
      local dx = 134 - sw * scale / 2
      local dy = 202 - sh * scale / 2
      if state.sprite.setFilter then pcall(state.sprite.setFilter, state.sprite, "nearest", "nearest") end
      setColor({ 1, 1, 1, 1 })
      local palette = PaletteFX and PaletteFX.monPal
        and PaletteFX.monPal(game.data, def.id) or nil
      drawWithPalette(state.sprite, palette, function()
        g.draw(state.sprite, math.floor(dx), math.floor(dy), 0, scale, scale)
      end)
    end
  end

  g.setFont(fonts.small)
  setColor(COLORS.ink)
  g.print(fitLabel(fonts.small, entry.kind or "UNKNOWN", 320), 278, 72)
  local owned = state.forceOwned or (game.save and game.save.pokedex
    and game.save.pokedex.owned and game.save.pokedex.owned[def.id])
  if owned and entry.heightFt then
    local height = entry.heightM and string.format("HEIGHT  %.1fm", entry.heightM)
      or string.format("HEIGHT  %d'%02d\"", entry.heightFt, entry.heightIn or 0)
    local weight = entry.weightKg and string.format("WEIGHT  %.1fkg", entry.weightKg)
      or string.format("WEIGHT  %.1flb", (entry.weight or 0) / 10)
    g.print(height, 278, 102)
    g.print(weight, 278, 124)
  end
  local text = owned and entry.text and game.data and game.data.text
    and game.data.text[entry.text] or "DATA UNKNOWN."
  local lines = wrapRenderedText(fonts.small, text, 322)
  for i = 1, math.min(7, #lines) do
    g.print(lines[i], 278, 160 + (i - 1) * 20)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  g.print("A / B  BACK", 20, 334)
end

local function drawImageContained(image, x, y, w, h, maxScale, palette, keyed)
  if not (image and type(image.getDimensions) == "function") then return end
  local iw, ih = image:getDimensions()
  if iw <= 0 or ih <= 0 then return end
  local scale = math.min(w / iw, h / ih, maxScale or math.huge)
  if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
  setColor({ 1, 1, 1, 1 })
  drawWithPalette(image, palette, function()
    love.graphics.draw(image,
      math.floor(x + (w - iw * scale) / 2),
      math.floor(y + (h - ih * scale) / 2), 0, scale, scale)
  end, keyed)
end

local function drawImageGrounded(image, x, bottom, w, h, maxScale, palette, keyed)
  if not (image and type(image.getDimensions) == "function") then return end
  local iw, ih = image:getDimensions()
  if iw <= 0 or ih <= 0 then return end
  local scale = math.min(w / iw, h / ih, maxScale or math.huge)
  if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
  setColor({ 1, 1, 1, 1 })
  drawWithPalette(image, palette, function()
    love.graphics.draw(image, math.floor(x + (w - iw * scale) / 2),
      math.floor(bottom - ih * scale), 0, scale, scale)
  end, keyed)
end

-- TitleState's ribbon image is an 80x8 source strip. Blue uses its first
-- 64 pixels; Red composes pixels 0..15 and 40..79 with an eight-pixel gap.
-- Drawing the whole source exposed unused white canvas and shifted the label.
local function drawTitleVersion(title, x, y, w, h, palette)
  local image = title and title.version
  if not (image and type(image.getDimensions) == "function") then return end
  local iw, ih = image:getDimensions()
  if iw <= 0 or ih < 8 then return end
  local logicalW = 64
  local scale = math.min(w / logicalW, h / 8, 4)
  local dx = math.floor(x + (w - logicalW * scale) / 2)
  local dy = math.floor(y + (h - 8 * scale) / 2)
  if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
  setColor({ 1, 1, 1, 1 })
  drawWithPalette(image, palette, function()
    if title.blue then
      local q = love.graphics.newQuad(0, 0, math.min(64, iw), 8, iw, ih)
      love.graphics.draw(image, q, dx, dy, 0, scale, scale)
    else
      local leftW = math.min(16, iw)
      local rightX, rightW = 40, math.max(0, math.min(40, iw - 40))
      if leftW > 0 then
        love.graphics.draw(image,
          love.graphics.newQuad(0, 0, leftW, 8, iw, ih), dx, dy, 0, scale, scale)
      end
      if rightW > 0 then
        love.graphics.draw(image,
          love.graphics.newQuad(rightX, 0, rightW, 8, iw, ih),
          dx + 24 * scale, dy, 0, scale, scale)
      end
    end
  end, true)
end

local TITLE_CYCLE_SECONDS = 4
local TITLE_SLIDE_SECONDS = 0.55

local function titleSpriteAt(title, index, species)
  local original = title.cycleIndex
  title.cycleIndex = index
  local ok, image, trueColor = pcall(title.currentSprite, title)
  title.cycleIndex = original
  return {
    image = ok and image or nil,
    species = species[index],
    trueColor = ok and trueColor or false,
  }
end

local function titlePresentationSprites(title)
  if not (title and type(title.currentSprite) == "function") then return nil end
  local species = title.cycleSpecies or {}
  if #species <= 1 then
    local ok, image, trueColor = pcall(title.currentSprite, title)
    return {
      current = { image = ok and image or nil, species = species[1],
                  trueColor = ok and trueColor or false },
      progress = 1,
    }
  end
  local now = love.timer and love.timer.getTime and love.timer.getTime() or 0
  local cycle = titlePresentationCycles[title]
  if not cycle then
    local initial = clamp(tonumber(title.cycleIndex) or 1, 1, #species)
    cycle = { index = initial, nativeIndex = initial, changedAt = now }
    titlePresentationCycles[title] = cycle
  end

  -- TitleState keeps its original random cycle while it is topmost. Track
  -- that change and animate toward it. When a menu covers TitleState and its
  -- update pauses, continue cycling every four seconds without consuming RNG.
  local nativeIndex = clamp(tonumber(title.cycleIndex) or cycle.nativeIndex,
                            1, #species)
  if nativeIndex ~= cycle.nativeIndex then
    cycle.previousIndex = cycle.index
    cycle.index = nativeIndex
    cycle.nativeIndex = nativeIndex
    cycle.transitionAt = now
    cycle.changedAt = now
  elseif now - cycle.changedAt >= TITLE_CYCLE_SECONDS then
    local steps = math.max(1,
      math.floor((now - cycle.changedAt) / TITLE_CYCLE_SECONDS))
    cycle.previousIndex = cycle.index
    cycle.index = ((cycle.index - 1 + steps) % #species) + 1
    cycle.transitionAt = now
    cycle.changedAt = cycle.changedAt + steps * TITLE_CYCLE_SECONDS
  end

  local progress = 1
  if cycle.transitionAt then
    progress = clamp((now - cycle.transitionAt) / TITLE_SLIDE_SECONDS, 0, 1)
    if progress >= 1 then
      cycle.previousIndex = nil
      cycle.transitionAt = nil
    end
  end
  return {
    current = titleSpriteAt(title, cycle.index, species),
    previous = cycle.previousIndex
      and titleSpriteAt(title, cycle.previousIndex, species) or nil,
    progress = progress,
  }
end

local function drawTitleBackdrop(title, fonts, viewW, viewH)
  local g = love.graphics
  setColor({ COLORS.paper[1], COLORS.paper[2], COLORS.paper[3], 1 })
  g.rectangle("fill", 0, 0, viewW, viewH)
  setColor(COLORS.accent)
  g.rectangle("fill", 0, 0, viewW, 6)
  local data = title and title.game and title.game.data
  local logoPal = PaletteFX and PaletteFX.pal and PaletteFX.pal(data, "LOGO2")
  local versionPal = PaletteFX and PaletteFX.pal and PaletteFX.pal(data, "LOGO1")
  local actorPal = PaletteFX and PaletteFX.pal and PaletteFX.pal(data, "MEWMON")
  -- The title card owns the full upper band. This keeps it large at 4:3 and
  -- 16:9 while leaving the lower-left region available for the menu panel.
  local logoW = math.min(460, viewW - 56)
  local logoX = math.floor((viewW - logoW) / 2)
  drawImageContained(title and title.logo, logoX, 14, logoW, 104, 4,
                     logoPal, true)
  if title and title.version and not title.yellow then
    drawTitleVersion(title, math.floor((viewW - 196) / 2), 116, 196, 28,
                     versionPal)
  end
  local artX, artW = math.floor(viewW * 0.49), math.floor(viewW * 0.47)
  local ground = viewH - 38
  if title and title.yellowLayout then
    drawImageGrounded(title.yellowPikachu, artX + 24, ground, artW - 48,
                      viewH - 158, 3, actorPal, true)
  elseif title then
    local presentation = titlePresentationSprites(title)
    local slotW = math.floor(artW * 0.50)
    local slideSpan = slotW + 12
    local function drawMon(item, x)
      if not item then return end
      local monPal = item.species and PaletteFX and PaletteFX.monPal
        and PaletteFX.monPal(data, item.species) or actorPal
      if item.trueColor then monPal = nil end
      drawImageGrounded(item.image, x, ground, slotW, viewH - 158, 3,
                        monPal, not item.trueColor)
    end
    if presentation then
      local progress = presentation.progress or 1
      if presentation.previous and progress < 1 then
        drawMon(presentation.previous, artX - progress * slideSpan)
        drawMon(presentation.current, artX + (1 - progress) * slideSpan)
      else
        drawMon(presentation.current, artX)
      end
    end
    drawImageGrounded(title.player, artX + math.floor(artW * 0.50), ground,
                      math.floor(artW * 0.50), viewH - 154, 3, actorPal, true)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  local copyright = title and title.title and title.title.copyrightText
    or "2026 BOIS CLUB GAMES"
  g.print(cleanLabel(copyright), viewW - 20 - fonts.tiny:getWidth(cleanLabel(copyright)),
          viewH - 22)
end

local function drawTitleStandby(title, fonts, viewW, viewH)
  drawTitleBackdrop(title, fonts, viewW, viewH)
  local g = love.graphics
  g.setFont(fonts.small)
  setColor(COLORS.ink)
  local prompt = "PRESS START"
  local x = 24
  g.print(prompt, x, viewH - 54)
  setColor(COLORS.accent)
  g.rectangle("fill", x, viewH - 34, fonts.small:getWidth(prompt), 3)
end

local function drawTitleMenu(title, menu, fonts, viewW, viewH)
  local g = love.graphics
  drawTitleBackdrop(title, fonts, viewW, viewH)
  local items = menu.items or {}
  local panelW = math.min(300, math.floor(viewW * 0.47))
  local rowH = #items > 5 and 30 or 36
  local panelH = math.min(viewH - 36, 78 + #items * rowH)
  local x = 20
  local y = math.max(126, math.floor((viewH - panelH + 90) / 2))
  y = math.min(y, viewH - panelH - 12)
  drawPanel(x, y, panelW, panelH)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print("MAIN MENU", x + 18, y + 16)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 142, y + 29, panelW - 164, 3)
  local firstY = y + 54
  local selected = tonumber(menu.index) or 1
  for i, item in ipairs(items) do
    local ry = firstY + (i - 1) * rowH
    local isSelected = i == selected
    setColor(isSelected and COLORS.selected or COLORS.paper2)
    g.rectangle("fill", x + 12, ry, panelW - 24, rowH - 5)
    if isSelected then
      setColor(COLORS.accent)
      g.rectangle("fill", x + 12, ry, 5, rowH - 5)
    end
    g.setFont(fonts.body)
    setColor(isSelected and COLORS.selectedText or COLORS.ink)
    g.print(fitLabel(fonts.body, cleanLabel(item.label or ""), panelW - 58),
            x + 28, ry + math.floor((rowH - 5 - fonts.body:getHeight()) / 2))
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  g.print("A SELECT", x + 18, y + panelH - 24)
end

local function drawContinueInfo(title, info, fonts, viewW, viewH)
  local g = love.graphics
  drawTitleBackdrop(title, fonts, viewW, viewH)
  local save = info.save or {}
  local badges = 0
  local okBadges, Badges = pcall(require, "src.inventory.Badges")
  if okBadges and Badges and type(Badges.count) == "function" then
    local ok, count = pcall(Badges.count, info.game and info.game.data, save)
    if ok then badges = tonumber(count) or 0 end
  end
  local owned = 0
  for _ in pairs(save.pokedex and save.pokedex.owned or {}) do owned = owned + 1 end
  local seconds = math.floor(tonumber(save.playTime) or 0)
  local rows = {
    { "PLAYER", save.player and save.player.name or "RED" },
    { "BADGES", tostring(badges) },
    { "POKEDEX", tostring(owned) },
    { "TIME", ("%d:%02d"):format(math.floor(seconds / 3600),
                                    math.floor(seconds / 60) % 60) },
  }
  local w, h = math.min(390, viewW - 40), 260
  local x, y = 24, math.floor((viewH - h) / 2)
  drawPanel(x, y, w, h)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print("CONTINUE", x + 18, y + 16)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 132, y + 29, w - 154, 3)
  for i, row in ipairs(rows) do
    local ry = y + 58 + (i - 1) * 38
    setColor(COLORS.paper2)
    g.rectangle("fill", x + 14, ry, w - 28, 30)
    g.setFont(fonts.small)
    setColor(COLORS.muted)
    g.print(row[1], x + 26, ry + 7)
    setColor(COLORS.ink)
    g.print(row[2], x + w - 26 - fonts.small:getWidth(row[2]), ry + 7)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  g.print("A CONTINUE     B BACK", x + 18, y + h - 24)
end

local function loadReportPresentationLines(state, fonts, maxWidth)
  local report = state.report or {}
  local out = {}
  local function add(text)
    for _, line in ipairs(wrapRenderedText(fonts.small, text, maxWidth)) do
      out[#out + 1] = line
    end
  end
  local function section(title, rows)
    if #rows == 0 then return end
    if #out > 0 then out[#out + 1] = "" end
    out[#out + 1] = title
    for _, row in ipairs(rows) do add("  " .. row) end
  end
  if report.recovered then add("SAVE RECOVERED FROM ." .. tostring(report.recovered)
    .. " BACKUP COPY") end
  local rows = {}
  for _, mon in ipairs(report.lostMons or {}) do
    rows[#rows + 1] = tostring(mon.species or "?") .. " ("
      .. tostring(mon.from or "?") .. ")"
  end
  section("MOVED TO LOST BOX", rows)
  rows = {}
  for _, item in ipairs(report.lostItems or {}) do
    rows[#rows + 1] = tostring(item.id or "?") .. " x"
      .. tostring(item.count or 1)
  end
  section("ITEMS REMOVED", rows)
  rows = {}
  for _, map in ipairs(report.remappedMaps or {}) do
    rows[#rows + 1] = tostring(map.id or "?") .. "  ->  "
      .. tostring(map.to or map.field or "?")
  end
  section("LOCATION RESET", rows)
  rows = {}
  for _, mon in ipairs(report.restoredMons or {}) do
    rows[#rows + 1] = tostring(mon.species or "?") .. " TO BOX "
      .. tostring(mon.box or 0)
  end
  for _, item in ipairs(report.restoredItems or {}) do
    rows[#rows + 1] = tostring(item.id or "?") .. " x"
      .. tostring(item.count or 1)
  end
  section("RESTORED", rows)
  local okSave, SaveData = pcall(require, "src.core.SaveData")
  if okSave and SaveData and type(SaveData.modsDiffNotice) == "function" then
    local ok, notice = pcall(SaveData.modsDiffNotice, report.modsDiff,
      state.game and state.game.save and state.game.save.meta)
    if ok and notice then
      -- SaveData deliberately exposes a compact one-line notice. The wide
      -- report is a reading surface, so promote every semicolon/comma clause
      -- to an independent row instead of wrapping mid-sentence.
      local noticeRows = {}
      for row in tostring(notice):gmatch("[^;,]+") do
        row = row:match("^%s*(.-)%s*$")
        if row ~= "" then noticeRows[#noticeRows + 1] = row end
      end
      section("MOD CONFIGURATION", noticeRows)
    end
  elseif #out == 0 and type(state.lines) == "table" then
    for _, line in ipairs(state.lines) do out[#out + 1] = line end
  end
  if #out == 0 then out[1] = "NO LOAD CHANGES REPORTED" end
  return out
end

local function drawLoadReport(state, fonts, viewW, viewH)
  local g = love.graphics
  setColor({ COLORS.paper[1], COLORS.paper[2], COLORS.paper[3], 1 })
  g.rectangle("fill", 0, 0, viewW, viewH)
  local x, y, w, h = 18, 18, viewW - 36, viewH - 36
  drawPanel(x, y, w, h)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print("LOAD REPORT", x + 18, y + 16)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 166, y + 29, w - 188, 3)
  local lines = loadReportPresentationLines(state, fonts, w - 52)
  local visible = math.max(1, math.floor((h - 94) / 20))
  local offset = clamp(tonumber(state.offset) or 0, 0, math.max(0, #lines - visible))
  g.setFont(fonts.small)
  for row = 1, visible do
    local line = lines[offset + row]
    if not line then break end
    setColor(line ~= "" and COLORS.ink or COLORS.muted)
    g.print(fitLabel(fonts.small, cleanLabel(line), w - 52),
            x + 24, y + 54 + (row - 1) * 20)
  end
  if offset + visible < #lines then
    setColor(COLORS.accent)
    g.polygon("fill", x + w - 34, y + h - 32,
      x + w - 18, y + h - 32, x + w - 26, y + h - 22)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  local position = ("%d / %d"):format(math.min(#lines, offset + 1), #lines)
  g.print("UP / DOWN  SCROLL     A / B / START  CONTINUE", x + 20, y + h - 25)
  g.print(position, x + w - 20 - fonts.tiny:getWidth(position), y + h - 25)
end

local function bundledPartyIcon(mod, mon, selected, counter)
  if not (Assets and love and love.graphics and mon and mon.species) then
    return nil
  end
  local species = tostring(mon.species):upper():gsub("[^A-Z0-9]", "")
  local dex = PARTY_ICON_DEX[species]
  if not dex then return nil end
  local path = mod.assets:path("party_icons.png")
  local cached = partyIconSheetCache[path]
  if cached == nil then
    local ok, image = pcall(Assets.image, path)
    if ok and image and type(image.getDimensions) == "function" then
      local iw, ih = image:getDimensions()
      if iw == 512 and ih == 640 then
        if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
        if image.setWrap then pcall(image.setWrap, image, "clamp", "clamp") end
        cached = { image = image, iw = iw, ih = ih, quads = {} }
      end
    end
    cached = cached or false
    partyIconSheetCache[path] = cached
  end
  if cached == false then return nil end

  local maxHP = mon.stats and mon.stats.hp or 1
  local hp = mon.hp or maxHP
  local pixels = math.floor(hp * 48 / math.max(1, maxHP))
  local speed = pixels >= 27 and 10 or pixels >= 10 and 20 or 32
  local alternate = math.floor((counter or 0) / speed) % 2 == 1
  local frame = alternate and 2 or 1
  local key = dex * 2 + frame
  local quad = cached.quads[key]
  if not quad then
    local zero = dex - 1
    local x = (zero % 16) * 32
    local y = math.floor(zero / 16) * 64 + (frame - 1) * 32
    quad = love.graphics.newQuad(x, y, 32, 32, cached.iw, cached.ih)
    cached.quads[key] = quad
  end
  return cached.image, quad
end

local function nativePartyIcon(game, mon, selected, counter)
  if not (Assets and love and love.graphics and mon and mon.species) then
    return nil
  end
  local icons = game and game.data and game.data.icons
  local entry = icons and icons.bySpecies and icons.bySpecies[mon.species]
  local path
  if type(entry) == "table" then
    local shiny = ShinyArtResolver and ShinyArtResolver(mon)
    if shiny == nil then
      shiny = mon.shiny == true
        or (Stats and Stats.isShiny and Stats.isShiny(mon.dvs))
    end
    path = shiny and entry.shinyImage or entry.image
  end
  if type(path) ~= "string" or path == "" then return nil end

  local cached = partyIconSheetCache[path]
  if cached == nil then
    local ok, image = pcall(Assets.image, path)
    if ok and image and type(image.getDimensions) == "function" then
      local iw, ih = image:getDimensions()
      if iw == 32 and ih == 64 then
        if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
        if image.setWrap then pcall(image.setWrap, image, "clamp", "clamp") end
        cached = {
          image = image,
          quads = {
            love.graphics.newQuad(0, 0, 32, 32, iw, ih),
            love.graphics.newQuad(0, 32, 32, 32, iw, ih),
          },
        }
      end
    end
    cached = cached or false
    partyIconSheetCache[path] = cached
  end
  if cached == false then return nil end

  local alternate = false
  if selected then
    local maxHP = mon.stats and mon.stats.hp or 1
    local hp = mon.hp or maxHP
    local pixels = math.floor(hp * 48 / math.max(1, maxHP))
    local speed = pixels >= 27 and 5 or pixels >= 10 and 16 or 32
    alternate = math.floor((counter or 0) / speed) % 2 == 1
  end
  return cached.image, cached.quads[alternate and 2 or 1]
end

local function drawPartyIcon(mod, PartyMenu, menu, mon, x, y, selected)
  local g = love.graphics
  g.push("all")
  setColor({ 1, 1, 1, 1 })
  -- Prefer the currently registered 32x64 icon descriptor. This lets a
  -- focused icon provider (such as hgss_menu_icons) own the artwork while
  -- retaining the widescreen atlas as a no-dependency fallback.
  local image, quad = nativePartyIcon(menu.game, mon, selected, menu.blink or 0)
  if not image then
    image, quad = bundledPartyIcon(mod, mon, selected, menu.blink or 0)
  end
  if image and quad then
    -- Modern icon packs author 32x32 frames. Drawing them directly on this
    -- 640x360 surface avoids the stock 32 -> 16 -> output-size round trip.
    g.draw(image, quad, x, y)
    if PaletteFX and type(PaletteFX.markTrueColor) == "function" then
      PaletteFX.markTrueColor(x, y, 32, 32)
    end
  else
    g.translate(x, y)
    g.scale(2, 2)
    PartyMenu.drawIcon(menu.game, mon, 0, 0, selected, menu.blink or 0)
  end
  g.pop()
end

local function partyBattlePaletteKey(data, species)
  if not PaletteFX then return "none", nil end
  local colors = PaletteFX.monPal(data, species)
  if not colors then return "none", nil end
  local name = PaletteFX.monPalName(data, species) or "MON"
  if PaletteFX.usesGbcPack and PaletteFX.usesGbcPack() then
    name = "redpp:" .. name
  end
  return name, colors
end

-- This follows the same live resolver used by battle presentation. The path
-- is deliberately resolved every frame: an enabled sprite mod may select a
-- different generated variant while the game is running, and caching the
-- resolver result would pin this panel to stale art.
local function engineBattleSpriteImage(game, mon)
  if not (PokemonSprites and Assets and game and game.data
      and mon and mon.species) then return nil end

  local path, trueColor = PokemonSprites.path(
    game.data, mon.species, "front", { mon = mon, kind = "battle" })
  if not path then return nil end

  local palName, colors = partyBattlePaletteKey(game.data, mon.species)
  local key = path .. "|" .. (trueColor and "truecolor" or palName)
  local cached = partyBattleSpriteCache[key]
  if cached then return cached end

  local image
  if trueColor or not colors or not (love.image and love.image.newImageData) then
    image = Assets.image(path)
  else
    local id = Assets.imageData(path)
    if id then
      id:mapPixel(function(_, _, r, green, blue, alpha)
        if alpha == 0 then return r, green, blue, alpha end
        local color = r > 0.83 and colors[1]
          or r > 0.50 and colors[2]
          or r > 0.17 and colors[3]
          or colors[4]
        return color[1] / 255, color[2] / 255, color[3] / 255, alpha
      end)
      image = love.graphics.newImage(id)
    end
  end

  if image and image.setFilter then
    image:setFilter("nearest", "nearest")
  end
  partyBattleSpriteCache[key] = image
  return image
end

local battleArtPreview = setmetatable({}, { __mode = "k" })

local function battleArtModules(game)
  local exports = game and game.mods and game.mods.exports
  local handle = exports and exports.BATTLE_ART_VOXEL_FORK
  local lib = handle and handle.lib
  if not (lib and type(lib.require) == "function") then return nil end
  local okArt, art = pcall(lib.require, "BattleArt")
  if not (okArt and art) then return nil end
  local okAnimated, animated = pcall(lib.require, "AnimatedBattleArt")
  return art, okAnimated and animated or nil, handle
end

-- BATTLE_ART_VOXEL_FORK applies its STATIC/ANIMATED images directly to the
-- battler after the engine's pokemon.sprite resolver has run. Consult its
-- exported modules first so Party sees the same selected collection. ROM and
-- missing-pack cases fall back to the normal engine resolver.
local function selectedBattleSpriteImage(game, mon)
  if ShinyArtResolver and ShinyArtResolver(mon)
      and type(ShinyBattleImage) == "function" then
    local ok, image = pcall(ShinyBattleImage, game, mon, "front")
    if ok and image then return image, nil end
  end
  local fallback = engineBattleSpriteImage(game, mon)
  local art, animated, handle = battleArtModules(game)
  if not art then return fallback, nil end

  local okMode, mode = pcall(art.setting.get, art.setting)
  if not okMode or mode == "rom" then return fallback, nil end

  if mode == "static" then
    local ok, image = pcall(art.image, mon.species, "front")
    if ok and image then
      local metric = type(art.metrics) == "function" and art.metrics(image)
      return image, metric
    end
    return fallback, nil
  end

  if mode == "animated" and animated
      and type(animated.update) == "function" then
    local preview = battleArtPreview[mon]
    if not preview or preview.handle ~= handle or preview.fallback ~= fallback then
      if preview and type(animated.finish) == "function" then
        pcall(animated.finish, preview.battle)
      end
      local battler = { mon = mon, sprite = fallback }
      preview = {
        handle = handle,
        fallback = fallback,
        battler = battler,
        battle = { enemy = battler },
        lastTime = nil,
      }
      battleArtPreview[mon] = preview
    end
    local now = love.timer and love.timer.getTime and love.timer.getTime()
                or os.clock()
    local dt = preview.lastTime and clamp(now - preview.lastTime, 0, 0.10) or 0
    preview.lastTime = now
    -- AnimatedBattleArt owns atlas cells and durations; advancing its preview
    -- battler makes UI portraits obey the same selected generation and timing
    -- without treating Dramatic Shape's Stadium models as 2D images.
    local ok = pcall(animated.update, preview.battle, dt)
    local image = ok and preview.battler.sprite or nil
    if image and image ~= fallback then
      local metric = type(art.metrics) == "function" and art.metrics(image)
      return image, metric
    end
  end

  return fallback, nil
end

local function drawPartyBattleSprite(game, mon, x, y, w, h, overscan)
  local image, metric = selectedBattleSpriteImage(game, mon)
  if not image then return false end
  local iw, ih = image:getDimensions()
  if not iw or not ih or iw <= 0 or ih <= 0 then return false end

  local sourceX, sourceY, frameW, frameH = 0, 0, iw, ih
  if metric and metric.x0 and metric.x1 and metric.y0 and metric.y1 then
    sourceX, sourceY = metric.x0, metric.y0
    frameW = metric.x1 - metric.x0 + 1
    frameH = metric.y1 - metric.y0 + 1
  elseif iw >= ih * 2 and iw % ih == 0 then
    frameW = ih
  elseif ih >= iw * 2 and ih % iw == 0 then
    frameH = iw
  end
  local scale = math.min(w / frameW, h / frameH)
  -- Wide silhouettes naturally look much shorter when fitted only by width.
  -- The compact Party panel may opt into a small bounded boost, aiming for
  -- three quarters of its portrait height while allowing at most the supplied
  -- overscan. This covers Kadabra and the same issue in Golbat, Geodude,
  -- Goldeen, Aerodactyl, Zubat, etc. without per-species exceptions.
  overscan = math.max(1, tonumber(overscan) or 1)
  if overscan > 1 then
    local shownHeight = frameH * scale
    local targetHeight = h * 0.75
    local boost = shownHeight > 0 and targetHeight / shownHeight or 1
    scale = scale * clamp(boost, 1, overscan)
  end
  if scale <= 0 then return false end
  local dx = math.floor(x + (w - frameW * scale) / 2 + 0.5)
  local dy = math.floor(y + (h - frameH * scale) / 2 + 0.5)

  setColor({ 1, 1, 1, 1 })
  if sourceX ~= 0 or sourceY ~= 0 or frameW ~= iw or frameH ~= ih then
    local quad = love.graphics.newQuad(sourceX, sourceY,
                                      frameW, frameH, iw, ih)
    love.graphics.draw(image, quad, dx, dy, 0, scale, scale)
  else
    love.graphics.draw(image, dx, dy, 0, scale, scale)
  end
  return true
end

local function canLearnTM(menu, mon)
  if not (menu.tmhm and mon) then return nil end
  local def = monDefinition(menu.game, mon)
  for _, moveId in ipairs((def and def.tmhm) or {}) do
    if moveId == menu.tmhm.move then return true end
  end
  return false
end

local function drawPartyRows(mod, menu, PartyMenu, fonts, x, y, w)
  local g = love.graphics
  local party = menu.party or (menu.game.save and menu.game.save.party) or {}
  local rowH = 44

  -- Decorations first, labels second. This keeps selection fills from ever
  -- painting over glyphs, matching the START menu's overlap fix.
  for i = 1, math.min(6, #party) do
    local ry = y + (i - 1) * rowH
    setColor(i == menu.index and COLORS.selected or COLORS.paper2)
    g.rectangle("fill", x, ry, w, rowH - 3)
    if i == menu.index then
      setColor(COLORS.accent)
      g.rectangle("fill", x, ry, 5, rowH - 3)
    end
  end

  g.setFont(fonts.body)
  for i = 1, math.min(6, #party) do
    local mon = party[i]
    local ry = y + (i - 1) * rowH
    local selected = i == menu.index
    local maxHP = math.max(1, mon.stats and mon.stats.hp or 1)
    local hp = shownHP(menu, mon)
    drawPartyIcon(mod, PartyMenu, menu, mon, x + 9, ry + 4, selected)

    setColor(selected and COLORS.selectedText or COLORS.ink)
    g.print(monName(menu.game, mon), x + 49, ry + 4)
    local level = "Lv." .. tostring(mon.level or "?")
    g.print(level, x + w - 10 - fonts.body:getWidth(level), ry + 4)

    g.setFont(fonts.small)
    local able = canLearnTM(menu, mon)
    if able ~= nil then
      local label = able and "ABLE" or "NOT ABLE"
      setColor(able and { 0.12, 0.55, 0.23, 1 }
                       or { 0.70, 0.16, 0.12, 1 })
      g.print(label, x + 49, ry + 24)
    else
      setColor(selected and COLORS.selectedText or COLORS.muted)
      g.print("HP", x + 49, ry + 24)
      drawHPBar(x + 72, ry + 28, 112, hp, maxHP)
      setColor(selected and COLORS.selectedText or COLORS.ink)
      local hpText = string.format("%d/%d", hp, maxHP)
      g.print(hpText, x + w - 10 - fonts.small:getWidth(hpText), ry + 22)
    end
    g.setFont(fonts.body)
  end
end

local function updateSubmenuScroll(menu, visible)
  local count = #(menu.subItems or {})
  local index = clamp(tonumber(menu.subIndex) or 1, 1, math.max(1, count))
  local maxScroll = math.max(0, count - visible)
  local scroll = clamp(tonumber(menu.__wideUiSubScroll) or 0, 0, maxScroll)
  if index <= scroll then
    scroll = index - 1
  elseif index > scroll + visible then
    scroll = index - visible
  end
  menu.__wideUiSubScroll = clamp(scroll, 0, maxScroll)
  return menu.__wideUiSubScroll
end

local function statValue(mon, ...)
  local stats = mon and mon.stats or {}
  for i = 1, select("#", ...) do
    local value = stats[select(i, ...)]
    if value ~= nil then return tostring(math.floor(value)) end
  end
  return "-"
end

local function drawPartySidePanel(menu, fonts, x, y, w, h)
  local g = love.graphics
  drawPanel(x, y, w, h)
  g.setFont(fonts.title)
  setColor(COLORS.ink)
  g.print(menu.submenu and "ACTIONS" or "DETAILS", x + 14, y + 12)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 102, y + 21, w - 118, 3)

  if menu.submenu and menu.subItems then
    local rowH, listY = 24, y + 43
    local visible = math.max(1, math.floor((h - 56) / rowH))
    local scroll = updateSubmenuScroll(menu, visible)

    -- Background pass.
    for slot = 1, visible do
      local index = scroll + slot
      if not menu.subItems[index] then break end
      if index == menu.subIndex then
        local ry = listY + (slot - 1) * rowH
        setColor(COLORS.selected)
        g.rectangle("fill", x + 9, ry, w - 18, rowH - 2)
        setColor(COLORS.accent)
        g.rectangle("fill", x + 9, ry, 4, rowH - 2)
      end
    end

    -- Label pass.
    g.setFont(fonts.body)
    local offset = math.floor((rowH - fonts.body:getHeight()) / 2)
    for slot = 1, visible do
      local index = scroll + slot
      local entry = menu.subItems[index]
      if not entry then break end
      local ry = listY + (slot - 1) * rowH
      setColor(index == menu.subIndex and COLORS.selectedText or COLORS.ink)
      g.print(cleanLabel(entry.label), x + 21, ry + offset)
    end

    if scroll > 0 or scroll + visible < #menu.subItems then
      g.setFont(fonts.small)
      setColor(COLORS.muted)
      g.print("MORE", x + w - 52, y + h - 20)
    end
    return
  end

  local party = menu.party or (menu.game.save and menu.game.save.party) or {}
  local mon = party[clamp(menu.index or 1, 1, math.max(1, #party))]
  if not mon then return end
  local maxHP = math.max(1, mon.stats and mon.stats.hp or 1)
  local hp = shownHP(menu, mon)
  local name = monName(menu.game, mon)
  local nameWidth = w - 86
  local nameFont = fonts.body
  if fonts.body:getWidth(name) > nameWidth then nameFont = fonts.small end
  g.setFont(nameFont)
  setColor(COLORS.ink)
  g.print(name, x + 14, y + 39)

  -- Free-standing active battle portrait. No frame is drawn around it; the
  -- transparent prepared art sits directly on the panel background.
  drawPartyBattleSprite(menu.game, mon, x + w - 68, y + 38, 56, 66, 1.15)

  local def = monDefinition(menu.game, mon)
  local types = def and def.types or {}
  drawTypeBadge(types[1], fonts, x + 14, y + 61, 54, 18)
  if types[2] and types[2] ~= types[1] then
    drawTypeBadge(types[2], fonts, x + 72, y + 61, 54, 18)
  end

  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print("LEVEL", x + 14, y + 86)
  setColor(COLORS.ink)
  g.print(tostring(mon.level or "?"), x + 55, y + 86)
  setColor(COLORS.muted)
  g.print("HP", x + 14, y + 104)
  setColor(COLORS.ink)
  g.print(string.format("%d/%d", hp, maxHP), x + 55, y + 104)
  drawHPBar(x + 14, y + 124, w - 28, hp, maxHP)
  drawXPBar(x + 14, y + 134, w - 28,
            levelExpProgress(menu.game, mon, def))

  setColor(COLORS.muted)
  g.print("STATS", x + 14, y + 148)
  setColor(COLORS.ink)
  g.print("ATK " .. statValue(mon, "attack", "atk"), x + 14, y + 165)
  g.print("DEF " .. statValue(mon, "defense", "def"), x + 99, y + 165)
  g.print("SPD " .. statValue(mon, "speed", "spd"), x + 14, y + 181)
  g.print("SPC " .. statValue(mon, "special", "spc", "specialAttack"),
          x + 99, y + 181)

  setColor(COLORS.muted)
  g.print("MOVES", x + 14, y + 194)
  local moves = mon.moves or {}
  for i = 1, math.min(4, #moves) do
    local move = moves[i]
    local def = menu.game.data and menu.game.data.moves
                and menu.game.data.moves[move.id]
    local name = cleanLabel((def and def.name) or move.id or "-")
    setColor(COLORS.ink)
    g.print(name, x + 14, y + 194 + i * 13)
  end
end

local function drawPartyMenu(mod, menu, PartyMenu, fonts)
  local g = love.graphics
  setColor({ 0.11, 0.12, 0.12, 0.96 })
  g.rectangle("fill", 0, 0, DESIGN_W, DESIGN_H)

  drawPanel(9, 8, DESIGN_W - 18, DESIGN_H - 16)
  g.setFont(fonts.title)
  setColor(COLORS.ink)
  g.print("POKÉMON", 25, 22)
  setColor(COLORS.accent)
  g.rectangle("fill", 126, 31, 276, 3)

  local party = menu.party or (menu.game.save and menu.game.save.party) or {}
  if #party == 0 then
    g.setFont(fonts.body)
    setColor(COLORS.ink)
    g.print("No POKEMON!", 28, 70)
    return
  end

  drawPartyRows(mod, menu, PartyMenu, fonts, 23, 49, 382)
  drawPartySidePanel(menu, fonts, 422, 49, 195, 268)

  setColor(COLORS.paper2)
  g.rectangle("fill", 23, 322, 594, 24)
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  local prompt = cleanLabel(menu:bottomMessage())
  g.print(prompt, 31, 328)
  local controls = menu.submenu and "A SELECT   B BACK" or "A OPEN   B CLOSE"
  g.print(controls, 609 - fonts.small:getWidth(controls), 328)
end

local function presentationStackIndex(game, background)
  local states = game and game.stack and game.stack.states
  if type(states) ~= "table" then return nil end
  for i, state in ipairs(states) do
    if state == background then return i end
  end
  return nil
end

local function presentationRange(game, background)
  local states = game and game.stack and game.stack.states
  local first = presentationStackIndex(game, background)
  if not first then return nil end
  -- An opaque screen above this presenter correctly replaces it. Non-opaque
  -- states are messages/choices/effects that must be composited over the
  -- widescreen background instead of reviving its native draw underneath.
  for i = first + 1, #states do
    if states[i].isOpaque then return nil end
  end
  return first, #states
end

local function expForNextLevel(game, mon, def)
  local level = tonumber(mon.level) or 1
  if level >= 100 then return 0 end
  local ok, Growth = pcall(require, "src.pokemon.Growth")
  if ok and Growth and type(Growth.expForLevel) == "function" then
    local growth = def and (def.growthRate or def.growth)
    local rates = game and game.data and game.data.growth_rates
    local calcOk, target = pcall(Growth.expForLevel, growth, level + 1, rates)
    if calcOk and target then
      return math.max(0, math.floor(target - (tonumber(mon.exp) or 0)))
    end
  end
  return nil
end

levelExpProgress = function(game, mon, def)
  local level = tonumber(mon.level) or 1
  if level >= 100 then return 1 end
  local ok, Growth = pcall(require, "src.pokemon.Growth")
  if not (ok and Growth and type(Growth.expForLevel) == "function") then
    return 0
  end
  local growth = def and (def.growthRate or def.growth)
  local rates = game and game.data and game.data.growth_rates
  local baseOk, base = pcall(Growth.expForLevel, growth, level, rates)
  local nextOk, nextLevel = pcall(Growth.expForLevel, growth, level + 1, rates)
  if not (baseOk and nextOk and base and nextLevel) or nextLevel <= base then
    return 0
  end
  return clamp(((tonumber(mon.exp) or base) - base) / (nextLevel - base), 0, 1)
end

local function summaryStatus(mon)
  local status = mon and mon.status
  if status == nil or status == false or status == 0 or status == "" then
    return "OK"
  end
  return cleanLabel(tostring(status):gsub("_", " "))
end

local function drawSummaryShared(summary, fonts, x, y, w, h)
  local g, mon, game = love.graphics, summary.mon, summary.game
  local def = monDefinition(game, mon)
  drawPanel(x, y, w, h)

  local name = monName(game, mon)
  local nameFont = fonts.title
  if nameFont:getWidth(name) > w - 30 then nameFont = fonts.small end
  g.setFont(nameFont)
  setColor(COLORS.ink)
  g.print(name, x + 14, y + 13)

  g.setFont(fonts.small)
  setColor(COLORS.muted)
  local dex = def and (def.dex or def.number or def.id)
  if dex then
    g.print(string.format("No. %03d", tonumber(dex) or 0), x + 14, y + 38)
  end

  -- The same resolver used by Party: Battle Art static/animated 2D fronts,
  -- then the engine's active front-sprite resolver. Stadium models are never
  -- requested by this path.
  drawPartyBattleSprite(game, mon, x + 16, y + 53, w - 32, 142)

  local player = game and game.save and game.save.player or {}
  setColor(COLORS.muted)
  g.print("OT", x + 14, y + 205)
  g.print("ID No.", x + 14, y + 231)
  setColor(COLORS.ink)
  g.print(cleanLabel(mon.ot or player.name or "-"), x + 65, y + 205)
  g.print(tostring(mon.otId or player.id or "-"), x + 65, y + 231)
end

local function drawSummaryPageOne(summary, fonts, x, y, w, h)
  local g, mon = love.graphics, summary.mon
  local def = monDefinition(summary.game, mon)
  local maxHP = math.max(1, mon.stats and mon.stats.hp or 1)
  local hp = math.floor(mon.hp or 0)
  drawPanel(x, y, w, h)

  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print("LEVEL", x + 15, y + 18)
  g.print("STATUS", x + 190, y + 18)
  setColor(COLORS.ink)
  g.print(tostring(mon.level or "?"), x + 15, y + 37)
  g.print(summaryStatus(mon), x + 190, y + 37)

  setColor(COLORS.muted)
  g.print("HP", x + 15, y + 61)
  local hpText = string.format("%d/%d", hp, maxHP)
  setColor(COLORS.ink)
  g.print(hpText, x + w - 15 - fonts.small:getWidth(hpText), y + 61)
  drawHPBar(x + 15, y + 82, w - 30, hp, maxHP)

  setColor(COLORS.muted)
  g.print("STATS", x + 15, y + 101)
  local cards = {
    { "ATTACK", statValue(mon, "attack", "atk") },
    { "DEFENSE", statValue(mon, "defense", "def") },
    { "SPEED", statValue(mon, "speed", "spd") },
    { "SPECIAL", statValue(mon, "special", "spc", "specialAttack") },
  }
  for i, entry in ipairs(cards) do
    local col = (i - 1) % 2
    local row = math.floor((i - 1) / 2)
    local cx, cy = x + 15 + col * 170, y + 120 + row * 42
    setColor(COLORS.paper2)
    g.rectangle("fill", cx, cy, 155, 34)
    setColor(COLORS.muted)
    g.print(entry[1], cx + 8, cy + 8)
    setColor(COLORS.ink)
    g.print(entry[2], cx + 145 - fonts.small:getWidth(entry[2]), cy + 8)
  end

  setColor(COLORS.muted)
  g.print("TYPE", x + 15, y + 216)
  local types = def and def.types or {}
  drawTypeBadge(types[1], fonts, x + 73, y + 211, 78, 21)
  if types[2] and types[2] ~= types[1] then
    drawTypeBadge(types[2], fonts, x + 158, y + 211, 78, 21)
  end
end

local function drawSummaryPageTwo(summary, fonts, x, y, w, h)
  local g, mon, game = love.graphics, summary.mon, summary.game
  local def = monDefinition(game, mon)
  drawPanel(x, y, w, h)
  g.setFont(fonts.small)

  setColor(COLORS.muted)
  g.print("EXP POINTS", x + 15, y + 14)
  g.print("NEXT LEVEL", x + 190, y + 14)
  setColor(COLORS.ink)
  g.print(tostring(math.floor(tonumber(mon.exp) or 0)), x + 15, y + 33)
  local nextExp = expForNextLevel(game, mon, def)
  g.print(nextExp ~= nil and tostring(nextExp) or "-", x + 190, y + 33)

  setColor(COLORS.muted)
  g.print("LEVEL PROGRESS", x + 15, y + 55)
  drawXPBar(x + 125, y + 59, w - 140, levelExpProgress(game, mon, def))

  setColor(COLORS.muted)
  g.print("MOVES", x + 15, y + 84)
  local moves = mon.moves or {}
  for i = 1, 4 do
    local move = moves[i]
    local mdef = move and game.data and game.data.moves
                 and game.data.moves[move.id]
    local ry = y + 104 + (i - 1) * 37
    setColor(COLORS.paper2)
    g.rectangle("fill", x + 15, ry, w - 30, 30)
    setColor(COLORS.ink)
    local moveName = fitLabel(fonts.small,
      (mdef and mdef.name) or (move and move.id) or "-", 154)
    g.print(moveName, x + 25, ry + 6)
    if move then
      drawTypeBadge(mdef and mdef.type, fonts, x + 190, ry + 6, 65, 18)
      local maxPP = tonumber(mdef and mdef.pp) or tonumber(move.pp) or 0
      local ups = tonumber(move.ppUps) or 0
      maxPP = maxPP + ups * math.floor(maxPP / 5)
      local pp = tostring(move.pp or 0) .. "/" .. tostring(maxPP)
      setColor(COLORS.muted)
      g.print("PP " .. pp, x + w - 25 - fonts.small:getWidth("PP " .. pp),
              ry + 6)
    end
  end
end

local function drawSummaryMenu(summary, fonts)
  local g = love.graphics
  setColor({ 0.11, 0.12, 0.12, 0.96 })
  g.rectangle("fill", 0, 0, DESIGN_W, DESIGN_H)
  drawPanel(9, 8, DESIGN_W - 18, DESIGN_H - 16)
  g.setFont(fonts.title)
  setColor(COLORS.ink)
  local summaryTitle = "POKEMON SUMMARY"
  g.print(summaryTitle, 25, 22)
  setColor(COLORS.accent)
  local lineX = 25 + fonts.title:getWidth(summaryTitle) + 15
  g.rectangle("fill", lineX, 31, math.max(20, 402 - lineX), 3)
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  local page = clamp(tonumber(summary.page) or 1, 1, 2)
  g.print(page .. " / 2", 579, 24)

  drawSummaryShared(summary, fonts, 23, 49, 202, 267)
  if page == 1 then
    drawSummaryPageOne(summary, fonts, 240, 49, 377, 267)
  else
    drawSummaryPageTwo(summary, fonts, 240, 49, 377, 267)
  end

  setColor(COLORS.paper2)
  g.rectangle("fill", 23, 322, 594, 24)
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print(page == 1 and "POKEMON DATA" or "MOVES & EXPERIENCE", 31, 328)
  local controls = page == 1 and "A / B NEXT" or "A / B CLOSE"
  g.print(controls, 609 - fonts.small:getWidth(controls), 328)
end

local function visibleTextBoxLine(box, shownIndex)
  local shown = box.shown and box.shown[shownIndex]
  local page = box.pages and box.pages[box.pageIndex]
  if not (shown and page) then return "" end
  local sourceIndex = box.lineIndex - (#box.shown - shownIndex)
  local source = page[sourceIndex] or ""
  if not (EngineFont and EngineFont.split) then
    return source:sub(1, math.min(#source, #shown))
  end
  local spans = EngineFont.split(source)
  local count = math.min(#shown, #spans)
  if count <= 0 then return "" end
  return source:sub(1, spans[count].to)
end

local function drawWideTextBox(box, fonts)
  local g = love.graphics
  local x, y, w, h = 23, 254, 594, 92
  drawPanel(x, y, w, h)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  for i = 1, math.min(2, #(box.shown or {})) do
    g.print(visibleTextBoxLine(box, i), x + 20, y + 19 + (i - 1) * 28)
  end
  if (box.waiting or (box.done and not box.choice and not box.auto
                      and not box.stay)) and (box.blink or 0) < 30 then
    setColor(COLORS.accent)
    g.polygon("fill", x + w - 29, y + h - 25,
              x + w - 15, y + h - 25,
              x + w - 22, y + h - 15)
  end
end

local function drawWideChoiceBox(choice, fonts)
  local g = love.graphics
  local x, y, w, h = 470, 166, 147, 82
  drawPanel(x, y, w, h)
  local rowH = 28
  for i = 1, 2 do
    local ry = y + 13 + (i - 1) * rowH
    if i == choice.index then
      setColor(COLORS.selected)
      g.rectangle("fill", x + 9, ry, w - 18, rowH - 2)
      setColor(COLORS.accent)
      g.rectangle("fill", x + 9, ry, 4, rowH - 2)
    end
  end
  g.setFont(fonts.body)
  setColor(choice.index == 1 and COLORS.selectedText or COLORS.ink)
  g.print("YES", x + 24, y + 18)
  setColor(choice.index == 2 and COLORS.selectedText or COLORS.ink)
  g.print("NO", x + 24, y + 46)
end

local function drawNativeOverlay(state)
  if not (state and type(state.draw) == "function") then return end
  local g = love.graphics
  g.push("all")
  -- Generic non-opaque effects use the engine's 160x144 coordinate space.
  -- Stretching a full-screen veil is exact; custom TextBox/Choice presenters
  -- above avoid stretching text or borders.
  g.scale(DESIGN_W / 160, DESIGN_H / 144)
  pcall(state.draw, state)
  g.pop()
end

local function drawPresentationOverlays(game, first, last, fonts)
  local states = game.stack.states
  for i = first + 1, last do
    local state = states[i]
    local mt = getmetatable(state)
    if TextBoxClass and mt == TextBoxClass then
      drawWideTextBox(state, fonts)
    elseif ChoiceBoxClass and mt == ChoiceBoxClass then
      drawWideChoiceBox(state, fonts)
    else
      drawNativeOverlay(state)
    end
  end
end

local function drawInDesignSpace(drawFn)
  local g = love.graphics
  local ww, wh = g.getDimensions()
  if ww <= 0 or wh <= 0 then return end
  local scale = math.min(ww / DESIGN_W, wh / DESIGN_H)
  local ox = math.floor((ww - DESIGN_W * scale) / 2)
  local oy = math.floor((wh - DESIGN_H * scale) / 2)
  g.push("all")
  g.translate(ox, oy)
  g.scale(scale, scale)
  drawFn()
  g.pop()
end

-- Battles use the same uniform pixel scale as the 640x360 presentation, but
-- expose the entire physical window to the HUD. This keeps 16:9 unchanged and
-- anchors chrome to the real top/bottom edges on taller 4:3 displays without
-- changing the world renderer, camera, or battle arena geometry.
local function drawInBattleSpace(drawFn)
  local g = love.graphics
  local ww, wh = g.getDimensions()
  if ww <= 0 or wh <= 0 then return end
  local scale = math.min(ww / DESIGN_W, wh / DESIGN_H)
  if scale <= 0 then return end
  local viewW = math.floor(ww / scale + 0.5)
  local viewH = math.floor(wh / scale + 0.5)
  g.push("all")
  g.scale(scale, scale)
  drawFn(viewW, viewH)
  g.pop()
end

return function(mod)
  local providerErrors = {}
  local warnedForcedBattleHud = false
  battleMoveInspectorLogError = function(message)
    message = tostring(message)
    if providerErrors[message] then return end
    providerErrors[message] = true
    mod.log:error("Widescreen UI Move Inspector: %s", message)
  end

  local battleHudOverlayErrors = {}
  battleHudOverlayLogError = function(message)
    message = tostring(message)
    if battleHudOverlayErrors[message] then return end
    battleHudOverlayErrors[message] = true
    mod.log:error("Widescreen UI Battle HUD overlay: %s", message)
  end
  mod.exports.battleHudOverlayApiVersion = BATTLE_HUD_OVERLAY_API_VERSION
  mod.exports.registerBattleHudOverlay = function(spec)
    if type(spec) ~= "table" then
      return nil, "provider descriptor must be a table"
    end
    if type(spec.owner) ~= "string" or spec.owner == "" then
      return nil, "provider owner must be a non-empty string"
    end
    if spec.apiVersion ~= BATTLE_HUD_OVERLAY_API_VERSION then
      return nil, "unsupported Battle HUD overlay API version"
    end
    if type(spec.draw) ~= "function" then
      return nil, "provider draw must be a function"
    end
    for i, provider in ipairs(battleHudOverlayProviders) do
      if provider.owner == spec.owner then
        battleHudOverlayProviders[i] = {
          owner = spec.owner, draw = spec.draw, failed = false,
        }
        return true, "replaced"
      end
    end
    battleHudOverlayProviders[#battleHudOverlayProviders + 1] = {
      owner = spec.owner, draw = spec.draw, failed = false,
    }
    return true, "registered"
  end
  mod.exports.unregisterBattleHudOverlay = function(owner)
    for i, provider in ipairs(battleHudOverlayProviders) do
      if provider.owner == owner then
        table.remove(battleHudOverlayProviders, i)
        return true, "unregistered"
      end
    end
    return true, "absent"
  end

  local worldHudOverlayErrors = {}
  worldHudOverlayLogError = function(message)
    message = tostring(message)
    if worldHudOverlayErrors[message] then return end
    worldHudOverlayErrors[message] = true
    mod.log:error("Widescreen UI World HUD overlay: %s", message)
  end
  mod.exports.worldHudOverlayApiVersion = WORLD_HUD_OVERLAY_API_VERSION
  mod.exports.registerWorldHudOverlay = function(spec)
    if type(spec) ~= "table" then
      return nil, "provider descriptor must be a table"
    end
    if type(spec.owner) ~= "string" or spec.owner == "" then
      return nil, "provider owner must be a non-empty string"
    end
    if spec.apiVersion ~= WORLD_HUD_OVERLAY_API_VERSION then
      return nil, "unsupported World HUD overlay API version"
    end
    if type(spec.draw) ~= "function" then
      return nil, "provider draw must be a function"
    end
    for i, provider in ipairs(worldHudOverlayProviders) do
      if provider.owner == spec.owner then
        worldHudOverlayProviders[i] = {
          owner = spec.owner, draw = spec.draw, failed = false,
        }
        return true, "replaced"
      end
    end
    worldHudOverlayProviders[#worldHudOverlayProviders + 1] = {
      owner = spec.owner, draw = spec.draw, failed = false,
    }
    return true, "registered"
  end
  mod.exports.unregisterWorldHudOverlay = function(owner)
    for i, provider in ipairs(worldHudOverlayProviders) do
      if provider.owner == owner then
        table.remove(worldHudOverlayProviders, i)
        return true, "unregistered"
      end
    end
    return true, "absent"
  end

  mod.exports.battleMoveInspectorApiVersion = BATTLE_MOVE_INSPECTOR_API_VERSION
  mod.exports.registerBattleMoveInspector = function(spec)
    if type(spec) ~= "table" then return nil, "provider descriptor must be a table" end
    if type(spec.owner) ~= "string" or spec.owner == "" then
      return nil, "provider owner must be a non-empty string"
    end
    if spec.apiVersion ~= BATTLE_MOVE_INSPECTOR_API_VERSION then
      return nil, "unsupported Move Inspector API version"
    end
    if type(spec.snapshot) ~= "function" then
      return nil, "provider snapshot must be a function"
    end
    if battleMoveInspectorProvider
        and battleMoveInspectorProvider.owner ~= spec.owner then
      return nil, "Move Inspector provider already owned by "
        .. battleMoveInspectorProvider.owner
    end
    local replaced = battleMoveInspectorProvider ~= nil
    battleMoveInspectorProvider = {
      owner = spec.owner,
      apiVersion = spec.apiVersion,
      snapshot = spec.snapshot,
    }
    providerErrors = {}
    return true, replaced and "replaced" or "registered"
  end
  mod.exports.unregisterBattleMoveInspector = function(owner)
    if not battleMoveInspectorProvider then return true, "absent" end
    if owner ~= battleMoveInspectorProvider.owner then
      return nil, "provider is owned by " .. battleMoveInspectorProvider.owner
    end
    battleMoveInspectorProvider = nil
    providerErrors = {}
    warnedForcedBattleHud = false
    return true, "unregistered"
  end
  mod.exports.activeBattleMoveInspectorOwner = function()
    return battleMoveInspectorProvider and battleMoveInspectorProvider.owner or nil
  end

  local pokedexProviderErrors = {}
  pokedexProviderLogError = function(message)
    message = tostring(message)
    if pokedexProviderErrors[message] then return end
    pokedexProviderErrors[message] = true
    mod.log:error("Widescreen UI Pokedex provider: %s", message)
  end
  mod.exports.pokedexProviderApiVersion = POKEDEX_PROVIDER_API_VERSION
  mod.exports.registerPokedexProvider = function(spec)
    if type(spec) ~= "table" then return nil, "provider descriptor must be a table" end
    if type(spec.owner) ~= "string" or spec.owner == "" then
      return nil, "provider owner must be a non-empty string"
    end
    if spec.apiVersion ~= POKEDEX_PROVIDER_API_VERSION then
      return nil, "unsupported Pokedex provider API version"
    end
    if type(spec.match) ~= "function" or type(spec.snapshot) ~= "function" then
      return nil, "provider match and snapshot must be functions"
    end
    if type(spec.actions) ~= "table" then
      return nil, "provider actions must be a table"
    end
    if pokedexProvider and pokedexProvider.owner ~= spec.owner then
      return nil, "Pokedex provider already owned by " .. pokedexProvider.owner
    end
    local replaced = pokedexProvider ~= nil
    pokedexProvider = {
      owner = spec.owner,
      apiVersion = spec.apiVersion,
      match = spec.match,
      snapshot = spec.snapshot,
      actions = spec.actions,
    }
    pokedexProviderErrors = {}
    return true, replaced and "replaced" or "registered"
  end
  mod.exports.unregisterPokedexProvider = function(owner)
    if not pokedexProvider then return true, "absent" end
    if owner ~= pokedexProvider.owner then
      return nil, "provider is owned by " .. pokedexProvider.owner
    end
    pokedexProvider = nil
    pokedexProviderErrors = {}
    return true, "unregistered"
  end
  mod.exports.activePokedexProviderOwner = function()
    return pokedexProvider and pokedexProvider.owner or nil
  end
  mod.exports.invokePokedexProviderAction = function(actionId, game, state, ...)
    if not pokedexProvider then return nil, "no active Pokedex provider" end
    local action = pokedexProvider.actions[actionId]
    if type(action) ~= "function" then
      return nil, "unsupported Pokedex action " .. tostring(actionId)
    end
    local ok, value, reason = pcall(action, game, state, ...)
    if not ok then
      pokedexProviderLogError("action " .. tostring(actionId)
        .. " exception: " .. tostring(value))
      return nil, value
    end
    return value, reason
  end

  ShinyArtResolver = function(mon)
    local shinyMod = mod.find and mod:find("gen1_shiny_system")
    local use = shinyMod and shinyMod.exports
      and shinyMod.exports.shouldUseShinyArt
    if type(use) ~= "function" then return nil end
    local ok, value = pcall(use, mon)
    return ok and (value and true or false) or nil
  end
  ShinyBattleImage = function(game, mon, side)
    local shinyMod = mod.find and mod:find("gen1_shiny_system")
    local resolve = shinyMod and shinyMod.exports
      and shinyMod.exports.battleImage
    if type(resolve) ~= "function" then return nil end
    return resolve(game, mon, side)
  end

  mod.options:define({
    {
      key = "start_menu",
      type = "toggle",
      label = "WIDESCREEN START MENU",
      default = true,
    },
    {
      key = "title_menu",
      type = "toggle",
      label = "WIDESCREEN MAIN MENU",
      default = true,
    },
    {
      key = "load_report",
      type = "toggle",
      label = "WIDESCREEN LOAD REPORT",
      default = true,
    },
    {
      key = "party_screen",
      type = "toggle",
      label = "WIDESCREEN POKEMON SCREEN",
      default = true,
    },
    {
      key = "summary_screen",
      type = "toggle",
      label = "WIDESCREEN STAT SCREEN",
      default = true,
    },
    {
      key = "pokedex_screen",
      type = "toggle",
      label = "WIDESCREEN POKEDEX",
      default = true,
    },
    {
      key = "battle_hud",
      type = "toggle",
      label = "WIDESCREEN BATTLE HUD",
      default = true,
    },
  })

  local function optionEnabled(key)
    local ok, value = pcall(mod.options.get, mod.options, key)
    if key == "battle_hud" and battleMoveInspectorProvider then
      if ok and value == false and not warnedForcedBattleHud then
        warnedForcedBattleHud = true
        mod.log:warn("Widescreen UI: WIDESCREEN BATTLE HUD is required by Move Inspector provider %s; the disabled setting is ignored while it is active",
          battleMoveInspectorProvider.owner)
      end
      return true
    end
    if key == "pokedex_screen" and pokedexProvider then return true end
    return not ok or value ~= false
  end

  local fonts = {
    title = loadFont(16),
    body = loadFont(16),
    small = loadFont(12),
    tiny = loadFont(10),
  }
  if not fonts.title or not fonts.body or not fonts.small or not fonts.tiny then
    mod.log:warn("Widescreen UI: could not create screen-space fonts")
  end

  local okSpriteDeps, spriteDepsErr = pcall(function()
    PokemonSprites = require("src.pokemon.Sprites")
    Assets = require("src.render.Assets")
    PaletteFX = require("src.render.PaletteFX")
    Stats = require("src.pokemon.Stats")
    EngineFont = require("src.render.Font")
    TextBoxClass = require("src.render.TextBox")
    ChoiceBoxClass = require("src.ui.ChoiceBox")
    local function optionalRequire(name)
      local loaded, value = pcall(require, name)
      return loaded and value or nil
    end
    ListMenuClass = optionalRequire("src.ui.ListMenu")
    MenuClass = optionalRequire("src.ui.Menu")
    PokedexMenuClass = optionalRequire("src.ui.PokedexMenu")
    DexEntryMenuClass = optionalRequire("src.ui.DexEntryMenu")
    TitleStateClass = optionalRequire("src.ui.TitleState")
    QuarantineReportClass = optionalRequire("src.ui.QuarantineReport")
    BattleState = require("src.battle.BattleState")
    if Assets.register then
      Assets.register(function()
        partyBattleSpriteCache = {}
        partyIconSheetCache = {}
        battleArtPreview = setmetatable({}, { __mode = "k" })
      end)
    end
  end)
  if not okSpriteDeps then
    mod.log:warn("Widescreen UI: battle portrait resolver unavailable: %s",
                 tostring(spriteDepsErr))
  end

  -- The engine's WIDE battle compositor and Dramatic Shape's snapped HUD are
  -- both presentations of the same battle state.  While this option is on,
  -- keep the simulation/input untouched but route drawing through the classic
  -- battlefield layer with its native HUD/text passes suppressed.  The final
  -- 640x360 presenter below then becomes the single owner of battle chrome.
  local activeBattle
  local okBattlePatch, battlePatchErr = pcall(function()
    if not BattleState or BattleState.__widescreenUiBattleWrapped then return end
    local originalWideLayout = BattleState.wideLayout
    local originalDrawHUDs = BattleState.drawHUDs
    local originalDrawTextArea = BattleState.drawTextArea
    local originalUpdate = BattleState.update

    BattleState.wideLayout = function(self, ...)
      if optionEnabled("battle_hud") then return false end
      return originalWideLayout(self, ...)
    end
    BattleState.drawHUDs = function(self, ...)
      if optionEnabled("battle_hud") then return end
      return originalDrawHUDs(self, ...)
    end
    BattleState.drawTextArea = function(self, ...)
      if optionEnabled("battle_hud") then return end
      return originalDrawTextArea(self, ...)
    end
    if type(originalUpdate) == "function" then
      BattleState.update = function(self, dt, ...)
        -- Rendering uses the classic battlefield layer so its native chrome
        -- can be suppressed cleanly. Preserve the 2x2 navigation promised by
        -- the visible move grid explicitly while A/B/SELECT remain native.
        if optionEnabled("battle_hud") and self and self.game
            and self.game.input and type(self.game.input.wasPressed) == "function"
            and (self.phase == "moveSelect" or self.phase == "mimicSelect") then
          local moves = self.phase == "moveSelect"
            and self.player and self.player.curMoves or self.mimicMoves
          local key = self.phase == "moveSelect" and "moveIndex" or "mimicIndex"
          local index = tonumber(self[key]) or 1
          local count = #(moves or {})
          local input = self.game.input
          local direction
          for _, candidate in ipairs({ "left", "right", "up", "down" }) do
            if input:wasPressed(candidate) then
              direction = candidate
              break
            end
          end
          if direction == "left" or direction == "right" then
            local row = math.floor((index - 1) / 2)
            local col = (index - 1) % 2
            local other = row * 2 + (1 - col) + 1
            if other <= count then self[key] = other end
          elseif direction == "up" or direction == "down" then
            local row = math.floor((index - 1) / 2)
            local col = (index - 1) % 2
            local other = (1 - row) * 2 + col + 1
            if other <= count then self[key] = other end
          end
          if direction then
            -- wideLayout is false only for drawing suppression. Prevent the
            -- classic +/-1 navigation from applying after the grid step.
            local originalWasPressed = input.wasPressed
            input.wasPressed = function(obj, pressedKey)
              if pressedKey == "left" or pressedKey == "right"
                  or pressedKey == "up" or pressedKey == "down" then
                return false
              end
              return originalWasPressed(obj, pressedKey)
            end
            local ok, a, b, c = pcall(originalUpdate, self, dt, ...)
            input.wasPressed = originalWasPressed
            if not ok then error(a, 0) end
            return a, b, c
          end
        end
        return originalUpdate(self, dt, ...)
      end
    end
    BattleState.__widescreenUiBattleWrapped = true
  end)
  if not okBattlePatch then
    mod.log:error("Widescreen UI: battle-state patch failed: %s",
                  tostring(battlePatchErr))
  end

  local battleProviderAdapters = {}
  local function patchBattleProvider(game, providerId)
    if battleProviderAdapters[providerId] then return true end
    local exports = game and game.mods and game.mods.exports
    local handle = exports and exports[providerId]
    if not handle and mod.find then
      local ok, found = pcall(mod.find, mod, providerId)
      if ok then handle = found end
    end
    local lib = handle and (handle.lib
      or (handle.exports and handle.exports.lib))
    if not (lib and type(lib.require) == "function") then return false end
    local okOB, OB = pcall(lib.require, "OverworldBattle")
    local okBH, BH = pcall(lib.require, "BattleHud")
    if not (okOB and OB and okBH and BH) then return false end

    local originalSnapHUDs = OB.snapHUDs
    local originalDrawHudPanels = OB.drawHudPanels
    local originalPanel = BH.panel
    OB.snapHUDs = function(battle, shot, ...)
      if optionEnabled("battle_hud") then
        return battle ~= nil and shot ~= nil and shot.canvas ~= nil
          and (tonumber(shot.scale) or 0) > 0
      end
      return originalSnapHUDs(battle, shot, ...)
    end
    OB.drawHudPanels = function(battle, ...)
      if optionEnabled("battle_hud") then return end
      return originalDrawHudPanels(battle, ...)
    end
    BH.panel = function(rect, box, world, ...)
      if optionEnabled("battle_hud") then return true end
      return originalPanel(rect, box, world, ...)
    end
    battleProviderAdapters[providerId] = {
      overworldBattle = OB, battleHud = BH,
    }
    return true
  end

  local function patchDramaticShapeBattle(game)
    local dramatic = patchBattleProvider(game, "DRAMATIC_SHAPE")
    local battleArt = patchBattleProvider(game, "BATTLE_ART_VOXEL_FORK")
    return dramatic or battleArt
  end

  -- Install before the first render pass when the loader exposes the mod
  -- handle. Dramatic Shape builds its snapped HUD during world composition,
  -- which occurs before render.hud; waiting until that hook is one frame too
  -- late and can also miss the captured native draw closure entirely.
  patchDramaticShapeBattle(nil)

  -- The voxel providers capture the engine HUD into a private texture before
  -- render.hud. Patch them at battle creation as well, covering load orders in
  -- which their exported library was not yet available during this mod's init.
  if mod.events and type(mod.events.on) == "function" then
    mod.events:on("battle.started", function(payload)
      local battle = payload and payload.battle
      patchDramaticShapeBattle(battle and battle.game)
    end)
  end

  mod.hooks:wrap("battle.overlay", function(next, battle)
    patchDramaticShapeBattle(battle and battle.game)
    local result = next(battle)
    activeBattle = battle
    return result
  end, 11000)

  local activeStart
  local okPatch, patchErr = pcall(function()
    local StartMenu = require("src.ui.StartMenu")
    if StartMenu.__widescreenUiWrapped then return end
    local originalNew = StartMenu.new
    StartMenu.new = function(game, ...)
      local menu = originalNew(game, ...)
      menu.__widescreenUiStart = true
      menu.__widescreenUiOriginalDraw = menu.draw
      -- An instance method is intentional: it wins over other mods that wrap
      -- generic Menu.draw, so two final-pass START presenters cannot both arm
      -- themselves merely because of load order.
      menu.draw = function(self, ...)
        if not optionEnabled("start_menu") and self.__widescreenUiOriginalDraw then
          return self.__widescreenUiOriginalDraw(self, ...)
        end
      end
      activeStart = menu
      return menu
    end
    StartMenu.__widescreenUiWrapped = true
  end)

  if not okPatch then
    mod.log:error("Widescreen UI: START menu patch failed: %s",
                  tostring(patchErr))
  end

  local activeParty
  local PartyMenu
  local okPartyPatch, partyPatchErr = pcall(function()
    PartyMenu = require("src.ui.PartyMenu")
    if PartyMenu.__widescreenUiWrapped then return end
    local originalNew = PartyMenu.new
    PartyMenu.new = function(game, opts)
      local menu = originalNew(game, opts)
      menu.__widescreenUiParty = true
      menu.__widescreenUiOriginalDraw = menu.draw
      menu.draw = function(self, ...)
        if not optionEnabled("party_screen")
            and self.__widescreenUiOriginalDraw then
          return self.__widescreenUiOriginalDraw(self, ...)
        end
        activeParty = self
      end
      activeParty = menu
      return menu
    end
    PartyMenu.__widescreenUiWrapped = true
  end)

  if not okPartyPatch then
    mod.log:error("Widescreen UI: Pokemon screen patch failed: %s",
                  tostring(partyPatchErr))
  end

  local activeSummary
  local SummaryMenu
  local okSummaryPatch, summaryPatchErr = pcall(function()
    SummaryMenu = require("src.ui.SummaryMenu")
    if SummaryMenu.__widescreenUiWrapped then return end
    local originalNew = SummaryMenu.new
    SummaryMenu.new = function(game, mon, ...)
      local summary = originalNew(game, mon, ...)
      summary.__widescreenUiSummary = true
      summary.__widescreenUiOriginalDraw = summary.draw
      summary.draw = function(self, ...)
        if not optionEnabled("summary_screen")
            and self.__widescreenUiOriginalDraw then
          return self.__widescreenUiOriginalDraw(self, ...)
        end
        activeSummary = self
      end
      activeSummary = summary
      return summary
    end
    SummaryMenu.__widescreenUiWrapped = true
  end)

  if not okSummaryPatch then
    mod.log:error("Widescreen UI: stat screen patch failed: %s",
                  tostring(summaryPatchErr))
  end

  -- TitleState keeps animating beneath the menu, but its original 160x144
  -- Menu box must never be drawn once the final-resolution presenter owns the
  -- title flow. The callbacks/update path remain on the original Menu object.
  if MenuClass and type(MenuClass.draw) == "function"
      and not MenuClass.__widescreenUiTitleDrawWrapped then
    local originalMenuDraw = MenuClass.draw
    MenuClass.draw = function(self, ...)
      if optionEnabled("title_menu") and self and self.titleUiBox then return end
      return originalMenuDraw(self, ...)
    end
    MenuClass.__widescreenUiTitleDrawWrapped = true
  end

  local okPokedexPatch, pokedexPatchErr = pcall(function()
    if not PokedexMenuClass or PokedexMenuClass.__widescreenUiWrapped then return end
    local originalNew = PokedexMenuClass.new
    PokedexMenuClass.new = function(game, opts, ...)
      local list = originalNew(game, opts, ...)
      list.__widescreenUiPokedexRoot = true
      return list
    end
    PokedexMenuClass.__widescreenUiWrapped = true
  end)
  if not okPokedexPatch then
    mod.log:error("Widescreen UI: Pokedex presentation patch failed: %s",
                  tostring(pokedexPatchErr))
  end

  local function isNativePokedexList(state)
    if type(state) ~= "table" or getmetatable(state) ~= ListMenuClass then
      return false
    end
    local title = tostring(state.title or "")
      :gsub("é", "E"):gsub("É", "E"):upper():gsub("[^A-Z]", "")
    return title == "POKEDEX"
  end

  local function pokedexRootRange(game)
    local states = game and game.stack and game.stack.states
    if type(states) ~= "table" then return nil end
    for i, state in ipairs(states) do
      if state.__widescreenUiPokedexRoot or isNativePokedexList(state) then
        return i, #states
      end
    end
  end

  local function validatePokedexSnapshot(snapshot)
    if type(snapshot) ~= "table" then return nil, "snapshot must be a table" end
    if snapshot.schemaVersion ~= 1 then
      return nil, "unsupported snapshot schemaVersion"
    end
    if type(snapshot.screen) ~= "string" then
      return nil, "snapshot screen must be a string"
    end
    if type(snapshot.rows) ~= "table" then
      return nil, "snapshot rows must be a table"
    end
    if type(snapshot.selectedIndex) ~= "number" then
      return nil, "snapshot selectedIndex must be numeric"
    end
    for i, row in ipairs(snapshot.rows) do
      if type(row) ~= "table" or (type(row.label) ~= "string"
          and type(row.name) ~= "string") then
        return nil, "snapshot row " .. tostring(i)
          .. " must have a label or species name"
      end
    end
    return snapshot
  end

  local function providerPokedexPresentation(game)
    local provider = pokedexProvider
    local states = game and game.stack and game.stack.states
    if not provider or type(states) ~= "table" then return nil end
    for i = #states, 1, -1 do
      local state = states[i]
      local okMatch, matched = pcall(provider.match, state)
      if not okMatch then
        pokedexProviderLogError("match exception: " .. tostring(matched))
        return nil
      end
      if matched then
        local okSnapshot, value, reason = pcall(provider.snapshot, game, state)
        if not okSnapshot then
          pokedexProviderLogError("snapshot exception: " .. tostring(value))
          return nil
        end
        if value == nil then
          pokedexProviderLogError("provider returned no snapshot: " .. tostring(reason))
          return nil
        end
        local snapshot, invalid = validatePokedexSnapshot(value)
        if not snapshot then
          pokedexProviderLogError("invalid snapshot: " .. tostring(invalid))
          return nil
        end
        return state, i, #states, snapshot
      end
    end
  end

  local function pokedexPresentation(game)
    if not optionEnabled("pokedex_screen") then return nil end
    local providerState, providerFirst, providerLast, snapshot =
      providerPokedexPresentation(game)
    if providerState then
      local rows = {}
      for _, row in ipairs(snapshot.rows) do
        local copy = {}
        for key, value in pairs(row) do copy[key] = value end
        if not copy.label then
          local number = copy.number and (tostring(copy.number) .. " ") or ""
          copy.label = number .. (copy.hidden and "?????" or copy.name)
        end
        if copy.owned then copy.marker = true end
        rows[#rows + 1] = copy
      end
      local footer = snapshot.footer
      if not footer and type(snapshot.counts) == "table" then
        footer = ("SEEN %03d     OWN %03d     A OPEN     B BACK"):format(
          tonumber(snapshot.counts.seen) or 0,
          tonumber(snapshot.counts.owned) or 0)
      end
      local model = {
        title = snapshot.title or "POKEDEX",
        rows = rows,
        index = snapshot.selectedIndex,
        scroll = snapshot.scroll or 0,
        footer = footer,
      }
      return "list", providerState, providerFirst, providerLast, model
    end
    local first, last = pokedexRootRange(game)
    if not first then return nil end
    local states = game.stack.states
    local baseIndex = last
    while baseIndex > first do
      local mt = getmetatable(states[baseIndex])
      if mt == TextBoxClass or mt == ChoiceBoxClass then
        baseIndex = baseIndex - 1
      else
        break
      end
    end
    local state = states[baseIndex]
    local mt = getmetatable(state)
    if mt == DexEntryMenuClass then
      return "entry", state, baseIndex, last
    end
    if mt == ListMenuClass or mt == MenuClass then
      return "list", state, baseIndex, last, nil
    end
    return nil
  end

  local function titlePresentation(game)
    if not optionEnabled("title_menu") then return nil end
    if not (TitleStateClass and MenuClass) then return nil end
    local states = game and game.stack and game.stack.states
    if type(states) ~= "table" or #states < 1 then return nil end
    local title
    for _, state in ipairs(states) do
      if getmetatable(state) == TitleStateClass then title = state break end
    end
    if not title then return nil end
    local top = states[#states]
    if top == title then return "title", title, nil end
    if getmetatable(top) == MenuClass and top.titleUiBox then
      return "menu", title, top
    end
    if top.title == title and type(top.save) == "table" then
      return "continue", title, top
    end
  end

  local function loadReportPresentation(game)
    if not optionEnabled("load_report") then return nil end
    if not QuarantineReportClass then return nil end
    local state = topState(game)
    if state and getmetatable(state) == QuarantineReportClass then return state end
  end

  -- Native TextBox and ChoiceBox render in the engine's 160x144 viewport.
  -- When one sits over a widescreen background, drawing it before our final
  -- presenter leaves a second box docked below the custom UI. Suppress only
  -- that native pass; drawPresentationOverlays recreates the active overlay
  -- afterward in 640x360 design space. Other game screens remain untouched.
  local function customBackgroundOwnsStack(game)
    if optionEnabled("summary_screen") and activeSummary
        and presentationRange(game, activeSummary) then
      return true
    end
    if optionEnabled("party_screen") and activeParty
        and presentationRange(game, activeParty) then
      return true
    end
    if pokedexPresentation(game) then return true end
    return false
  end

  local function suppressNativeOverlayDraw(class, marker)
    if not (class and type(class.draw) == "function") or class[marker] then
      return
    end
    local originalDraw = class.draw
    class.draw = function(self, ...)
      if customBackgroundOwnsStack(self and self.game) then return end
      return originalDraw(self, ...)
    end
    class[marker] = true
  end
  suppressNativeOverlayDraw(TextBoxClass, "__widescreenUiTextDrawWrapped")
  suppressNativeOverlayDraw(ChoiceBoxClass, "__widescreenUiChoiceDrawWrapped")

  mod.hooks:wrap("render.hud", function(next, game, viewport)
    patchDramaticShapeBattle(game)
    local result = next(game, viewport)
    if not fonts.body then return result end

    if activeStart and not stateInStack(game, activeStart) then
      activeStart = nil
    end
    if activeParty and not stateInStack(game, activeParty) then
      activeParty = nil
    end
    if activeSummary and not stateInStack(game, activeSummary) then
      activeSummary = nil
    end
    if activeBattle and not stateInStack(game, activeBattle) then
      activeBattle = nil
    end

    local top = topState(game)
    local summaryFirst, summaryLast
    if optionEnabled("summary_screen") and activeSummary and SummaryMenu then
      summaryFirst, summaryLast = presentationRange(game, activeSummary)
    end
    local partyFirst, partyLast
    if optionEnabled("party_screen") and activeParty and PartyMenu then
      partyFirst, partyLast = presentationRange(game, activeParty)
    end
    local dexKind, dexState, dexFirst, dexLast, dexModel = pokedexPresentation(game)
    local titleKind, titleState, titleOverlay = titlePresentation(game)
    local loadReport = loadReportPresentation(game)
    if loadReport then
      drawInBattleSpace(function(viewW, viewH)
        drawLoadReport(loadReport, fonts, viewW, viewH)
      end)
    elseif titleKind then
      drawInBattleSpace(function(viewW, viewH)
        if titleKind == "continue" then
          drawContinueInfo(titleState, titleOverlay, fonts, viewW, viewH)
        elseif titleKind == "title" then
          drawTitleStandby(titleState, fonts, viewW, viewH)
        else
          drawTitleMenu(titleState, titleOverlay, fonts, viewW, viewH)
        end
      end)
    elseif summaryFirst then
      drawInDesignSpace(function()
        drawSummaryMenu(activeSummary, fonts)
        drawPresentationOverlays(game, summaryFirst, summaryLast, fonts)
      end)
    elseif partyFirst then
      drawInDesignSpace(function()
        drawPartyMenu(mod, activeParty, PartyMenu, fonts)
        drawPresentationOverlays(game, partyFirst, partyLast, fonts)
      end)
    elseif dexKind then
      drawInDesignSpace(function()
        if dexKind == "entry" then
          drawPokedexEntry(dexState, fonts)
        else
          drawPokedexList(dexState, fonts, dexModel)
        end
        drawPresentationOverlays(game, dexFirst, dexLast, fonts)
      end)
    elseif optionEnabled("start_menu") and activeStart and top == activeStart then
      drawInDesignSpace(function() drawStartMenu(activeStart, fonts) end)
    elseif optionEnabled("battle_hud") and activeBattle and top == activeBattle then
      drawInBattleSpace(function(viewW, viewH)
        drawBattleHUD(activeBattle, fonts, viewW, viewH)
      end)
    end
    if #worldHudOverlayProviders > 0 then
      drawInBattleSpace(function(viewW, viewH)
        drawWorldHudExtensions(game, fonts, viewW, viewH)
      end)
    end
    return result
  end, 12000)

  mod.exports.designWidth = DESIGN_W
  mod.exports.designHeight = DESIGN_H
  mod.exports.resolve2dPokemonPortrait = selectedBattleSpriteImage
  mod.exports.draw2dPokemonPortrait = drawPartyBattleSprite
  mod.exports.portraitPolicy = "battle_art_2d_only"
  mod.exports.prototype = "title_start_party_summary_pokedex_report_and_battle"
  mod.exports.battleHud = "responsive_640x360"
  mod.exports.battleMoveInspectorContract = "v1"
  mod.exports.pokedexPresentation = "native_independent_style_v1"
  mod.exports.pokedexProviderContract = "v1"
end
