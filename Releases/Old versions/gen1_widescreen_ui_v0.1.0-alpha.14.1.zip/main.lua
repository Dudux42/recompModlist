-- Gen1 Widescreen UI
-- Version 0.1.0-alpha.14.1
--
-- The world renderer deliberately remains on its normal 160x144 logical
-- surface.  Converted screens are presented in render.hud, after Gen1Recomp
-- and Dramatic Shape have finished composing the world.  This avoids the
-- camera/zoom changes caused by asking Renderer for a wider UI canvas while
-- the overworld is visible.

local DESIGN_W, DESIGN_H = 640, 360
local FONT_PATH = "PixelifySans-VariableFont_wght.ttf"
local PokemonSprites, Assets, PaletteFX, Stats, BattleState
local ShinyArtResolver, ShinyBattleImage, BattleArtProviderImage
local BattleArtProviderPresentation
local EngineFont, TextBoxClass, ChoiceBoxClass
local ListMenuClass, MenuClass, PokedexMenuClass, DexEntryMenuClass
local TitleStateClass, QuarantineReportClass, OptionsMenuClass, ManagerStateClass
local partyBattleSpriteCache = {}
local partyIconSheetCache = {}
local titlePresentationCycles = setmetatable({}, { __mode = "k" })
local titleBattleArtPreviews = setmetatable({}, { __mode = "k" })
local pokemonPresentationTokens = setmetatable({}, { __mode = "k" })
local drawPartyBattleSprite
local selectedBattleSpriteImage
local levelExpProgress
local battleMoveInspectorProvider
local battleMoveInspectorLogError
local BATTLE_MOVE_INSPECTOR_API_VERSION = 1
local pokedexProvider
local pokedexProviderLogError
local POKEDEX_PROVIDER_API_VERSION = 2
local PokedexProviderUI = {
  compatVersion = 1,
  lastValid = setmetatable({}, { __mode = "k" }),
  hitRegions = setmetatable({}, { __mode = "k" }),
  views = setmetatable({}, { __mode = "k" }),
}
local battleHudOverlayProviders = {}
local battleHudOverlayLogError
local BATTLE_HUD_OVERLAY_API_VERSION = 1
local worldHudOverlayProviders = {}
local worldHudOverlayLogError
local WORLD_HUD_OVERLAY_API_VERSION = 1

local PARTY_ICON_SPECIES = {
  "BULBASAUR","IVYSAUR","VENUSAUR","CHARMANDER","CHARMELEON","CHARIZARD",
  "SQUIRTLE","WARTORTLE","BLASTOISE","CATERPIE","METAPOD","BUTTERFREE",
  "WEEDLE","KAKUNA","BEEDRILL","PIDGEY","PIDGEOTTO","PIDGEOT","RATTATA",
  "RATICATE","SPEAROW","FEAROW","EKANS","ARBOK","PIKACHU","RAICHU",
  "SANDSHREW","SANDSLASH","NIDORANF","NIDORINA","NIDOQUEEN","NIDORANM",
  "NIDORINO","NIDOKING","CLEFAIRY","CLEFABLE","VULPIX","NINETALES",
  "JIGGLYPUFF","WIGGLYTUFF","ZUBAT","GOLBAT","ODDISH","GLOOM","VILEPLUME",
  "PARAS","PARASECT","VENONAT","VENOMOTH","DIGLETT","DUGTRIO","MEOWTH",
  "PERSIAN","PSYDUCK","GOLDUCK","MANKEY","PRIMEAPE","GROWLITHE","ARCANINE",
  "POLIWAG","POLIWHIRL","POLIWRATH","ABRA","KADABRA","ALAKAZAM","MACHOP",
  "MACHOKE","MACHAMP","BELLSPROUT","WEEPINBELL","VICTREEBEL","TENTACOOL",
  "TENTACRUEL","GEODUDE","GRAVELER","GOLEM","PONYTA","RAPIDASH","SLOWPOKE",
  "SLOWBRO","MAGNEMITE","MAGNETON","FARFETCHD","DODUO","DODRIO","SEEL",
  "DEWGONG","GRIMER","MUK","SHELLDER","CLOYSTER","GASTLY","HAUNTER",
  "GENGAR","ONIX","DROWZEE","HYPNO","KRABBY","KINGLER","VOLTORB",
  "ELECTRODE","EXEGGCUTE","EXEGGUTOR","CUBONE","MAROWAK","HITMONLEE",
  "HITMONCHAN","LICKITUNG","KOFFING","WEEZING","RHYHORN","RHYDON","CHANSEY",
  "TANGELA","KANGASKHAN","HORSEA","SEADRA","GOLDEEN","SEAKING","STARYU",
  "STARMIE","MRMIME","SCYTHER","JYNX","ELECTABUZZ","MAGMAR","PINSIR",
  "TAUROS","MAGIKARP","GYARADOS","LAPRAS","DITTO","EEVEE","VAPOREON",
  "JOLTEON","FLAREON","PORYGON","OMANYTE","OMASTAR","KABUTO","KABUTOPS",
  "AERODACTYL","SNORLAX","ARTICUNO","ZAPDOS","MOLTRES","DRATINI","DRAGONAIR",
  "DRAGONITE","MEWTWO","MEW",
}
local PARTY_ICON_DEX = {}
for dex, species in ipairs(PARTY_ICON_SPECIES) do PARTY_ICON_DEX[species] = dex end

local COLORS = {
  shadow = { 0.02, 0.025, 0.03, 0.72 },
  paper = { 0.965, 0.965, 0.93, 0.97 },
  paper2 = { 0.88, 0.89, 0.84, 0.97 },
  ink = { 0.055, 0.065, 0.07, 1.0 },
  selected = { 0.075, 0.10, 0.12, 1.0 },
  selectedText = { 1.0, 1.0, 0.96, 1.0 },
  accent = { 0.82, 0.16, 0.11, 1.0 },
  enabled = { 0.12, 0.62, 0.27, 1.0 },
  disabled = { 0.88, 0.18, 0.14, 1.0 },
  muted = { 0.25, 0.27, 0.27, 1.0 },
}

local function setColor(c)
  love.graphics.setColor(c[1], c[2], c[3], c[4])
end

local function presentationToken(owner, purpose, identity)
  if type(owner) ~= "table" then return {} end
  local tokens = pokemonPresentationTokens[owner]
  if not tokens then
    tokens = {}
    pokemonPresentationTokens[owner] = tokens
  end
  local key = tostring(purpose or "portrait") .. ":" .. tostring(identity or "")
  if not tokens[key] then tokens[key] = {} end
  return tokens[key]
end

-- Presentation API v1 is the only path allowed to time or decode the
-- standalone Battle Art provider's animations. The second result tells
-- callers that the provider owns the request even when ROM mode/missing art
-- intentionally returns nil.
local function providerPokemonPresentation(game, mon, purpose, token)
  if type(BattleArtProviderPresentation) ~= "function" then return nil, false end
  local ok, result, supported = pcall(BattleArtProviderPresentation,
    game, mon, "front", {
      purpose = purpose or "portrait",
      token = token,
    })
  if not (ok and supported) then return nil, false end
  if type(result) ~= "table" or not result.image
      or type(result.image.getDimensions) ~= "function" then
    return nil, true
  end
  return result, true
end

local function topState(game)
  if not (game and game.stack) then return nil end
  if type(game.stack.top) == "function" then return game.stack:top() end
  local states = game.stack.states
  return type(states) == "table" and states[#states] or nil
end

local function stateInStack(game, wanted)
  local states = game and game.stack and game.stack.states
  if type(states) ~= "table" or wanted == nil then return false end
  for _, state in ipairs(states) do
    if state == wanted then return true end
  end
  return false
end

local function drawPanel(x, y, w, h)
  local g = love.graphics
  setColor(COLORS.shadow)
  g.rectangle("fill", x + 4, y + 5, w, h)
  setColor(COLORS.ink)
  g.rectangle("fill", x, y, w, h)
  setColor(COLORS.paper)
  g.rectangle("fill", x + 2, y + 2, w - 4, h - 4)
  setColor(COLORS.ink)
  g.rectangle("fill", x + 6, y + 6, w - 12, 2)
  g.rectangle("fill", x + 6, y + h - 8, w - 12, 2)
end

local function loadFont(size)
  local g = love and love.graphics
  if not g then return nil end
  local ok, font = pcall(g.newFont, FONT_PATH, size, "mono")
  if not ok or not font then
    ok, font = pcall(g.newFont, size)
  end
  if ok and font and font.setFilter then
    pcall(font.setFilter, font, "nearest", "nearest")
  end
  return ok and font or nil
end

local function cleanLabel(value)
  local text = tostring(value or "")
  -- Menu labels should be one line even when supplied by an external mod.
  text = text:gsub("[\r\n]+", " ")
  return text
end

local function fitLabel(font, value, maxWidth)
  local text = cleanLabel(value)
  if not font or font:getWidth(text) <= maxWidth then return text end
  local suffix = ".."
  while #text > 1 and font:getWidth(text .. suffix) > maxWidth do
    text = text:sub(1, -2)
  end
  return text .. suffix
end

local function updatePresentationScroll(menu, visible)
  local count = #(menu.items or {})
  local index = math.max(1, math.min(tonumber(menu.index) or 1,
                                    math.max(1, count)))
  local maxScroll = math.max(0, count - visible)
  local scroll = math.max(0, math.min(tonumber(menu.__wideUiScroll) or 0,
                                     maxScroll))
  if index <= scroll then
    scroll = index - 1
  elseif index > scroll + visible then
    scroll = index - visible
  end
  menu.__wideUiScroll = math.max(0, math.min(scroll, maxScroll))
  return menu.__wideUiScroll
end

local function drawStartMenu(menu, fonts)
  local g = love.graphics
  -- Keep a generous row pitch so proportional fonts and accented labels have
  -- room at every output resolution. The two-pass row renderer below is also
  -- intentional: every highlight is painted before any label, so a glyph that
  -- extends outside its nominal font box can never be overpainted by the next
  -- row's selection band.
  local x, y, w, h = DESIGN_W - 224, 5, 212, DESIGN_H - 10
  local headerH, footerH, rowH = 31, 24, 22
  local contentTop = y + headerH + 3
  local contentBottom = y + h - footerH - 3
  local visible = math.max(1, math.floor((contentBottom - contentTop) / rowH))
  local items = menu.items or {}
  local scroll = updatePresentationScroll(menu, visible)

  drawPanel(x, y, w, h)

  setColor(COLORS.ink)
  g.setFont(fonts.title)
  g.print("START", x + 14, y + 10)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 83, y + 17, w - 99, 3)

  g.setFont(fonts.body)
  -- Pass 1: selection decoration.
  for slot = 1, visible do
    local itemIndex = scroll + slot
    local item = items[itemIndex]
    if not item then break end
    local ry = contentTop + (slot - 1) * rowH
    if itemIndex == menu.index then
      setColor(COLORS.selected)
      g.rectangle("fill", x + 9, ry + 2, w - 18, rowH - 2)
      setColor(COLORS.accent)
      g.rectangle("fill", x + 9, ry + 2, 4, rowH - 2)
    end
  end

  -- Pass 2: labels. Center using the selected font's actual line height
  -- instead of relying on font-specific baseline offsets.
  local textOffsetY = math.floor((rowH - fonts.body:getHeight()) / 2)
  for slot = 1, visible do
    local itemIndex = scroll + slot
    local item = items[itemIndex]
    if not item then break end
    local ry = contentTop + (slot - 1) * rowH
    if itemIndex == menu.index then
      setColor(COLORS.selectedText)
    else
      setColor(COLORS.ink)
    end
    g.print(cleanLabel(item.label), x + 20, ry + textOffsetY)
  end

  g.setFont(fonts.small)
  if scroll > 0 then
    setColor(COLORS.muted)
    g.print("MORE", x + w - 51, y + headerH - 1)
    g.polygon("fill", x + w - 19, y + headerH + 5,
              x + w - 13, y + headerH + 5,
              x + w - 16, y + headerH + 1)
  end
  if scroll + visible < #items then
    setColor(COLORS.muted)
    g.print("MORE", x + w - 51, y + h - footerH - 12)
    g.polygon("fill", x + w - 19, y + h - footerH - 8,
              x + w - 13, y + h - footerH - 8,
              x + w - 16, y + h - footerH - 4)
  end

  setColor(COLORS.paper2)
  g.rectangle("fill", x + 8, y + h - footerH, w - 16, footerH - 8)
  setColor(COLORS.muted)
  g.print("A  SELECT", x + 14, y + h - footerH + 3)
  local closeText = "B / START  CLOSE"
  g.print(closeText, x + w - 14 - fonts.small:getWidth(closeText),
          y + h - footerH + 3)
end

local function clamp(value, low, high)
  return math.max(low, math.min(high, value))
end

local function monDefinition(game, mon)
  local pokemon = game and game.data and game.data.pokemon
  return pokemon and mon and pokemon[mon.species] or nil
end

local function monName(game, mon)
  local def = monDefinition(game, mon)
  return cleanLabel(mon and (mon.nickname or (def and def.name) or mon.species)
                    or "POKEMON")
end

local function shownHP(menu, mon)
  if menu.heal and menu.heal.mon == mon then
    return math.floor(menu.heal.shown or mon.hp or 0)
  end
  return math.floor(mon.hp or 0)
end

local function hpColor(hp, maximum)
  local ratio = clamp(hp / math.max(1, maximum), 0, 1)
  if ratio <= 0.20 then return { 0.78, 0.15, 0.12, 1 } end
  if ratio <= 0.50 then return { 0.86, 0.62, 0.08, 1 } end
  return { 0.12, 0.62, 0.25, 1 }
end

local function drawHPBar(x, y, w, hp, maximum)
  local g = love.graphics
  local ratio = clamp(hp / math.max(1, maximum), 0, 1)
  setColor(COLORS.ink)
  g.rectangle("fill", x, y, w, 6)
  setColor(COLORS.paper2)
  g.rectangle("fill", x + 1, y + 1, w - 2, 4)
  local fill = math.floor((w - 2) * ratio + 0.5)
  if fill > 0 then
    setColor(hpColor(hp, maximum))
    g.rectangle("fill", x + 1, y + 1, fill, 4)
  end
end

local TYPE_COLORS = {
  NORMAL   = { 0.66, 0.65, 0.48, 1 },
  FIRE     = { 0.93, 0.51, 0.19, 1 },
  WATER    = { 0.39, 0.56, 0.94, 1 },
  ELECTRIC = { 0.97, 0.82, 0.17, 1 },
  GRASS    = { 0.48, 0.78, 0.30, 1 },
  ICE      = { 0.59, 0.85, 0.84, 1 },
  FIGHTING = { 0.76, 0.18, 0.16, 1 },
  POISON   = { 0.64, 0.24, 0.63, 1 },
  GROUND   = { 0.89, 0.75, 0.40, 1 },
  FLYING   = { 0.66, 0.56, 0.95, 1 },
  PSYCHIC  = { 0.98, 0.33, 0.53, 1 },
  BUG      = { 0.65, 0.73, 0.10, 1 },
  ROCK     = { 0.71, 0.63, 0.21, 1 },
  GHOST    = { 0.45, 0.34, 0.59, 1 },
  DRAGON   = { 0.44, 0.21, 0.99, 1 },
  DARK     = { 0.44, 0.34, 0.27, 1 },
  STEEL    = { 0.72, 0.72, 0.81, 1 },
  FAIRY    = { 0.84, 0.52, 0.68, 1 },
}

local LIGHT_TYPE_TEXT = {
  NORMAL = true, ELECTRIC = true, GRASS = true, ICE = true,
  GROUND = true, ROCK = true, STEEL = true,
}

local function normalizedType(typeId)
  return tostring(typeId or "-"):gsub("_TYPE$", ""):gsub("_", " "):upper()
end

local function drawTypeBadge(typeId, fonts, x, y, w, h)
  local g = love.graphics
  local label = normalizedType(typeId)
  local color = TYPE_COLORS[label] or { 0.40, 0.43, 0.45, 1 }
  local badgeFont = (h <= 18 and fonts.tiny) or fonts.small
  setColor(COLORS.ink)
  g.rectangle("fill", x, y, w, h, math.floor(h / 2), math.floor(h / 2))
  setColor(color)
  g.rectangle("fill", x + 1, y + 1, w - 2, h - 2,
              math.floor((h - 2) / 2), math.floor((h - 2) / 2))
  -- Small upper highlight gives the capsule the polished newer-game look
  -- without requiring additional image assets.
  setColor({ 1, 1, 1, 0.22 })
  g.rectangle("fill", x + 4, y + 3, w - 8, 2, 1, 1)
  g.setFont(badgeFont)
  setColor(LIGHT_TYPE_TEXT[label] and COLORS.ink or COLORS.selectedText)
  local tx = x + math.floor((w - badgeFont:getWidth(label)) / 2)
  local ty = y + math.floor((h - badgeFont:getHeight()) / 2)
  g.print(label, tx, ty)
end

local function drawXPBar(x, y, w, ratio)
  local g = love.graphics
  ratio = clamp(tonumber(ratio) or 0, 0, 1)
  setColor(COLORS.ink)
  g.rectangle("fill", x, y, w, 7)
  setColor(COLORS.paper2)
  g.rectangle("fill", x + 1, y + 1, w - 2, 5)
  local fill = math.floor((w - 2) * ratio + 0.5)
  if fill > 0 then
    setColor({ 0.18, 0.52, 0.94, 1 })
    g.rectangle("fill", x + 1, y + 1, fill, 5)
  end
end

-- -------------------------------------------------------------------------
-- Battle HUD
-- -------------------------------------------------------------------------

local function battleShownHP(battler)
  if not battler then return 0 end
  return math.max(0, math.floor(tonumber(battler.shownHP)
    or tonumber(battler.mon and battler.mon.hp) or 0))
end

local function battleMaxHP(battler)
  return math.max(1, math.floor(tonumber(battler and battler.mon
    and battler.mon.stats and battler.mon.stats.hp) or 1))
end

local function battleName(battler)
  return cleanLabel(battler and (battler.name
    or (battler.mon and battler.mon.nickname)
    or (battler.mon and battler.mon.species)) or "POKEMON")
end

local function battleStatus(battle, battler)
  if not (battler and battler.shownStatus) then return nil end
  if battle and type(battle.statusLabel) == "function" then
    local ok, label = pcall(battle.statusLabel, battle,
                            { status = battler.shownStatus })
    if ok and label and label ~= "" then return cleanLabel(label):upper() end
  end
  return cleanLabel(battler.shownStatus):upper()
end

local BATTLE_STATUS_COLORS = {
  PSN = { 0.58, 0.20, 0.68, 1 }, TOX = { 0.58, 0.20, 0.68, 1 },
  PAR = { 0.88, 0.63, 0.06, 1 }, BRN = { 0.88, 0.28, 0.08, 1 },
  FRZ = { 0.16, 0.57, 0.82, 1 }, SLP = { 0.35, 0.38, 0.43, 1 },
}

local function battleStatusColor(label)
  label = tostring(label or ""):upper()
  for key, color in pairs(BATTLE_STATUS_COLORS) do
    if label:find(key, 1, true) then return color end
  end
  return COLORS.muted
end

local function battleEnemyVisible(battle)
  if not (battle and battle.enemy) or battle.showEnemyTrainer
      or battle.enemySendingOut or battle.enemy.fainted
      or battle.introBalls then return false end
  if battle.growInScale then
    local ok, scale = pcall(battle.growInScale, battle, battle.enemy)
    if ok and scale then return false end
  end
  return (tonumber(battle.introSlide) or 0) == 0
end

local function battlePlayerVisible(battle)
  return battle and battle.player and not battle.safari and not battle.demo
    and not battle.showPlayerBack and (tonumber(battle.introSlide) or 0) == 0
end

local function battleExpRatio(battle, battler)
  local mon = battler and battler.mon
  local def = mon and battle and battle.data and battle.data.pokemon
    and battle.data.pokemon[mon.species]
  if not (mon and def) then return 0 end
  return levelExpProgress(battle.game, mon, def)
end

local function drawBattleStatusPanel(battle, battler, fonts,
                                    x, y, w, h, player)
  local g = love.graphics
  drawPanel(x, y, w, h)
  local hp, maximum = battleShownHP(battler), battleMaxHP(battler)

  g.setFont(fonts.small)
  setColor(COLORS.ink)
  local displayName = fitLabel(fonts.small, battleName(battler), w - 76)
  g.print(displayName, x + 13, y + 9)
  local level = tostring((battler.mon and battler.mon.level) or "?")
  local levelText = "Lv." .. level
  g.print(levelText, x + w - 13 - fonts.small:getWidth(levelText), y + 9)

  local status = battleStatus(battle, battler)
  if status then
    local color = battleStatusColor(status)
    setColor(color)
    g.rectangle("fill", x + 13, y + 28, 34, 12, 6, 6)
    g.setFont(fonts.tiny)
    setColor(COLORS.selectedText)
    g.print(fitLabel(fonts.tiny, status, 28), x + 16, y + 29)
  else
    g.setFont(fonts.tiny)
    setColor(COLORS.muted)
    g.print("HP", x + 13, y + 29)
  end

  drawHPBar(x + 50, y + 32, w - 63, hp, maximum)
  if player then
    g.setFont(fonts.small)
    setColor(COLORS.ink)
    local hpText = tostring(hp) .. "/" .. tostring(maximum)
    g.print(hpText, x + w - 13 - fonts.small:getWidth(hpText), y + 42)
    -- Leave a full separator row between EXP and the panel's lower rule.
    -- This avoids the same bottom-edge collision corrected in the Party UI.
    drawXPBar(x + 13, y + h - 18, w - 26, battleExpRatio(battle, battler))
  end
  return {
    x = x, y = y, w = w, h = h,
    name = displayName, nameX = x + 13, nameY = y + 9,
    nameWidth = fonts.small:getWidth(displayName),
  }
end

local function drawBattleHudExtensions(battle, fonts, layout)
  for _, provider in ipairs(battleHudOverlayProviders) do
    if not provider.failed then
      local ok, err = pcall(provider.draw, battle, {
        apiVersion = BATTLE_HUD_OVERLAY_API_VERSION,
        fonts = fonts,
        layout = layout,
        colors = COLORS,
        drawPanel = drawPanel,
      })
      if not ok then
        provider.failed = true
        if battleHudOverlayLogError then
          battleHudOverlayLogError(provider.owner .. ": " .. tostring(err))
        end
      end
    end
  end
end

local function drawWorldHudExtensions(game, fonts, viewW, viewH)
  for _, provider in ipairs(worldHudOverlayProviders) do
    if not provider.failed then
      local ok, err = pcall(provider.draw, game, {
        apiVersion = WORLD_HUD_OVERLAY_API_VERSION,
        fonts = fonts,
        viewW = viewW,
        viewH = viewH,
        colors = COLORS,
        drawPanel = drawPanel,
      })
      if not ok then
        provider.failed = true
        if worldHudOverlayLogError then
          worldHudOverlayLogError(provider.owner .. ": " .. tostring(err))
        end
      end
    end
  end
end

local function drawBattlePartyPips(party, x, y, direction)
  local g = love.graphics
  for i = 1, math.min(6, #(party or {})) do
    local mon = party[i]
    local px = x + (i - 1) * 14 * direction
    setColor(COLORS.ink)
    g.circle("fill", px, y, 5)
    if (tonumber(mon and mon.hp) or 0) <= 0 then
      setColor({ 0.40, 0.41, 0.40, 1 })
    elseif mon and mon.status then
      setColor({ 0.86, 0.52, 0.10, 1 })
    else
      setColor({ 0.82, 0.16, 0.11, 1 })
    end
    g.circle("fill", px, y, 3)
    setColor(COLORS.paper)
    g.rectangle("fill", px - 3, y - 1, 6, 2)
  end
end

local function battleMessageLines(battle)
  if battle and battle.current and battle.current.text then
    battle.__widescreenUiLastMessage = tostring(battle.current.text)
  end
  local text = tostring(battle and battle.__widescreenUiLastMessage or "")
  text = text:gsub("\v", "\n")
  local lines = {}
  for line in (text .. "\n"):gmatch("(.-)\n") do
    lines[#lines + 1] = cleanLabel(line)
  end
  return lines
end

local function drawBattleMessage(battle, fonts, viewW, viewH)
  local g = love.graphics
  local x, y, w, h = 8, viewH - 72, viewW - 16, 64
  drawPanel(x, y, w, h)
  g.setFont(fonts.small)
  setColor(COLORS.ink)
  local lines = battleMessageLines(battle)
  for i = 1, math.min(2, #lines) do
    g.print(fitLabel(fonts.small, lines[i], w - 48), x + 20, y + 10 + (i - 1) * 20)
  end
  if (battle.msgWaiting or battle.msgPrompt)
      and (tonumber(battle.frame) or 0) % 60 < 30 then
    setColor(COLORS.accent)
    g.polygon("fill", x + w - 25, y + h - 24,
              x + w - 13, y + h - 24, x + w - 19, y + h - 16)
  end
end

local function drawBattleChoiceCell(fonts, label, selected, x, y, w, h)
  local g = love.graphics
  setColor(selected and COLORS.selected or COLORS.paper2)
  g.rectangle("fill", x, y, w, h)
  if selected then
    setColor(COLORS.accent)
    g.rectangle("fill", x, y, 5, h)
  end
  g.setFont(fonts.small)
  setColor(selected and COLORS.selectedText or COLORS.ink)
  local text = fitLabel(fonts.small, label, w - 22)
  g.print(text, x + 12, y + math.floor((h - fonts.small:getHeight()) / 2))
end

local function drawBattleCommand(battle, fonts, viewW, viewH)
  local g = love.graphics
  local promptX, menuW, y, h = 8, 382, viewH - 72, 64
  local menuX = viewW - menuW - 8
  local promptW = menuX - promptX - 8
  drawPanel(promptX, y, promptW, h)
  drawPanel(menuX, y, menuW, h)

  if not battle.demo then
    g.setFont(fonts.small)
    setColor(COLORS.ink)
    if battle.safari then
      g.print("SAFARI ZONE", promptX + 16, y + 10)
      g.setFont(fonts.small)
      g.print("BALLS  " .. tostring(battle.safari.balls or 0),
              promptX + 16, y + 34)
    else
      g.print("What will", promptX + 16, y + 10)
      g.print(fitLabel(fonts.small, battleName(battle.player) .. " do?", promptW - 32),
              promptX + 16, y + 34)
    end
  end

  local labels = battle.safari and { "BALL", "BAIT", "ROCK", "RUN" }
    or { "FIGHT", "POKEMON", "BAG", "RUN" }
  local selected = tonumber(battle.menuIndex) or 1
  if battle.demo then
    labels = { "FIGHT", "POKEMON", "BAG", "RUN" }
    selected = (tonumber(battle.demoTimer) or 0) <= 80 and 1 or 3
  end
  local gap, pad = 4, 10
  local cellW = math.floor((menuW - pad * 2 - gap) / 2)
  local cellH = 21
  for i, label in ipairs(labels) do
    local col, row = (i - 1) % 2, math.floor((i - 1) / 2)
    drawBattleChoiceCell(fonts, label, i == selected,
      menuX + pad + col * (cellW + gap), y + 9 + row * (cellH + 4),
      cellW, cellH)
  end
end

local function battleMoveMaxPP(move, def)
  if move and move.maxPP then return tonumber(move.maxPP) or 0 end
  local base = tonumber(def and def.pp) or tonumber(move and move.pp) or 0
  return base + (tonumber(move and move.ppUps) or 0) * math.floor(base / 5)
end

local SNAPSHOT_POWER_KINDS = {
  base = true, status = true, fixed = true, special = true,
}
local SNAPSHOT_ACCURACY_KINDS = {
  percent = true, always = true, unavailable = true,
}

local function validateMoveInspectorSnapshot(value)
  if type(value) ~= "table" then return nil, "snapshot must be a table" end
  if value.schemaVersion ~= 1 then return nil, "unsupported snapshot schemaVersion" end
  if value.phase ~= "moveSelect" then return nil, "snapshot phase must be moveSelect" end
  if type(value.selectedIndex) ~= "number" then return nil, "selectedIndex must be numeric" end
  if type(value.moveId) ~= "string" or type(value.moveName) ~= "string" then
    return nil, "moveId and moveName must be strings"
  end
  if type(value.typeId) ~= "string" then return nil, "typeId must be a string" end
  if type(value.pp) ~= "table" or type(value.pp.current) ~= "number"
      or type(value.pp.maximum) ~= "number" then
    return nil, "pp.current and pp.maximum must be numeric"
  end
  if type(value.power) ~= "table" or not SNAPSHOT_POWER_KINDS[value.power.kind]
      or type(value.power.label) ~= "string" then
    return nil, "invalid power descriptor"
  end
  if type(value.accuracy) ~= "table"
      or not SNAPSHOT_ACCURACY_KINDS[value.accuracy.kind]
      or type(value.accuracy.label) ~= "string" then
    return nil, "invalid accuracy descriptor"
  end
  if type(value.matchup) ~= "table" or type(value.matchup.factor) ~= "number"
      or type(value.matchup.label) ~= "string"
      or type(value.matchup.multiplierLabel) ~= "string" then
    return nil, "invalid matchup descriptor"
  end
  if type(value.stab) ~= "table" or type(value.stab.applies) ~= "boolean" then
    return nil, "invalid STAB descriptor"
  end
  if type(value.disabled) ~= "boolean" then return nil, "disabled must be boolean" end
  return value
end

local function activeMoveInspectorSnapshot(battle)
  local provider = battleMoveInspectorProvider
  if not provider then return nil end
  local ok, value, reason = pcall(provider.snapshot, battle)
  if not ok then
    if battleMoveInspectorLogError then
      battleMoveInspectorLogError("provider exception: " .. tostring(value))
    end
    return nil
  end
  if value == nil then
    if reason and battleMoveInspectorLogError then
      battleMoveInspectorLogError("provider returned no snapshot: " .. tostring(reason))
    end
    return nil
  end
  local snapshot, invalid = validateMoveInspectorSnapshot(value)
  if not snapshot and battleMoveInspectorLogError then
    battleMoveInspectorLogError("invalid provider snapshot: " .. tostring(invalid))
  end
  return snapshot
end

local function drawBattleMoves(battle, fonts, moves, selected, allowInspector,
                               viewW, viewH)
  local g = love.graphics
  local x, y, w, h = 8, viewH - 116, viewW - 16, 108
  drawPanel(x, y, w, h)
  local detailW, gap = 150, 5
  local listX, listY, cellH = x + 12, y + 12, 38
  local detailX = x + w - detailW - 12
  local listW = detailX - listX - 18
  local cellW = math.floor((listW - gap) / 2)
  selected = clamp(tonumber(selected) or 1, 1, math.max(1, #(moves or {})))
  for i = 1, 4 do
    local move = moves and moves[i]
    local col, row = (i - 1) % 2, math.floor((i - 1) / 2)
    local cx, cy = listX + col * (cellW + gap), listY + row * (cellH + gap)
    local def = move and battle.data and battle.data.moves
      and battle.data.moves[move.id]
    local label = def and def.name or (move and move.id) or "-"
    drawBattleChoiceCell(fonts, label, i == selected, cx, cy, cellW, cellH)
    if battle.moveSwapIndex == i and i ~= selected then
      setColor(COLORS.accent)
      g.rectangle("line", cx + 2, cy + 2, cellW - 4, cellH - 4)
    end
  end

  local snapshot = allowInspector and activeMoveInspectorSnapshot(battle) or nil
  local move = moves and moves[selected]
  local def = move and battle.data and battle.data.moves
    and battle.data.moves[move.id]
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print(snapshot and "MOVE INSPECTOR" or "MOVE INFO", detailX, y + 8)
  if snapshot then
    drawTypeBadge(snapshot.typeId, fonts, detailX, y + 25, 132, 16)
    g.setFont(fonts.tiny)
    setColor(COLORS.ink)
    g.print("PP  " .. tostring(snapshot.pp.current) .. "/"
      .. tostring(snapshot.pp.maximum), detailX, y + 45)
    local stats = "POW " .. snapshot.power.label
      .. "  ACC " .. snapshot.accuracy.label
    g.print(fitLabel(fonts.tiny, stats, 150), detailX, y + 59)
    local matchup = snapshot.matchup.label .. " "
      .. snapshot.matchup.multiplierLabel
    g.print(fitLabel(fonts.tiny, matchup, 150), detailX, y + 73)
    local flags = {}
    if snapshot.stab.applies then flags[#flags + 1] = snapshot.stab.label or "STAB" end
    if snapshot.disabled then flags[#flags + 1] = "DISABLED" end
    if #flags > 0 then
      setColor(snapshot.disabled and COLORS.accent or COLORS.muted)
      g.print(table.concat(flags, "  "), detailX, y + 87)
    end
  elseif def then
    drawTypeBadge(def.type, fonts, detailX, y + 28, 132, 16)
    g.setFont(fonts.small)
    setColor(COLORS.ink)
    local pp = "PP  " .. tostring(move.pp or 0) .. "/" .. tostring(battleMoveMaxPP(move, def))
    g.print(pp, detailX, y + 51)
    if battle.player and battle.player.disabledSlot == selected then
      setColor(COLORS.accent)
      g.print("DISABLED", detailX, y + 72)
    end
  end
end

local function drawBattleHUD(battle, fonts, viewW, viewH)
  if not battle or battle.blankForAskName then return end
  local layout = { viewW = viewW, viewH = viewH }
  if battleEnemyVisible(battle) then
    layout.enemy = drawBattleStatusPanel(
      battle, battle.enemy, fonts, 12, 10, 190, 52, false)
  end
  if battlePlayerVisible(battle) then
    -- Alpha 8.2 docks this panel above the command area. Move selection uses a
    -- taller inspector surface, so lift it without changing arena ownership.
    local panelLift = (battle.phase == "moveSelect" or battle.phase == "mimicSelect")
      and 192 or 148
    drawBattleStatusPanel(battle, battle.player, fonts,
                          viewW - 198, viewH - panelLift, 190, 72, true)
  end
  if battle.introBalls then
    drawBattlePartyPips(battle.enemyParty, 94, 82, -1)
    drawBattlePartyPips(battle.playerParty
      or (battle.game and battle.game.save and battle.game.save.party),
      viewW - 94, viewH - 204, 1)
  elseif battle.showEnemyBalls then
    drawBattlePartyPips(battle.enemyParty, 94, 25, -1)
  end

  if battle.phase == "messages"
      and (battle.current or battle.animPlaying or battle.msgHold
        or battle.__widescreenUiLastMessage) then
    drawBattleMessage(battle, fonts, viewW, viewH)
  elseif battle.phase == "menu" then
    drawBattleCommand(battle, fonts, viewW, viewH)
  elseif battle.phase == "moveSelect" then
    drawBattleMoves(battle, fonts,
      battle.player and battle.player.curMoves, battle.moveIndex, true,
      viewW, viewH)
  elseif battle.phase == "mimicSelect" then
    drawBattleMoves(battle, fonts, battle.mimicMoves, battle.mimicIndex, false,
                    viewW, viewH)
  end
  if layout.enemy then drawBattleHudExtensions(battle, fonts, layout) end
end

local function wrapRenderedText(font, text, maxWidth)
  text = tostring(text or ""):gsub("\v", "\n"):gsub("\f", "\n")
  local lines = {}
  for paragraph in (text .. "\n"):gmatch("(.-)\n") do
    local line = ""
    for word in paragraph:gmatch("%S+") do
      local candidate = line == "" and word or (line .. " " .. word)
      if line ~= "" and font:getWidth(candidate) > maxWidth then
        lines[#lines + 1] = line
        line = word
      else
        line = candidate
      end
    end
    if line ~= "" then lines[#lines + 1] = line end
  end
  return lines
end

local function drawPokedexHeader(fonts, title, page)
  local g = love.graphics
  setColor({ COLORS.paper[1], COLORS.paper[2], COLORS.paper[3], 1 })
  g.rectangle("fill", 0, 0, DESIGN_W, DESIGN_H)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print(cleanLabel(title or "POKEDEX"), 20, 14)
  setColor(COLORS.accent)
  g.rectangle("fill", 184, 30, 270, 3)
  if page then
    g.setFont(fonts.small)
    setColor(COLORS.muted)
    g.print(page, DESIGN_W - 20 - fonts.small:getWidth(page), 17)
  end
end

local function drawPokedexList(state, fonts, model)
  local g = love.graphics
  local rows = model and model.rows or state.items or {}
  local index = tonumber(model and model.index or state.index) or 1
  local scroll = tonumber(model and model.scroll or state.scroll) or 0
  local title = model and model.title or state.title or "POKEDEX"
  drawPokedexHeader(fonts, title)
  local x, y, w, h = 20, 52, 600, 266
  drawPanel(x, y, w, h)
  local visible, rowH = 7, 34
  for row = 1, visible do
    local i = scroll + row
    local item = rows[i]
    if not item then break end
    local ry = y + 11 + (row - 1) * rowH
    local selected = i == index
    setColor(selected and COLORS.selected or COLORS.paper2)
    g.rectangle("fill", x + 10, ry, w - 20, rowH - 4)
    if selected then
      setColor(COLORS.accent)
      g.rectangle("fill", x + 10, ry, 5, rowH - 4)
    end
    g.setFont(fonts.small)
    setColor(selected and COLORS.selectedText or COLORS.ink)
    local label = cleanLabel(item.label or "")
    g.print(fitLabel(fonts.small, label, w - 150), x + 25, ry + 6)
    local value = item.value or item.right
    if value ~= nil and type(value) ~= "table" then
      local valueText = cleanLabel(value)
      g.print(valueText, x + w - 26 - fonts.small:getWidth(valueText), ry + 6)
    end
    if item.marker or item.ball then
      local bx, by = x + w - 112, ry + 14
      setColor(selected and COLORS.selectedText or COLORS.ink)
      g.circle("line", bx, by, 5)
      g.rectangle("fill", bx - 5, by - 1, 10, 2)
      g.circle("fill", bx, by, 2)
    end
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  local footer = model and model.footer or state.footer
  if type(footer) == "table" then footer = table.concat(footer, "     ") end
  footer = cleanLabel(footer or "A OPEN     B BACK")
  g.print(fitLabel(fonts.tiny, footer, DESIGN_W - 40), 20, 334)
end

local function providerPokedexRegions(state)
  local regions = {}
  if type(state) == "table" then PokedexProviderUI.hitRegions[state] = regions end
  return regions
end

local function addPokedexRegion(regions, x, y, w, h, action, value)
  regions[#regions + 1] = {
    x = math.floor(x), y = math.floor(y),
    w = math.floor(w), h = math.floor(h),
    action = action, value = value,
  }
end

local function providerVisibleRange(rows, selected, requestedScroll, visible)
  local count = #(rows or {})
  selected = clamp(math.floor(tonumber(selected) or 1), 1, math.max(1, count))
  local scroll = clamp(math.floor(tonumber(requestedScroll) or 0),
    0, math.max(0, count - visible))
  if selected <= scroll then scroll = selected - 1 end
  if selected > scroll + visible then scroll = selected - visible end
  return selected, clamp(scroll, 0, math.max(0, count - visible))
end

local function providerTrackedRange(state, key, rows, selected,
                                    requestedScroll, visible)
  if type(state) ~= "table" then
    return providerVisibleRange(rows, selected, requestedScroll, visible)
  end
  local views = PokedexProviderUI.views[state]
  if not views then
    views = {}
    PokedexProviderUI.views[state] = views
  end
  local view = views[key]
  local count = #(rows or {})
  selected = clamp(math.floor(tonumber(selected) or 1), 1, math.max(1, count))
  requestedScroll = clamp(math.floor(tonumber(requestedScroll) or 0),
    0, math.max(0, count - visible))
  if not view then
    view = { selected = selected, requested = requestedScroll,
      scroll = requestedScroll }
    views[key] = view
  elseif requestedScroll ~= view.requested then
    -- Provider pageUp/pageDown/scroll changed the explicit viewport.
    view.scroll = requestedScroll
  elseif selected ~= view.selected then
    -- Provider up/down/selectRow changed focus; reveal that row without
    -- writing presentation state back into the immutable snapshot.
    if selected <= view.scroll then view.scroll = selected - 1 end
    if selected > view.scroll + visible then view.scroll = selected - visible end
  end
  view.selected, view.requested = selected, requestedScroll
  view.scroll = clamp(view.scroll, 0, math.max(0, count - visible))
  return selected, view.scroll
end

local function providerEntryViewport(state, snapshot, lineCount)
  local maxOffset = math.max(0, (tonumber(lineCount) or 0) - 5)
  if type(state) ~= "table" then
    return { offset = 0, maxOffset = maxOffset, focused = false,
      available = maxOffset > 0 }
  end
  local views = PokedexProviderUI.views[state]
  if not views then
    views = {}
    PokedexProviderUI.views[state] = views
  end
  local detail = type(snapshot.detail) == "table" and snapshot.detail or {}
  local selected = math.floor(tonumber(snapshot.selectedIndex) or 1)
  local selectedRow = type(snapshot.rows) == "table" and snapshot.rows[selected]
  local speciesKey = tostring(detail.speciesId or snapshot.selectedSpeciesId
    or (type(selectedRow) == "table" and selectedRow.speciesId)
    or detail.number or selected)
  local view = views.entryViewport
  if not view or view.speciesKey ~= speciesKey then
    -- A newly selected species always opens at the beginning. This prevents a
    -- long entry's offset from hiding the first lines of the next species.
    view = { speciesKey = speciesKey, offset = 0, focused = false }
    views.entryViewport = view
  end
  view.maxOffset = maxOffset
  view.offset = clamp(math.floor(tonumber(view.offset) or 0), 0, maxOffset)
  view.available = maxOffset > 0 and snapshot.submenu == nil
  if not view.available then view.focused = false end
  return view
end

PokedexProviderUI.applyEntryAction = function(state, action, value)
  local views = type(state) == "table" and PokedexProviderUI.views[state]
  local view = views and views.entryViewport
  if not (view and view.available and (view.maxOffset or 0) > 0) then
    return false
  end
  if action == "entryFocus" then
    view.focused = value == nil and not view.focused or value and true or false
  elseif action == "entryBlur" then
    view.focused = false
  elseif action == "entryScroll" then
    view.focused = true
    view.offset = clamp((view.offset or 0) + (tonumber(value) or 0),
      0, view.maxOffset)
  else
    return false
  end
  return true
end

local function drawProviderPokemonPortrait(game, state, detail, x, y, w, h)
  if type(detail) ~= "table" or detail.hidden or detail.seen == false then
    return false
  end
  local portrait = detail.portrait
  if type(portrait) ~= "table" or portrait.kind ~= "pokemon"
      or type(portrait.speciesId) ~= "string" then return false end
  -- Deliberately species-only: no DVs, shiny flag or party identity reaches
  -- the art provider. This is the normal Pokedex specimen, never an inference
  -- about an owned Pokemon and never a flattened Stadium model.
  local mon = { species = portrait.speciesId, shiny = false }
  local image = selectedBattleSpriteImage(game, mon, "pokedex", state)
  if not (image and type(image.getDimensions) == "function") then return false end
  local sw, sh = image:getDimensions()
  if not sw or not sh or sw <= 0 or sh <= 0 then return false end
  if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
  local scale = math.min(w / sw, h / sh)
  local dx = math.floor(x + (w - sw * scale) / 2)
  local dy = math.floor(y + (h - sh * scale) / 2)
  setColor({ 1, 1, 1, 1 })
  love.graphics.draw(image, dx, dy, 0, scale, scale)
  return true
end

local function pokedexCountText(counts)
  counts = type(counts) == "table" and counts or {}
  return ("SEEN %03d     OWN %03d     TOTAL %03d"):format(
    tonumber(counts.seen) or 0, tonumber(counts.owned) or 0,
    tonumber(counts.total) or 0)
end

local function drawPokedexProviderMain(game, state, snapshot, fonts)
  local g = love.graphics
  local regions = providerPokedexRegions(state)
  drawPokedexHeader(fonts, snapshot.title or "POKEDEX")
  local listX, listY, listW, listH = 20, 52, 260, 266
  local detailX, detailY, detailW, detailH = 292, 52, 328, 266
  drawPanel(listX, listY, listW, listH)
  drawPanel(detailX, detailY, detailW, detailH)

  local rows = snapshot.rows or {}
  local visible, rowH = 8, 29
  local selected, scroll = providerTrackedRange(state, "pokedex",
    rows, snapshot.selectedIndex, snapshot.scroll, visible)
  for row = 1, visible do
    local index = scroll + row
    local item = rows[index]
    if not item then break end
    local ry = listY + 10 + (row - 1) * rowH
    local focused = index == selected
    setColor(focused and COLORS.selected or COLORS.paper2)
    g.rectangle("fill", listX + 9, ry, listW - 18, rowH - 3)
    if focused then
      setColor(COLORS.accent)
      g.rectangle("fill", listX + 9, ry, 5, rowH - 3)
    end
    g.setFont(fonts.small)
    setColor(focused and COLORS.selectedText or COLORS.ink)
    local number = tostring(item.number or "---")
    local name = (item.hidden or item.seen == false) and "?????"
      or tostring(item.name or "UNKNOWN")
    g.print(fitLabel(fonts.small, number .. "  " .. name, listW - 62),
      listX + 22, ry + 5)
    if item.owned then
      local bx, by = listX + listW - 25, ry + 12
      g.circle("line", bx, by, 5)
      g.rectangle("fill", bx - 5, by - 1, 10, 2)
      g.circle("fill", bx, by, 2)
    end
    addPokedexRegion(regions, listX + 9, ry, listW - 18, rowH - 3,
      "selectRow", index)
  end

  local detail = type(snapshot.detail) == "table" and snapshot.detail or {}
  local hidden = detail.hidden or detail.seen == false
  if hidden then
    -- Privacy transitions also retire any viewport that belonged to the
    -- previously visible species; hidden details expose neither stale text
    -- focus nor scroll controls.
    providerEntryViewport(state, snapshot, 0)
  end
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  local detailName = hidden and "?????" or tostring(detail.name or "UNKNOWN")
  g.print(fitLabel(fonts.body, detailName, 178), detailX + 17, detailY + 15)
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print("No. " .. tostring(detail.number or "---"), detailX + 18, detailY + 43)

  if hidden then
    g.setFont(fonts.body)
    setColor(COLORS.muted)
    g.print("?", detailX + 236, detailY + 79)
    g.setFont(fonts.small)
    local hiddenMessage = snapshot.providerError and "PROVIDER DATA UNAVAILABLE"
      or "NO DATA RECORDED"
    g.print(hiddenMessage, detailX + 18, detailY + 113)
    if snapshot.providerError then
      local lines = wrapRenderedText(fonts.tiny, snapshot.providerError,
        detailW - 36)
      g.setFont(fonts.tiny)
      for i = 1, math.min(5, #lines) do
        g.print(lines[i], detailX + 18, detailY + 145 + (i - 1) * 15)
      end
    end
  else
    drawProviderPokemonPortrait(game, state, detail,
      detailX + 185, detailY + 13, 125, 126)
    g.setFont(fonts.small)
    setColor(COLORS.ink)
    if detail.kind then
      g.print(fitLabel(fonts.small, detail.kind, 166),
        detailX + 18, detailY + 70)
    end
    if detail.height then
      local height = detail.height.metres and
        (tostring(detail.height.metres) .. " m") or
        ((tostring(detail.height.feet or "-") .. "' " ..
          tostring(detail.height.inches or 0) .. '\"'))
      g.print("HT  " .. height, detailX + 18, detailY + 94)
    end
    if detail.weight then
      local weight = detail.weight.kilograms and
        (tostring(detail.weight.kilograms) .. " kg") or
        (tostring(detail.weight.pounds or "-") .. " lb")
      g.print("WT  " .. weight, detailX + 18, detailY + 116)
    end
    local entry = detail.owned == false
      and tostring(detail.entry or "CATCH THIS POKEMON TO UNLOCK RESEARCH")
      or tostring(detail.entry or "DATA UNAVAILABLE")
    local lines = wrapRenderedText(fonts.small, entry, detailW - 54)
    local entryView = providerEntryViewport(state, snapshot, #lines)
    local entryX, entryY, entryW, entryH =
      detailX + 12, detailY + 145, detailW - 24, 98
    -- The broad detail action remains available outside the entry viewport.
    -- Entry-specific regions are registered afterwards and therefore receive
    -- pointer priority in the reverse-order hit test.
    addPokedexRegion(regions, detailX + 8, detailY + 8,
      detailW - 16, detailH - 16, "select")
    if entryView.maxOffset > 0 then
      setColor(entryView.focused and COLORS.accent or COLORS.muted)
      g.rectangle("line", entryX, entryY, entryW, entryH)
      addPokedexRegion(regions, entryX, entryY, entryW, entryH,
        "entryFocus", true)
    end
    setColor(detail.owned == false and COLORS.muted or COLORS.ink)
    for i = 1, 5 do
      local line = lines[entryView.offset + i]
      if not line then break end
      g.print(line, detailX + 18, detailY + 151 + (i - 1) * 18)
    end
    local arrowX = detailX + detailW - 18
    if entryView.offset > 0 then
      setColor(entryView.focused and COLORS.accent or COLORS.muted)
      g.polygon("fill", arrowX - 5, entryY + 12,
        arrowX + 5, entryY + 12, arrowX, entryY + 5)
      addPokedexRegion(regions, arrowX - 11, entryY,
        22, 24, "entryScroll", -1)
    end
    if entryView.offset < entryView.maxOffset then
      setColor(entryView.focused and COLORS.accent or COLORS.muted)
      g.polygon("fill", arrowX - 5, entryY + entryH - 12,
        arrowX + 5, entryY + entryH - 12, arrowX, entryY + entryH - 5)
      addPokedexRegion(regions, arrowX - 11, entryY + entryH - 24,
        22, 24, "entryScroll", 1)
    end
  end

  if type(snapshot.submenu) == "table" then
    local submenu = snapshot.submenu
    local menuX, menuY, menuW, menuH = detailX + 85, detailY + 38, 226, 210
    drawPanel(menuX, menuY, menuW, menuH)
    g.setFont(fonts.small)
    setColor(COLORS.ink)
    g.print("RESEARCH", menuX + 16, menuY + 13)
    local menuRows = submenu.rows or {}
    for i = 1, math.min(5, #menuRows) do
      local item = menuRows[i]
      local ry = menuY + 40 + (i - 1) * 31
      local focused = i == (tonumber(submenu.selectedIndex) or 1)
      setColor(focused and COLORS.selected or COLORS.paper2)
      g.rectangle("fill", menuX + 10, ry, menuW - 20, 27)
      if focused then
        setColor(COLORS.accent)
        g.rectangle("fill", menuX + 10, ry, 5, 27)
      end
      g.setFont(fonts.small)
      setColor(focused and COLORS.selectedText or COLORS.ink)
      g.print(fitLabel(fonts.small, item.label or item.id, menuW - 45),
        menuX + 24, ry + 5)
      addPokedexRegion(regions, menuX + 10, ry, menuW - 20, 27,
        "selectSubmenu", i)
    end
  end

  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  g.print(pokedexCountText(snapshot.counts), 20, 334)
  local entryViews = type(state) == "table" and PokedexProviderUI.views[state]
  local entryView = entryViews and entryViews.entryViewport
  local controls
  if snapshot.submenu then
    controls = "A OPEN     B CLOSE"
  elseif entryView and entryView.focused then
    controls = "UP/DOWN SCROLL     A/B/SELECT DONE"
  elseif entryView and entryView.available then
    controls = "SELECT ENTRY     A DETAILS     B BACK"
  else
    controls = "A DETAILS     B BACK"
  end
  g.print(controls, DESIGN_W - 20 - fonts.tiny:getWidth(controls), 334)
end

local function providerRowDisplay(row)
  if type(row) ~= "table" then return "DATA UNAVAILABLE" end
  return tostring(row.label or row.message or "DATA UNAVAILABLE")
end

local function drawPokedexResearchRow(snapshot, row, fonts, x, y, w, h, focused)
  local g = love.graphics
  local kind = tostring(row.kind or "message")
  setColor(focused and COLORS.selected or COLORS.paper2)
  g.rectangle("fill", x, y, w, h)
  if focused then
    setColor(COLORS.accent)
    g.rectangle("fill", x, y, 5, h)
  end
  local ink = focused and COLORS.selectedText or COLORS.ink
  g.setFont(fonts.small)
  setColor(ink)
  if snapshot.screen == "pokedex_habitat" and kind == "habitat" then
    g.print(fitLabel(fonts.small, row.mapName or row.mapId, w - 310), x + 14, y + 5)
    g.print(fitLabel(fonts.small, row.method or "UNKNOWN", 92), x + 240, y + 5)
    local levels = ("Lv.%s-%s"):format(tostring(row.minLevel or "-"),
      tostring(row.maxLevel or "-"))
    g.print(levels, x + 342, y + 5)
    local chance = tonumber(row.slotChance)
    local chanceText = chance and (("%.1f%%"):format(chance)) or "—"
    g.print(chanceText, x + w - 14 - fonts.small:getWidth(chanceText), y + 5)
  elseif snapshot.screen == "pokedex_learnset" and kind == "section" then
    setColor(COLORS.accent)
    g.print(fitLabel(fonts.small, row.label or "MOVES", w - 28), x + 14, y + 5)
  elseif snapshot.screen == "pokedex_learnset" and kind == "move" then
    g.print(fitLabel(fonts.small, row.levelLabel or "—", 62), x + 14, y + 5)
    g.print(fitLabel(fonts.small, row.moveName or row.moveId, 190), x + 82, y + 5)
    drawTypeBadge(row.typeId or row.typeName, fonts, x + 282, y + 4, 74, h - 8)
    local meta = {}
    if row.power ~= nil then meta[#meta + 1] = "PWR " .. tostring(row.power) end
    if row.accuracy ~= nil then meta[#meta + 1] = "ACC " .. tostring(row.accuracy) end
    if row.pp ~= nil then meta[#meta + 1] = "PP " .. tostring(row.pp) end
    g.setFont(fonts.tiny)
    setColor(ink)
    local value = table.concat(meta, "  ")
    g.print(fitLabel(fonts.tiny, value, w - 382), x + 370, y + 8)
  elseif snapshot.screen == "pokedex_evolution" and kind == "evolution" then
    local target = row.targetHidden and "?????" or
      tostring(row.targetName or row.targetSpeciesId or "?????")
    g.print(fitLabel(fonts.small, target, 200), x + 14, y + 5)
    g.print(fitLabel(fonts.small, row.method or "DATA INCOMPLETE", w - 240),
      x + 224, y + 5)
  else
    g.print(fitLabel(fonts.small, providerRowDisplay(row), w - 28), x + 14, y + 5)
  end
end

local function drawPokedexProviderResearch(state, snapshot, fonts)
  local g = love.graphics
  local regions = providerPokedexRegions(state)
  local modeName = tostring(snapshot.screen or "pokedex"):gsub("^pokedex_", ""):upper()
  drawPokedexHeader(fonts, "POKEDEX / " .. modeName,
    tostring(snapshot.number or "---") .. "  " .. tostring(snapshot.name or "UNKNOWN"))
  local x, y, w, h = 20, 52, 600, 266
  drawPanel(x, y, w, h)
  if snapshot.gated then
    g.setFont(fonts.body)
    setColor(COLORS.muted)
    local message = fitLabel(fonts.body,
      snapshot.message or "RESEARCH DATA LOCKED", w - 60)
    g.print(message, x + math.floor((w - fonts.body:getWidth(message)) / 2), y + 112)
  elseif snapshot.screen == "pokedex_stats" then
    local types = snapshot.types or {}
    for i = 1, math.min(2, #types) do
      drawTypeBadge(types[i].id or types[i].name, fonts,
        x + 18 + (i - 1) * 91, y + 15, 82, 20)
    end
    local rows = snapshot.rows or {}
    for i = 1, math.min(6, #rows) do
      local row = rows[i]
      local ry = y + 48 + (i - 1) * 33
      setColor(COLORS.paper2)
      g.rectangle("fill", x + 16, ry, w - 32, 28)
      g.setFont(fonts.small)
      setColor(COLORS.ink)
      g.print(fitLabel(fonts.small, row.label or row.id, 150), x + 30, ry + 5)
      local numeric = tonumber(row.value)
      if numeric ~= numeric or numeric == math.huge or numeric == -math.huge then
        numeric = nil
      end
      local display = numeric ~= nil and tostring(numeric) or "—"
      g.print(display, x + 196 - fonts.small:getWidth(display), ry + 5)
      if row.kind ~= "total" and numeric then
        local barX, barW = x + 224, w - 258
        setColor({ 0.74, 0.75, 0.70, 1 })
        g.rectangle("fill", barX, ry + 8, barW, 12)
        setColor(COLORS.enabled)
        g.rectangle("fill", barX, ry + 8,
          math.floor(barW * clamp(numeric / 255, 0, 1)), 12)
      end
    end
  else
    local rows = snapshot.rows or {}
    local visible, rowH = 7, 32
    local selected, scroll = providerTrackedRange(state, snapshot.screen,
      rows, snapshot.selectedIndex, snapshot.scroll, visible)
    for rowIndex = 1, visible do
      local index = scroll + rowIndex
      local row = rows[index]
      if not row then break end
      local ry = y + 13 + (rowIndex - 1) * rowH
      drawPokedexResearchRow(snapshot, row, fonts,
        x + 13, ry, w - 26, rowH - 4, index == selected)
      addPokedexRegion(regions, x + 13, ry, w - 26, rowH - 4,
        index < selected and "up" or index > selected and "down" or "select")
    end
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  g.print("UP / DOWN  SCROLL     LEFT / RIGHT  PAGE", 20, 334)
  local controls = "B BACK"
  g.print(controls, DESIGN_W - 20 - fonts.tiny:getWidth(controls), 334)
end

PokedexProviderUI.draw = function(game, state, snapshot, fonts)
  if snapshot.screen == "pokedex" then
    drawPokedexProviderMain(game, state, snapshot, fonts)
  else
    drawPokedexProviderResearch(state, snapshot, fonts)
  end
end

local function drawWithPalette(image, palette, drawFn, keyed)
  local g = love.graphics
  local applied = false
  local shaderFactory = keyed and PaletteFX and PaletteFX.keyedShader
    or PaletteFX and PaletteFX.shader
  if palette and type(shaderFactory) == "function"
      and type(PaletteFX.sendColors) == "function"
      and type(g.setShader) == "function" then
    local okShader, shader = pcall(shaderFactory)
    if okShader and shader then
      local ok = pcall(PaletteFX.sendColors, shader, palette)
      if ok then
        g.setShader(shader)
        applied = true
      end
    end
  end
  drawFn()
  if applied then g.setShader() end
end

local function drawPokedexEntry(state, fonts)
  local g = love.graphics
  local def = state.def or {}
  local game = state.game or {}
  local entry = def.dexEntry or {}
  local digits = game.data and game.data.constants
    and game.data.constants.dexDigits or 3
  drawPokedexHeader(fonts, "POKEMON DATA")
  drawPanel(20, 52, 228, 266)
  drawPanel(260, 52, 360, 266)

  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print(fitLabel(fonts.body, def.name or "UNKNOWN", 196), 36, 68)
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print(("No.%0" .. tostring(digits) .. "d"):format(def.dex or 0), 36, 96)
  local pokemonDrawn = false
  if def.id then
    local token = presentationToken(state, "pokedex", def.id)
    local presentation = providerPokemonPresentation(
      game, { species = def.id }, "pokedex", token)
    local providerImage = presentation and presentation.image
    if providerImage and type(providerImage.getDimensions) == "function" then
      local sw, sh = providerImage:getDimensions()
      if sw > 0 and sh > 0 then
        local scale = math.min(196 / sw, 156 / sh)
        local dx = 36 + (196 - sw * scale) / 2
        local dy = 116 + (156 - sh * scale) / 2
        if providerImage.setFilter then
          pcall(providerImage.setFilter, providerImage, "nearest", "nearest")
        end
        setColor({ 1, 1, 1, 1 })
        g.draw(providerImage, math.floor(dx), math.floor(dy), 0, scale, scale)
        pokemonDrawn = true
      end
    end
  end
  if not pokemonDrawn and state.sprite
      and type(state.sprite.getDimensions) == "function" then
    local sw, sh = state.sprite:getDimensions()
    if sw > 0 and sh > 0 then
      local scale = math.min(176 / sw, 156 / sh)
      local dx = 134 - sw * scale / 2
      local dy = 202 - sh * scale / 2
      if state.sprite.setFilter then pcall(state.sprite.setFilter, state.sprite, "nearest", "nearest") end
      setColor({ 1, 1, 1, 1 })
      local palette = PaletteFX and PaletteFX.monPal
        and PaletteFX.monPal(game.data, def.id) or nil
      drawWithPalette(state.sprite, palette, function()
        g.draw(state.sprite, math.floor(dx), math.floor(dy), 0, scale, scale)
      end)
    end
  end

  g.setFont(fonts.small)
  setColor(COLORS.ink)
  g.print(fitLabel(fonts.small, entry.kind or "UNKNOWN", 320), 278, 72)
  local owned = state.forceOwned or (game.save and game.save.pokedex
    and game.save.pokedex.owned and game.save.pokedex.owned[def.id])
  if owned and entry.heightFt then
    local height = entry.heightM and string.format("HEIGHT  %.1fm", entry.heightM)
      or string.format("HEIGHT  %d'%02d\"", entry.heightFt, entry.heightIn or 0)
    local weight = entry.weightKg and string.format("WEIGHT  %.1fkg", entry.weightKg)
      or string.format("WEIGHT  %.1flb", (entry.weight or 0) / 10)
    g.print(height, 278, 102)
    g.print(weight, 278, 124)
  end
  local text = owned and entry.text and game.data and game.data.text
    and game.data.text[entry.text] or "DATA UNKNOWN."
  local lines = wrapRenderedText(fonts.small, text, 322)
  for i = 1, math.min(7, #lines) do
    g.print(lines[i], 278, 160 + (i - 1) * 20)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  g.print("A / B  BACK", 20, 334)
end

local function drawImageContained(image, x, y, w, h, maxScale, palette, keyed)
  if not (image and type(image.getDimensions) == "function") then return end
  local iw, ih = image:getDimensions()
  if iw <= 0 or ih <= 0 then return end
  local scale = math.min(w / iw, h / ih, maxScale or math.huge)
  if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
  setColor({ 1, 1, 1, 1 })
  drawWithPalette(image, palette, function()
    love.graphics.draw(image,
      math.floor(x + (w - iw * scale) / 2),
      math.floor(y + (h - ih * scale) / 2), 0, scale, scale)
  end, keyed)
end

local function drawImageGrounded(image, x, bottom, w, h, maxScale, palette, keyed)
  if not (image and type(image.getDimensions) == "function") then return end
  local iw, ih = image:getDimensions()
  if iw <= 0 or ih <= 0 then return end
  local scale = math.min(w / iw, h / ih, maxScale or math.huge)
  if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
  setColor({ 1, 1, 1, 1 })
  drawWithPalette(image, palette, function()
    love.graphics.draw(image, math.floor(x + (w - iw * scale) / 2),
      math.floor(bottom - ih * scale), 0, scale, scale)
  end, keyed)
end

-- TitleState's ribbon image is an 80x8 source strip. Blue uses its first
-- 64 pixels; Red composes pixels 0..15 and 40..79 with an eight-pixel gap.
-- Drawing the whole source exposed unused white canvas and shifted the label.
local function drawTitleVersion(title, x, y, w, h, palette)
  local image = title and title.version
  if not (image and type(image.getDimensions) == "function") then return end
  local iw, ih = image:getDimensions()
  if iw <= 0 or ih < 8 then return end
  local logicalW = 64
  local scale = math.min(w / logicalW, h / 8, 4)
  local dx = math.floor(x + (w - logicalW * scale) / 2)
  local dy = math.floor(y + (h - 8 * scale) / 2)
  if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
  setColor({ 1, 1, 1, 1 })
  drawWithPalette(image, palette, function()
    if title.blue then
      local q = love.graphics.newQuad(0, 0, math.min(64, iw), 8, iw, ih)
      love.graphics.draw(image, q, dx, dy, 0, scale, scale)
    else
      local leftW = math.min(16, iw)
      local rightX, rightW = 40, math.max(0, math.min(40, iw - 40))
      if leftW > 0 then
        love.graphics.draw(image,
          love.graphics.newQuad(0, 0, leftW, 8, iw, ih), dx, dy, 0, scale, scale)
      end
      if rightW > 0 then
        love.graphics.draw(image,
          love.graphics.newQuad(rightX, 0, rightW, 8, iw, ih),
          dx + 24 * scale, dy, 0, scale, scale)
      end
    end
  end, true)
end

-- Exact Red/Blue motion tables from pokered engine/movie/title2.asm.
-- Each pair is { horizontal pixels per frame, number of frames }. The old
-- picture accelerates left; after CheckForUserInterruption's one-frame pause
-- (and the starter ball's five-frame wait), the new picture decelerates from
-- 120 pixels off the right edge. The stationary hold is 200 frames.
local TITLE_HOLD_FRAMES = 200
local TITLE_OUT_SCROLL = {
  { 1, 2 }, { 2, 2 }, { 3, 2 }, { 4, 2 },
  { 5, 2 }, { 6, 2 }, { 8, 3 }, { 9, 3 },
}
local TITLE_IN_SCROLL = {
  { 10, 2 }, { 9, 4 }, { 8, 4 }, { 6, 3 },
  { 5, 2 }, { 3, 1 }, { 1, 1 },
}
local TITLE_OUT_FRAMES, TITLE_IN_FRAMES = 18, 17
local TITLE_IN_DISTANCE = 120
local TITLE_STARTERS = { CHARMANDER = true, SQUIRTLE = true, BULBASAUR = true }

local function titleScrollDistance(schedule, elapsedFrames)
  local remaining = math.max(0, math.floor(elapsedFrames))
  local distance = 0
  for _, step in ipairs(schedule) do
    local used = math.min(remaining, step[2])
    distance = distance + used * step[1]
    remaining = remaining - used
    if remaining <= 0 then break end
  end
  return distance
end

-- Legacy fallback used only when the standalone provider/API is unavailable.
-- Battle Art Replacer conflicts with this older provider, so it must never
-- override a Presentation API v1 result or that provider's deliberate nil.
local function legacyAnimatedTitleImage(title, species, fallback)
  local exports = title and title.game and title.game.mods
    and title.game.mods.exports
  local handle = exports and exports.BATTLE_ART_VOXEL_FORK
  local lib = handle and handle.lib
  if not (species and lib and type(lib.require) == "function") then return nil end
  local okArt, art = pcall(lib.require, "BattleArt")
  if not (okArt and art and art.setting and type(art.setting.get) == "function") then
    return nil
  end
  local okMode, mode = pcall(art.setting.get, art.setting)
  if not okMode then return nil end
  if mode ~= "animated" then return nil end

  local okAnimated, animated = pcall(lib.require, "AnimatedBattleArt")
  if not (okAnimated and animated and type(animated.update) == "function") then
    return nil
  end
  local bySpecies = titleBattleArtPreviews[title]
  if not bySpecies then
    bySpecies = {}
    titleBattleArtPreviews[title] = bySpecies
  end
  local preview = bySpecies[species]
  if not preview or preview.handle ~= handle or preview.fallback ~= fallback then
    if preview and type(animated.finish) == "function" then
      pcall(animated.finish, preview.battle)
    end
    local mon = { species = species }
    local battler = { mon = mon, sprite = fallback }
    preview = {
      handle = handle,
      fallback = fallback,
      battler = battler,
      battle = { enemy = battler },
      lastTime = nil,
    }
    bySpecies[species] = preview
  end
  local now = love.timer and love.timer.getTime and love.timer.getTime()
              or os.clock()
  local dt = preview.lastTime and clamp(now - preview.lastTime, 0, 0.10) or 0
  preview.lastTime = now
  local ok = pcall(animated.update, preview.battle, dt)
  local image = ok and preview.battler.sprite or nil
  return image and image ~= fallback and image or nil
end

local function titleSpriteAt(title, index, species)
  local original = title.cycleIndex
  title.cycleIndex = index
  local ok, image, trueColor = pcall(title.currentSprite, title)
  title.cycleIndex = original
  local speciesId = species[index]
  local providerSupplied = false
  if speciesId then
    local token = presentationToken(title, "title", speciesId)
    local presentation, providerOwned = providerPokemonPresentation(
      title.game, { species = speciesId }, "title", token)
    if presentation then
      image = presentation.image
      trueColor = presentation.trueColor ~= false
      ok, providerSupplied = true, true
    elseif providerOwned then
      providerSupplied = true
    end
  end
  if speciesId and not providerSupplied
      and type(BattleArtProviderImage) == "function" then
    local providerOk, providerImage = pcall(BattleArtProviderImage,
      title.game, { species = speciesId }, "front", "title")
    if providerOk and providerImage then
      image, trueColor, ok = providerImage, true, true
      providerSupplied = true
    end
  end
  if speciesId and not providerSupplied then
    local animated = legacyAnimatedTitleImage(title, speciesId,
                                              ok and image or nil)
    if animated then image, trueColor, ok = animated, true, true end
  end
  return {
    image = ok and image or nil,
    species = speciesId,
    trueColor = ok and trueColor or false,
  }
end

local function titlePresentationSprites(title)
  if not (title and type(title.currentSprite) == "function") then return nil end
  local species = title.cycleSpecies or {}
  if #species <= 1 then
    local item
    if #species == 1 then
      item = titleSpriteAt(title, 1, species)
    else
      local ok, image, trueColor = pcall(title.currentSprite, title)
      item = { image = ok and image or nil, species = nil,
               trueColor = ok and trueColor or false }
    end
    return {
      current = item,
      offset = 0,
    }
  end
  local now = love.timer and love.timer.getTime and love.timer.getTime() or 0
  local cycle = titlePresentationCycles[title]
  if not cycle then
    local initial = clamp(tonumber(title.cycleIndex) or 1, 1, #species)
    cycle = { index = initial, nextIndex = initial % #species + 1,
              startedAt = now }
    titlePresentationCycles[title] = cycle
  end

  local function cycleFrames()
    local starterWait = TITLE_STARTERS[species[cycle.index]] and 5 or 0
    return TITLE_HOLD_FRAMES + TITLE_OUT_FRAMES + 1 + starterWait
      + TITLE_IN_FRAMES
  end

  local elapsed = math.max(0, (now - cycle.startedAt) * 60)
  local guard = 0
  while elapsed >= cycleFrames() and guard < #species * 2 do
    local completed = cycleFrames()
    cycle.index = cycle.nextIndex
    cycle.nextIndex = cycle.index % #species + 1
    cycle.startedAt = cycle.startedAt + completed / 60
    elapsed = math.max(0, (now - cycle.startedAt) * 60)
    guard = guard + 1

    -- Keep native TitleState aligned so START plays the displayed species'
    -- cry, and suppress the engine's older linear-slide approximation.
    title.cycleIndex = cycle.index
    if type(title.timer) == "number" then title.timer = 0 end
    title.slideIn = nil
  end

  if elapsed < TITLE_HOLD_FRAMES then
    return { current = titleSpriteAt(title, cycle.index, species), offset = 0 }
  end
  elapsed = elapsed - TITLE_HOLD_FRAMES
  if elapsed < TITLE_OUT_FRAMES then
    return {
      current = titleSpriteAt(title, cycle.index, species),
      offset = -titleScrollDistance(TITLE_OUT_SCROLL, elapsed) * 3,
    }
  end
  elapsed = elapsed - TITLE_OUT_FRAMES
  local pause = 1 + (TITLE_STARTERS[species[cycle.index]] and 5 or 0)
  if elapsed < pause then return { current = nil, offset = 0 } end
  elapsed = elapsed - pause
  return {
    current = titleSpriteAt(title, cycle.nextIndex, species),
    offset = (TITLE_IN_DISTANCE
      - titleScrollDistance(TITLE_IN_SCROLL, elapsed)) * 3,
  }
end

local function drawTitleBackdrop(title, fonts, viewW, viewH)
  local g = love.graphics
  setColor({ COLORS.paper[1], COLORS.paper[2], COLORS.paper[3], 1 })
  g.rectangle("fill", 0, 0, viewW, viewH)
  setColor(COLORS.accent)
  g.rectangle("fill", 0, 0, viewW, 6)
  local data = title and title.game and title.game.data
  local logoPal = PaletteFX and PaletteFX.pal and PaletteFX.pal(data, "LOGO2")
  local versionPal = PaletteFX and PaletteFX.pal and PaletteFX.pal(data, "LOGO1")
  local actorPal = PaletteFX and PaletteFX.pal and PaletteFX.pal(data, "MEWMON")
  -- The title card owns the full upper band. This keeps it large at 4:3 and
  -- 16:9 while leaving the lower-left region available for the menu panel.
  local logoW = math.min(460, viewW - 56)
  local logoX = math.floor((viewW - logoW) / 2)
  drawImageContained(title and title.logo, logoX, 14, logoW, 104, 4,
                     logoPal, true)
  if title and title.version and not title.yellow then
    drawTitleVersion(title, math.floor((viewW - 196) / 2), 116, 196, 28,
                     versionPal)
  end
  local artX, artW = math.floor(viewW * 0.49), math.floor(viewW * 0.47)
  local ground = viewH - 38
  if title and title.yellowLayout then
    drawImageGrounded(title.yellowPikachu, artX + 24, ground, artW - 48,
                      viewH - 158, 3, actorPal, true)
  elseif title then
    local presentation = titlePresentationSprites(title)
    local slotW = math.floor(artW * 0.50)
    local function drawMon(item, x)
      if not item then return end
      local monPal = item.species and PaletteFX and PaletteFX.monPal
        and PaletteFX.monPal(data, item.species) or actorPal
      if item.trueColor then monPal = nil end
      drawImageGrounded(item.image, x, ground, slotW, viewH - 158, 3,
                        monPal, not item.trueColor)
    end
    if presentation then
      -- Keep the Pokemon in its own half of the art band, but let it rest
      -- closer to the trainer instead of hugging the left edge.
      local monRestOffset = math.floor(slotW * 0.15)
      drawMon(presentation.current,
              artX + monRestOffset + (presentation.offset or 0))
    end
    drawImageGrounded(title.player, artX + math.floor(artW * 0.50), ground,
                      math.floor(artW * 0.50), viewH - 154, 3, actorPal, true)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  local copyright = title and title.title and title.title.copyrightText
    or "2026 BOIS CLUB GAMES"
  g.print(cleanLabel(copyright), viewW - 20 - fonts.tiny:getWidth(cleanLabel(copyright)),
          viewH - 22)
end

local function drawTitleStandby(title, fonts, viewW, viewH)
  drawTitleBackdrop(title, fonts, viewW, viewH)
  local g = love.graphics
  g.setFont(fonts.small)
  setColor(COLORS.ink)
  local prompt = "PRESS START"
  local x = 24
  g.print(prompt, x, viewH - 54)
  setColor(COLORS.accent)
  g.rectangle("fill", x, viewH - 34, fonts.small:getWidth(prompt), 3)
end

local function drawTitleMenu(title, menu, fonts, viewW, viewH)
  local g = love.graphics
  drawTitleBackdrop(title, fonts, viewW, viewH)
  local items = menu.items or {}
  local panelW = math.min(300, math.floor(viewW * 0.47))
  local rowH = #items > 5 and 30 or 36
  local panelH = math.min(viewH - 36, 78 + #items * rowH)
  local x = 20
  local y = math.max(126, math.floor((viewH - panelH + 90) / 2))
  y = math.min(y, viewH - panelH - 12)
  drawPanel(x, y, panelW, panelH)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print("MAIN MENU", x + 18, y + 16)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 142, y + 29, panelW - 164, 3)
  local firstY = y + 54
  local selected = tonumber(menu.index) or 1
  for i, item in ipairs(items) do
    local ry = firstY + (i - 1) * rowH
    local isSelected = i == selected
    setColor(isSelected and COLORS.selected or COLORS.paper2)
    g.rectangle("fill", x + 12, ry, panelW - 24, rowH - 5)
    if isSelected then
      setColor(COLORS.accent)
      g.rectangle("fill", x + 12, ry, 5, rowH - 5)
    end
    g.setFont(fonts.body)
    setColor(isSelected and COLORS.selectedText or COLORS.ink)
    g.print(fitLabel(fonts.body, cleanLabel(item.label or ""), panelW - 58),
            x + 28, ry + math.floor((rowH - 5 - fonts.body:getHeight()) / 2))
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  g.print("A SELECT", x + 18, y + panelH - 24)
end

local function drawContinueInfo(title, info, fonts, viewW, viewH)
  local g = love.graphics
  drawTitleBackdrop(title, fonts, viewW, viewH)
  local save = info.save or {}
  local badges = 0
  local okBadges, Badges = pcall(require, "src.inventory.Badges")
  if okBadges and Badges and type(Badges.count) == "function" then
    local ok, count = pcall(Badges.count, info.game and info.game.data, save)
    if ok then badges = tonumber(count) or 0 end
  end
  local owned = 0
  for _ in pairs(save.pokedex and save.pokedex.owned or {}) do owned = owned + 1 end
  local seconds = math.floor(tonumber(save.playTime) or 0)
  local rows = {
    { "PLAYER", save.player and save.player.name or "RED" },
    { "BADGES", tostring(badges) },
    { "POKEDEX", tostring(owned) },
    { "TIME", ("%d:%02d"):format(math.floor(seconds / 3600),
                                    math.floor(seconds / 60) % 60) },
  }
  local w, h = math.min(390, viewW - 40), 260
  local x, y = 24, math.floor((viewH - h) / 2)
  drawPanel(x, y, w, h)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print("CONTINUE", x + 18, y + 16)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 132, y + 29, w - 154, 3)
  for i, row in ipairs(rows) do
    local ry = y + 58 + (i - 1) * 38
    setColor(COLORS.paper2)
    g.rectangle("fill", x + 14, ry, w - 28, 30)
    g.setFont(fonts.small)
    setColor(COLORS.muted)
    g.print(row[1], x + 26, ry + 7)
    setColor(COLORS.ink)
    g.print(row[2], x + w - 26 - fonts.small:getWidth(row[2]), ry + 7)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  g.print("A CONTINUE     B BACK", x + 18, y + h - 24)
end

local function loadReportPresentationLines(state, fonts, maxWidth)
  local report = state.report or {}
  local out = {}
  local function add(text)
    for _, line in ipairs(wrapRenderedText(fonts.small, text, maxWidth)) do
      out[#out + 1] = line
    end
  end
  local function section(title, rows)
    if #rows == 0 then return end
    if #out > 0 then out[#out + 1] = "" end
    out[#out + 1] = title
    for _, row in ipairs(rows) do add("  " .. row) end
  end
  if report.recovered then add("SAVE RECOVERED FROM ." .. tostring(report.recovered)
    .. " BACKUP COPY") end
  local rows = {}
  for _, mon in ipairs(report.lostMons or {}) do
    rows[#rows + 1] = tostring(mon.species or "?") .. " ("
      .. tostring(mon.from or "?") .. ")"
  end
  section("MOVED TO LOST BOX", rows)
  rows = {}
  for _, item in ipairs(report.lostItems or {}) do
    rows[#rows + 1] = tostring(item.id or "?") .. " x"
      .. tostring(item.count or 1)
  end
  section("ITEMS REMOVED", rows)
  rows = {}
  for _, map in ipairs(report.remappedMaps or {}) do
    rows[#rows + 1] = tostring(map.id or "?") .. "  ->  "
      .. tostring(map.to or map.field or "?")
  end
  section("LOCATION RESET", rows)
  rows = {}
  for _, mon in ipairs(report.restoredMons or {}) do
    rows[#rows + 1] = tostring(mon.species or "?") .. " TO BOX "
      .. tostring(mon.box or 0)
  end
  for _, item in ipairs(report.restoredItems or {}) do
    rows[#rows + 1] = tostring(item.id or "?") .. " x"
      .. tostring(item.count or 1)
  end
  section("RESTORED", rows)
  local okSave, SaveData = pcall(require, "src.core.SaveData")
  if okSave and SaveData and type(SaveData.modsDiffNotice) == "function" then
    local ok, notice = pcall(SaveData.modsDiffNotice, report.modsDiff,
      state.game and state.game.save and state.game.save.meta)
    if ok and notice then
      -- SaveData deliberately exposes a compact one-line notice. The wide
      -- report is a reading surface, so promote every semicolon/comma clause
      -- to an independent row instead of wrapping mid-sentence.
      local noticeRows = {}
      for row in tostring(notice):gmatch("[^;,]+") do
        row = row:match("^%s*(.-)%s*$")
        if row ~= "" then noticeRows[#noticeRows + 1] = row end
      end
      section("MOD CONFIGURATION", noticeRows)
    end
  elseif #out == 0 and type(state.lines) == "table" then
    for _, line in ipairs(state.lines) do out[#out + 1] = line end
  end
  if #out == 0 then out[1] = "NO LOAD CHANGES REPORTED" end
  return out
end

local function drawLoadReport(state, fonts, viewW, viewH)
  local g = love.graphics
  setColor({ COLORS.paper[1], COLORS.paper[2], COLORS.paper[3], 1 })
  g.rectangle("fill", 0, 0, viewW, viewH)
  local x, y, w, h = 18, 18, viewW - 36, viewH - 36
  drawPanel(x, y, w, h)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print("LOAD REPORT", x + 18, y + 16)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 166, y + 29, w - 188, 3)
  local lines = loadReportPresentationLines(state, fonts, w - 52)
  local visible = math.max(1, math.floor((h - 94) / 20))
  local offset = clamp(tonumber(state.offset) or 0, 0, math.max(0, #lines - visible))
  g.setFont(fonts.small)
  for row = 1, visible do
    local line = lines[offset + row]
    if not line then break end
    setColor(line ~= "" and COLORS.ink or COLORS.muted)
    g.print(fitLabel(fonts.small, cleanLabel(line), w - 52),
            x + 24, y + 54 + (row - 1) * 20)
  end
  if offset + visible < #lines then
    setColor(COLORS.accent)
    g.polygon("fill", x + w - 34, y + h - 32,
      x + w - 18, y + h - 32, x + w - 26, y + h - 22)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  local position = ("%d / %d"):format(math.min(#lines, offset + 1), #lines)
  g.print("UP / DOWN  SCROLL     A / B / START  CONTINUE", x + 20, y + h - 25)
  g.print(position, x + w - 20 - fonts.tiny:getWidth(position), y + h - 25)
end

local OPTION_HELP = {
  textSpeed = "Controls how quickly dialogue characters appear.",
  animations = "Enables or disables move animations during battle.",
  battleStyle = "SHIFT offers a switch after a foe faints. SET does not.",
  battleLayout = "Chooses the classic battle canvas or the wide composition.",
  battleFit = "FIXED keeps integer pixels. FILL expands battle to the window.",
  battleBg = "Chooses what appears around and behind the battle presentation.",
  uiLayout = "Chooses fixed classic placement or dynamic window-edge docking.",
  ruleset = "Selects the active battle-mechanics ruleset.",
  musicVol = "Adjusts music volume from OFF through level 7.",
  sfxVol = "Adjusts sound-effect volume from OFF through level 7.",
  pikaVol = "Adjusts the volume of Pikachu voice clips in Yellow.",
  musicFilter = "Applies progressively stronger low-pass filtering to music.",
  performance = "Selects the performance tier used by advanced rendering.",
  colors = "Selects the active Game Boy, SGB, GBC or enhanced color treatment.",
  tilt = "Adjusts the 3D tilt level used by the world renderer.",
  gbcfx = "Adjusts Game Boy Color-style display effects.",
  zoom = "Offsets the overworld survey zoom from its fitted level.",
  voidFill = "Chooses how empty space beyond map geometry is presented.",
  videoMode = "Changes the active window or fullscreen presentation mode.",
  orientation = "Locks the display orientation on supported mobile devices.",
  faithfulRes = "Locks the window to an exact multiple of 160 by 144.",
  fpsCap = "Sets the maximum presentation frame rate.",
  speed = "Changes game logic speed without changing music pitch.",
  mods = "Opens the installed-mod manager.",
  controls = "Opens controller and keyboard binding settings.",
  touchControls = "Enables or disables the on-screen touch pad.",
  haptics = "Selects touch-control vibration strength.",
}

local function optionRowValue(row, game)
  if not (row and type(row.value) == "function") then return nil end
  local ok, value = pcall(row.value, game)
  if not ok or value == nil then return nil end
  return cleanLabel(value)
end

local function drawOptionsMenu(state, fonts, viewW, viewH, config)
  config = config or {}
  local g = love.graphics
  setColor({ COLORS.paper[1], COLORS.paper[2], COLORS.paper[3], 1 })
  g.rectangle("fill", 0, 0, viewW, viewH)
  setColor(COLORS.accent)
  g.rectangle("fill", 0, 0, viewW, 6)

  local rows = config.rows or state.rows or {}
  local includeCancel = config.includeCancel ~= false
  local lastIndex = #rows + (includeCancel and 1 or 0)
  if lastIndex < 1 then lastIndex = 1 end
  local index = clamp(tonumber(config.index or state.index) or 1, 1, lastIndex)
  local selected = index <= #rows and rows[index] or {
    id = "cancel", label = "CANCEL",
  }
  local selectedLabel = cleanLabel(selected.label or "OPTION")
  local selectedValue = optionRowValue(selected, state.game)

  local detailX, detailY, detailW, detailH = 18, 54, 220, viewH - 90
  drawPanel(detailX, detailY, detailW, detailH)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print(fitLabel(fonts.body, selectedLabel, detailW - 36),
          detailX + 16, detailY + 16)
  setColor(COLORS.accent)
  g.rectangle("fill", detailX + 16, detailY + 43, detailW - 32, 3)

  if selectedValue then
    g.setFont(fonts.tiny)
    setColor(COLORS.muted)
    g.print("CURRENT", detailX + 16, detailY + 62)
    setColor(COLORS.paper2)
    g.rectangle("fill", detailX + 14, detailY + 82, detailW - 28, 38)
    g.setFont(fonts.small)
    setColor(COLORS.ink)
    local valueText = fitLabel(fonts.small, selectedValue, detailW - 62)
    g.print(valueText,
      detailX + math.floor((detailW - fonts.small:getWidth(valueText)) / 2),
      detailY + 91)
    if selected.step then
      g.print("<", detailX + 25, detailY + 91)
      g.print(">", detailX + detailW - 34, detailY + 91)
    end
  end

  local help = config.help and config.help(selected) or OPTION_HELP[selected.id]
  if not help then
    if selected.activate then
      help = "Open " .. selectedLabel .. "."
    elseif selected.step then
      help = "Adjust this option. This row may be supplied by another mod."
    else
      help = "Return to the previous screen."
    end
  end
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  local helpY = detailY + (selectedValue and 138 or 66)
  for i, line in ipairs(wrapRenderedText(fonts.small, help, detailW - 32)) do
    if i > 5 then break end
    g.print(line, detailX + 16, helpY + (i - 1) * 20)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.ink)
  local action = selected.activate and "A OPEN"
    or selected.step and "LEFT / RIGHT CHANGE"
    or "A CLOSE"
  g.print(action, detailX + 16, detailY + detailH - 28)

  local listX, listY = 250, 20
  local listW, listH = viewW - listX - 18, viewH - 38
  drawPanel(listX, listY, listW, listH)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print(fitLabel(fonts.body, config.title or "OPTIONS", listW - 170),
          listX + 18, listY + 14)
  setColor(COLORS.accent)
  g.rectangle("fill", listX + 132, listY + 27, listW - 152, 3)

  local visible = math.max(4, math.floor((listH - 64) / 31))
  local total = lastIndex
  local maxStart = math.max(1, total - visible + 1)
  local first = clamp(index - math.floor(visible / 2), 1, maxStart)
  local rowY = listY + 49
  for slot = 1, visible do
    local rowIndex = first + slot - 1
    if rowIndex > total then break end
    local row = rowIndex <= #rows and rows[rowIndex]
      or { id = "cancel", label = "CANCEL" }
    local active = rowIndex == index
    local y = rowY + (slot - 1) * 31
    setColor(active and COLORS.selected or COLORS.paper2)
    g.rectangle("fill", listX + 12, y, listW - 24, 27)
    if active then
      setColor(COLORS.accent)
      g.rectangle("fill", listX + 12, y, 5, 27)
    end
    g.setFont(fonts.small)
    setColor(active and COLORS.selectedText or COLORS.ink)
    local label = fitLabel(fonts.small, cleanLabel(row.label or ""),
                           math.floor((listW - 48) * 0.60))
    g.print(label, listX + 27, y + 5)
    local value = rowIndex <= #rows and optionRowValue(row, state.game) or nil
    if value then
      local maxValueW = math.floor((listW - 48) * 0.38)
      value = fitLabel(fonts.small, value, maxValueW)
      g.print(value, listX + listW - 26 - fonts.small:getWidth(value), y + 5)
    elseif row.activate then
      g.print(">", listX + listW - 34, y + 5)
    end
  end
  if first > 1 then
    setColor(COLORS.accent)
    g.polygon("fill", listX + listW - 34, listY + 14,
      listX + listW - 18, listY + 14, listX + listW - 26, listY + 5)
  end
  if first + visible - 1 < total then
    setColor(COLORS.accent)
    g.polygon("fill", listX + listW - 34, listY + listH - 18,
      listX + listW - 18, listY + listH - 18,
      listX + listW - 26, listY + listH - 8)
  end
  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  g.print(config.footer or "UP / DOWN SELECT     B / START CLOSE",
          20, viewH - 25)
end

local MANAGER_TITLES = {
  list = "MOD MANAGER", detail = "MOD DETAILS", permissions = "PERMISSIONS",
  errors = "MOD ERRORS", apply = "PENDING CHANGES",
}

local function managerRows(state)
  if not (state and type(state.rowsForScreen) == "function") then return {} end
  local ok, rows = pcall(state.rowsForScreen, state)
  return ok and type(rows) == "table" and rows or {}
end

local function managerIsStaged(state, modInfo)
  if not (modInfo and type(state.isStaged) == "function") then return false end
  local ok, staged = pcall(state.isStaged, state, modInfo)
  return ok and staged and true or false
end

local function drawManagerOverlay(state, fonts, viewW, viewH)
  local overlay = state.overlay
  if not overlay then return end
  local lines = {}
  for _, raw in ipairs(overlay.lines or {}) do
    for _, line in ipairs(wrapRenderedText(fonts.small, raw, 360)) do
      lines[#lines + 1] = line
    end
  end
  local w = math.min(420, viewW - 70)
  local h = math.min(viewH - 50, 92 + #lines * 20
    + (overlay.kind == "confirm" and 54 or 22))
  local x, y = math.floor((viewW - w) / 2), math.floor((viewH - h) / 2)
  drawPanel(x, y, w, h)
  love.graphics.setFont(fonts.body)
  setColor(COLORS.ink)
  love.graphics.print(overlay.kind == "confirm" and "CONFIRM" or "NOTICE",
                      x + 18, y + 16)
  setColor(COLORS.accent)
  love.graphics.rectangle("fill", x + 126, y + 29, w - 148, 3)
  love.graphics.setFont(fonts.small)
  for i, line in ipairs(lines) do
    setColor(COLORS.ink)
    love.graphics.print(line, x + 22, y + 54 + (i - 1) * 20)
  end
  if overlay.kind == "confirm" then
    local baseY = y + h - 70
    for i, label in ipairs({ "YES", "NO" }) do
      local active = (tonumber(overlay.index) or 1) == i
      setColor(active and COLORS.selected or COLORS.paper2)
      love.graphics.rectangle("fill", x + 22, baseY + (i - 1) * 30,
                              w - 44, 26)
      if active then
        setColor(COLORS.accent)
        love.graphics.rectangle("fill", x + 22, baseY + (i - 1) * 30, 5, 26)
      end
      setColor(active and COLORS.selectedText or COLORS.ink)
      love.graphics.print(label, x + 38, baseY + 4 + (i - 1) * 30)
    end
  else
    love.graphics.setFont(fonts.tiny)
    setColor(COLORS.muted)
    love.graphics.print("A OK", x + 22, y + h - 28)
  end
end

local function drawModManager(state, fonts, viewW, viewH)
  if state.screen == "options" then
    local modInfo = state.currentMod or {}
    drawOptionsMenu(state, fonts, viewW, viewH, {
      rows = state.optionRows or {}, index = state.cursor,
      includeCancel = false,
      title = fitLabel(fonts.body,
        cleanLabel((modInfo.name or modInfo.id or "MOD") .. " OPTIONS"), 220),
      footer = state.notice or "LEFT / RIGHT CHANGE     A OPEN     B DONE",
      help = function(row)
        if row.id == "__reset" then return "Restore every option for this mod to its declared default." end
        return "Adjust this mod setting. Changes are saved without restarting unless the mod states otherwise."
      end,
    })
    drawManagerOverlay(state, fonts, viewW, viewH)
    return
  end

  local g = love.graphics
  setColor({ COLORS.paper[1], COLORS.paper[2], COLORS.paper[3], 1 })
  g.rectangle("fill", 0, 0, viewW, viewH)
  setColor(COLORS.accent)
  g.rectangle("fill", 0, 0, viewW, 6)
  local rows = managerRows(state)
  local cursor = clamp(tonumber(state.cursor) or 1, 1, math.max(1, #rows))
  local focused = rows[cursor]
  local title = MANAGER_TITLES[state.screen] or "MOD MANAGER"

  local listX, listY, listW, listH = 18, 20, 350, viewH - 58
  drawPanel(listX, listY, listW, listH)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print(title, listX + 16, listY + 13)
  setColor(COLORS.accent)
  g.rectangle("fill", listX + 154, listY + 27, listW - 174, 3)

  local contentY = listY + 48
  if state.screen == "list" then
    local tabs = { "MODS", "PROFILES", "ERRORS" }
    local tabW = math.floor((listW - 24) / 3)
    for i, label in ipairs(tabs) do
      local active = (tonumber(state.tab) or 1) == i
      setColor(active and COLORS.selected or COLORS.paper2)
      g.rectangle("fill", listX + 12 + (i - 1) * tabW, contentY,
                  tabW - 4, 25)
      g.setFont(fonts.tiny)
      setColor(active and COLORS.selectedText or COLORS.ink)
      g.print(label, listX + 22 + (i - 1) * tabW, contentY + 6)
    end
    contentY = contentY + 34
  end

  local visible = math.max(5, math.floor((listY + listH - 18 - contentY) / 28))
  local maxStart = math.max(1, #rows - visible + 1)
  local first = clamp(cursor - math.floor(visible / 2), 1, maxStart)
  for slot = 1, visible do
    local rowIndex = first + slot - 1
    local row = rows[rowIndex]
    if not row then break end
    local y = contentY + (slot - 1) * 28
    if row.header then
      g.setFont(fonts.tiny)
      setColor(COLORS.muted)
      g.print(fitLabel(fonts.tiny, cleanLabel(row.label or ""), listW - 42),
              listX + 18, y + 7)
    else
      local active = rowIndex == cursor
      setColor(active and COLORS.selected or COLORS.paper2)
      g.rectangle("fill", listX + 12, y, listW - 24, 25)
      if active then
        setColor(COLORS.accent)
        g.rectangle("fill", listX + 12, y, 5, 25)
      end
      g.setFont(fonts.small)
      setColor(active and COLORS.selectedText or COLORS.ink)
      local prefix = row.glyph and row.glyph ~= " " and row.glyph .. " " or ""
      g.print(fitLabel(fonts.small, prefix .. cleanLabel(row.label or ""),
                       listW - 82), listX + 27, y + 4)
      if row.mod then
        local cx, cy = listX + listW - 29, y + 12
        local enabled = row.mod.enabled == true
        setColor(enabled and COLORS.enabled or COLORS.disabled)
        if type(g.setLineWidth) == "function" then g.setLineWidth(3) end
        if type(g.line) == "function" then
          if enabled then
            g.line(cx - 6, cy, cx - 2, cy + 4)
            g.line(cx - 2, cy + 4, cx + 7, cy - 6)
          else
            g.line(cx - 6, cy - 6, cx + 6, cy + 6)
            g.line(cx + 6, cy - 6, cx - 6, cy + 6)
          end
        else
          g.print(enabled and "V" or "X", cx - 4, cy - 7)
        end
        if type(g.setLineWidth) == "function" then g.setLineWidth(1) end
      end
    end
  end

  local detailX, detailY, detailW, detailH = 380, 20, viewW - 398, viewH - 58
  drawPanel(detailX, detailY, detailW, detailH)
  local modInfo = focused and focused.mod or state.currentMod
  local detailTitle = modInfo and (modInfo.name or modInfo.id)
    or focused and focused.label or title
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  g.print(fitLabel(fonts.body, cleanLabel(detailTitle or title), detailW - 32),
          detailX + 16, detailY + 14)
  setColor(COLORS.accent)
  g.rectangle("fill", detailX + 16, detailY + 41, detailW - 32, 3)

  local infoY = detailY + 58
  if modInfo then
    g.setFont(fonts.small)
    setColor(modInfo.enabled and COLORS.enabled or COLORS.disabled)
    local status = modInfo.enabled and "ENABLED" or "DISABLED"
    if managerIsStaged(state, modInfo) then status = status .. " / STAGED" end
    g.print(status, detailX + 16, infoY)
    setColor(COLORS.muted)
    g.print(fitLabel(fonts.small,
      cleanLabel((modInfo.version or "") .. "  " .. (modInfo.category or "OTHER")),
      detailW - 32), detailX + 16, infoY + 22)
    local description = modInfo.error and ("FAILED: " .. tostring(modInfo.error))
      or modInfo.description or "No description supplied."
    for i, line in ipairs(wrapRenderedText(fonts.small, description, detailW - 32)) do
      if i > 7 then break end
      g.print(line, detailX + 16, infoY + 54 + (i - 1) * 19)
    end
  elseif state.screen == "apply" and type(state.stagedList) == "function" then
    local ok, staged = pcall(state.stagedList, state)
    staged = ok and staged or {}
    g.setFont(fonts.small)
    setColor(COLORS.muted)
    g.print(tostring(#staged) .. " MOD CHANGES WAITING", detailX + 16, infoY)
    for i, entry in ipairs(staged) do
      if i > 8 then break end
      g.print((entry.enabled and "ON  " or "OFF ")
        .. cleanLabel(entry.name or entry.id), detailX + 16, infoY + i * 21)
    end
  else
    g.setFont(fonts.small)
    setColor(COLORS.muted)
    local detail = focused and cleanLabel(focused.label or "")
      or "No entry selected."
    for i, line in ipairs(wrapRenderedText(fonts.small, detail, detailW - 32)) do
      if i > 8 then break end
      g.print(line, detailX + 16, infoY + (i - 1) * 20)
    end
  end

  g.setFont(fonts.tiny)
  setColor(COLORS.muted)
  local footer = state.notice or (state.screen == "list"
    and "A OPEN   SELECT TOGGLE   START APPLY   B EXIT"
    or "A CHOOSE   B BACK")
  g.print(fitLabel(fonts.tiny, cleanLabel(footer), viewW - 40), 20, viewH - 25)
  drawManagerOverlay(state, fonts, viewW, viewH)
end

local function bundledPartyIcon(mod, mon, selected, counter)
  if not (Assets and love and love.graphics and mon and mon.species) then
    return nil
  end
  local species = tostring(mon.species):upper():gsub("[^A-Z0-9]", "")
  local dex = PARTY_ICON_DEX[species]
  if not dex then return nil end
  local path = mod.assets:path("party_icons.png")
  local cached = partyIconSheetCache[path]
  if cached == nil then
    local ok, image = pcall(Assets.image, path)
    if ok and image and type(image.getDimensions) == "function" then
      local iw, ih = image:getDimensions()
      if iw == 512 and ih == 640 then
        if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
        if image.setWrap then pcall(image.setWrap, image, "clamp", "clamp") end
        cached = { image = image, iw = iw, ih = ih, quads = {} }
      end
    end
    cached = cached or false
    partyIconSheetCache[path] = cached
  end
  if cached == false then return nil end

  local maxHP = mon.stats and mon.stats.hp or 1
  local hp = mon.hp or maxHP
  local pixels = math.floor(hp * 48 / math.max(1, maxHP))
  local speed = pixels >= 27 and 10 or pixels >= 10 and 20 or 32
  local alternate = math.floor((counter or 0) / speed) % 2 == 1
  local frame = alternate and 2 or 1
  local key = dex * 2 + frame
  local quad = cached.quads[key]
  if not quad then
    local zero = dex - 1
    local x = (zero % 16) * 32
    local y = math.floor(zero / 16) * 64 + (frame - 1) * 32
    quad = love.graphics.newQuad(x, y, 32, 32, cached.iw, cached.ih)
    cached.quads[key] = quad
  end
  return cached.image, quad
end

local function nativePartyIcon(game, mon, selected, counter)
  if not (Assets and love and love.graphics and mon and mon.species) then
    return nil
  end
  local icons = game and game.data and game.data.icons
  local entry = icons and icons.bySpecies and icons.bySpecies[mon.species]
  local path
  if type(entry) == "table" then
    local shiny = ShinyArtResolver and ShinyArtResolver(mon)
    if shiny == nil then
      shiny = mon.shiny == true
        or (Stats and Stats.isShiny and Stats.isShiny(mon.dvs))
    end
    path = shiny and entry.shinyImage or entry.image
  end
  if type(path) ~= "string" or path == "" then return nil end

  local cached = partyIconSheetCache[path]
  if cached == nil then
    local ok, image = pcall(Assets.image, path)
    if ok and image and type(image.getDimensions) == "function" then
      local iw, ih = image:getDimensions()
      if iw == 32 and ih == 64 then
        if image.setFilter then pcall(image.setFilter, image, "nearest", "nearest") end
        if image.setWrap then pcall(image.setWrap, image, "clamp", "clamp") end
        cached = {
          image = image,
          quads = {
            love.graphics.newQuad(0, 0, 32, 32, iw, ih),
            love.graphics.newQuad(0, 32, 32, 32, iw, ih),
          },
        }
      end
    end
    cached = cached or false
    partyIconSheetCache[path] = cached
  end
  if cached == false then return nil end

  local alternate = false
  if selected then
    local maxHP = mon.stats and mon.stats.hp or 1
    local hp = mon.hp or maxHP
    local pixels = math.floor(hp * 48 / math.max(1, maxHP))
    local speed = pixels >= 27 and 5 or pixels >= 10 and 16 or 32
    alternate = math.floor((counter or 0) / speed) % 2 == 1
  end
  return cached.image, cached.quads[alternate and 2 or 1]
end

local function drawPartyIcon(mod, PartyMenu, menu, mon, x, y, selected)
  local g = love.graphics
  g.push("all")
  setColor({ 1, 1, 1, 1 })
  -- Prefer the currently registered 32x64 icon descriptor. This lets a
  -- focused icon provider (such as hgss_menu_icons) own the artwork while
  -- retaining the widescreen atlas as a no-dependency fallback.
  local image, quad = nativePartyIcon(menu.game, mon, selected, menu.blink or 0)
  if not image then
    image, quad = bundledPartyIcon(mod, mon, selected, menu.blink or 0)
  end
  if image and quad then
    -- Modern icon packs author 32x32 frames. Drawing them directly on this
    -- 640x360 surface avoids the stock 32 -> 16 -> output-size round trip.
    g.draw(image, quad, x, y)
    if PaletteFX and type(PaletteFX.markTrueColor) == "function" then
      PaletteFX.markTrueColor(x, y, 32, 32)
    end
  else
    g.translate(x, y)
    g.scale(2, 2)
    PartyMenu.drawIcon(menu.game, mon, 0, 0, selected, menu.blink or 0)
  end
  g.pop()
end

local function partyBattlePaletteKey(data, species)
  if not PaletteFX then return "none", nil end
  local colors = PaletteFX.monPal(data, species)
  if not colors then return "none", nil end
  local name = PaletteFX.monPalName(data, species) or "MON"
  if PaletteFX.usesGbcPack and PaletteFX.usesGbcPack() then
    name = "redpp:" .. name
  end
  return name, colors
end

-- This follows the same live resolver used by battle presentation. The path
-- is deliberately resolved every frame: an enabled sprite mod may select a
-- different generated variant while the game is running, and caching the
-- resolver result would pin this panel to stale art.
local function engineBattleSpriteImage(game, mon)
  if not (PokemonSprites and Assets and game and game.data
      and mon and mon.species) then return nil end

  local path, trueColor = PokemonSprites.path(
    game.data, mon.species, "front", { mon = mon, kind = "battle" })
  if not path then return nil end

  local palName, colors = partyBattlePaletteKey(game.data, mon.species)
  local key = path .. "|" .. (trueColor and "truecolor" or palName)
  local cached = partyBattleSpriteCache[key]
  if cached then return cached end

  local image
  if trueColor or not colors or not (love.image and love.image.newImageData) then
    image = Assets.image(path)
  else
    local id = Assets.imageData(path)
    if id then
      id:mapPixel(function(_, _, r, green, blue, alpha)
        if alpha == 0 then return r, green, blue, alpha end
        local color = r > 0.83 and colors[1]
          or r > 0.50 and colors[2]
          or r > 0.17 and colors[3]
          or colors[4]
        return color[1] / 255, color[2] / 255, color[3] / 255, alpha
      end)
      image = love.graphics.newImage(id)
    end
  end

  if image and image.setFilter then
    image:setFilter("nearest", "nearest")
  end
  partyBattleSpriteCache[key] = image
  return image
end

local battleArtPreview = setmetatable({}, { __mode = "k" })

local function battleArtModules(game)
  local exports = game and game.mods and game.mods.exports
  local handle = exports and exports.BATTLE_ART_VOXEL_FORK
  local lib = handle and handle.lib
  if not (lib and type(lib.require) == "function") then return nil end
  local okArt, art = pcall(lib.require, "BattleArt")
  if not (okArt and art) then return nil end
  local okAnimated, animated = pcall(lib.require, "AnimatedBattleArt")
  return art, okAnimated and animated or nil, handle
end

-- BATTLE_ART_VOXEL_FORK applies its STATIC/ANIMATED images directly to the
-- battler after the engine's pokemon.sprite resolver has run. Consult its
-- exported modules first so Party sees the same selected collection. ROM and
-- missing-pack cases fall back to the normal engine resolver.
selectedBattleSpriteImage = function(game, mon, purpose, tokenOwner)
  purpose = purpose or "portrait"
  local token = presentationToken(tokenOwner or mon, purpose,
                                  mon and mon.species)
  local presentation, providerOwned = providerPokemonPresentation(
    game, mon, purpose, token)
  if presentation then return presentation.image, nil end
  if providerOwned then return engineBattleSpriteImage(game, mon), nil end
  if type(BattleArtProviderImage) == "function" then
    local ok, image = pcall(BattleArtProviderImage, game, mon, "front", "portrait")
    if ok and image then return image, nil end
  end
  if ShinyArtResolver and ShinyArtResolver(mon)
      and type(ShinyBattleImage) == "function" then
    local ok, image = pcall(ShinyBattleImage, game, mon, "front")
    if ok and image then return image, nil end
  end
  local fallback = engineBattleSpriteImage(game, mon)
  local art, animated, handle = battleArtModules(game)
  if not art then return fallback, nil end

  local okMode, mode = pcall(art.setting.get, art.setting)
  if not okMode or mode == "rom" then return fallback, nil end

  if mode == "static" then
    local ok, image = pcall(art.image, mon.species, "front")
    if ok and image then
      local metric = type(art.metrics) == "function" and art.metrics(image)
      return image, metric
    end
    return fallback, nil
  end

  if mode == "animated" and animated
      and type(animated.update) == "function" then
    local preview = battleArtPreview[mon]
    if not preview or preview.handle ~= handle or preview.fallback ~= fallback then
      if preview and type(animated.finish) == "function" then
        pcall(animated.finish, preview.battle)
      end
      local battler = { mon = mon, sprite = fallback }
      preview = {
        handle = handle,
        fallback = fallback,
        battler = battler,
        battle = { enemy = battler },
        lastTime = nil,
      }
      battleArtPreview[mon] = preview
    end
    local now = love.timer and love.timer.getTime and love.timer.getTime()
                or os.clock()
    local dt = preview.lastTime and clamp(now - preview.lastTime, 0, 0.10) or 0
    preview.lastTime = now
    -- AnimatedBattleArt owns atlas cells and durations; advancing its preview
    -- battler makes UI portraits obey the same selected generation and timing
    -- without treating Dramatic Shape's Stadium models as 2D images.
    local ok = pcall(animated.update, preview.battle, dt)
    local image = ok and preview.battler.sprite or nil
    if image and image ~= fallback then
      local metric = type(art.metrics) == "function" and art.metrics(image)
      return image, metric
    end
  end

  return fallback, nil
end

drawPartyBattleSprite = function(game, mon, x, y, w, h, overscan,
                                 purpose, tokenOwner)
  local image, metric = selectedBattleSpriteImage(game, mon, purpose, tokenOwner)
  if not image then return false end
  local iw, ih = image:getDimensions()
  if not iw or not ih or iw <= 0 or ih <= 0 then return false end

  local sourceX, sourceY, frameW, frameH = 0, 0, iw, ih
  if metric and metric.x0 and metric.x1 and metric.y0 and metric.y1 then
    sourceX, sourceY = metric.x0, metric.y0
    frameW = metric.x1 - metric.x0 + 1
    frameH = metric.y1 - metric.y0 + 1
  elseif iw >= ih * 2 and iw % ih == 0 then
    frameW = ih
  elseif ih >= iw * 2 and ih % iw == 0 then
    frameH = iw
  end
  local scale = math.min(w / frameW, h / frameH)
  -- Wide silhouettes naturally look much shorter when fitted only by width.
  -- The compact Party panel may opt into a small bounded boost, aiming for
  -- three quarters of its portrait height while allowing at most the supplied
  -- overscan. This covers Kadabra and the same issue in Golbat, Geodude,
  -- Goldeen, Aerodactyl, Zubat, etc. without per-species exceptions.
  overscan = math.max(1, tonumber(overscan) or 1)
  if overscan > 1 then
    local shownHeight = frameH * scale
    local targetHeight = h * 0.75
    local boost = shownHeight > 0 and targetHeight / shownHeight or 1
    scale = scale * clamp(boost, 1, overscan)
  end
  if scale <= 0 then return false end
  local dx = math.floor(x + (w - frameW * scale) / 2 + 0.5)
  local dy = math.floor(y + (h - frameH * scale) / 2 + 0.5)

  setColor({ 1, 1, 1, 1 })
  if sourceX ~= 0 or sourceY ~= 0 or frameW ~= iw or frameH ~= ih then
    local quad = love.graphics.newQuad(sourceX, sourceY,
                                      frameW, frameH, iw, ih)
    love.graphics.draw(image, quad, dx, dy, 0, scale, scale)
  else
    love.graphics.draw(image, dx, dy, 0, scale, scale)
  end
  return true
end

local function canLearnTM(menu, mon)
  if not (menu.tmhm and mon) then return nil end
  local def = monDefinition(menu.game, mon)
  for _, moveId in ipairs((def and def.tmhm) or {}) do
    if moveId == menu.tmhm.move then return true end
  end
  return false
end

local function drawPartyRows(mod, menu, PartyMenu, fonts, x, y, w)
  local g = love.graphics
  local party = menu.party or (menu.game.save and menu.game.save.party) or {}
  local rowH = 44

  -- Decorations first, labels second. This keeps selection fills from ever
  -- painting over glyphs, matching the START menu's overlap fix.
  for i = 1, math.min(6, #party) do
    local ry = y + (i - 1) * rowH
    setColor(i == menu.index and COLORS.selected or COLORS.paper2)
    g.rectangle("fill", x, ry, w, rowH - 3)
    if i == menu.index then
      setColor(COLORS.accent)
      g.rectangle("fill", x, ry, 5, rowH - 3)
    end
  end

  g.setFont(fonts.body)
  for i = 1, math.min(6, #party) do
    local mon = party[i]
    local ry = y + (i - 1) * rowH
    local selected = i == menu.index
    local maxHP = math.max(1, mon.stats and mon.stats.hp or 1)
    local hp = shownHP(menu, mon)
    drawPartyIcon(mod, PartyMenu, menu, mon, x + 9, ry + 4, selected)

    setColor(selected and COLORS.selectedText or COLORS.ink)
    g.print(monName(menu.game, mon), x + 49, ry + 4)
    local level = "Lv." .. tostring(mon.level or "?")
    g.print(level, x + w - 10 - fonts.body:getWidth(level), ry + 4)

    g.setFont(fonts.small)
    local able = canLearnTM(menu, mon)
    if able ~= nil then
      local label = able and "ABLE" or "NOT ABLE"
      setColor(able and { 0.12, 0.55, 0.23, 1 }
                       or { 0.70, 0.16, 0.12, 1 })
      g.print(label, x + 49, ry + 24)
    else
      setColor(selected and COLORS.selectedText or COLORS.muted)
      g.print("HP", x + 49, ry + 24)
      drawHPBar(x + 72, ry + 28, 112, hp, maxHP)
      setColor(selected and COLORS.selectedText or COLORS.ink)
      local hpText = string.format("%d/%d", hp, maxHP)
      g.print(hpText, x + w - 10 - fonts.small:getWidth(hpText), ry + 22)
    end
    g.setFont(fonts.body)
  end
end

local function updateSubmenuScroll(menu, visible)
  local count = #(menu.subItems or {})
  local index = clamp(tonumber(menu.subIndex) or 1, 1, math.max(1, count))
  local maxScroll = math.max(0, count - visible)
  local scroll = clamp(tonumber(menu.__wideUiSubScroll) or 0, 0, maxScroll)
  if index <= scroll then
    scroll = index - 1
  elseif index > scroll + visible then
    scroll = index - visible
  end
  menu.__wideUiSubScroll = clamp(scroll, 0, maxScroll)
  return menu.__wideUiSubScroll
end

local function statValue(mon, ...)
  local stats = mon and mon.stats or {}
  for i = 1, select("#", ...) do
    local value = stats[select(i, ...)]
    if value ~= nil then return tostring(math.floor(value)) end
  end
  return "-"
end

local function drawPartySidePanel(menu, fonts, x, y, w, h)
  local g = love.graphics
  drawPanel(x, y, w, h)
  g.setFont(fonts.title)
  setColor(COLORS.ink)
  g.print(menu.submenu and "ACTIONS" or "DETAILS", x + 14, y + 12)
  setColor(COLORS.accent)
  g.rectangle("fill", x + 102, y + 21, w - 118, 3)

  if menu.submenu and menu.subItems then
    local rowH, listY = 24, y + 43
    local visible = math.max(1, math.floor((h - 56) / rowH))
    local scroll = updateSubmenuScroll(menu, visible)

    -- Background pass.
    for slot = 1, visible do
      local index = scroll + slot
      if not menu.subItems[index] then break end
      if index == menu.subIndex then
        local ry = listY + (slot - 1) * rowH
        setColor(COLORS.selected)
        g.rectangle("fill", x + 9, ry, w - 18, rowH - 2)
        setColor(COLORS.accent)
        g.rectangle("fill", x + 9, ry, 4, rowH - 2)
      end
    end

    -- Label pass.
    g.setFont(fonts.body)
    local offset = math.floor((rowH - fonts.body:getHeight()) / 2)
    for slot = 1, visible do
      local index = scroll + slot
      local entry = menu.subItems[index]
      if not entry then break end
      local ry = listY + (slot - 1) * rowH
      setColor(index == menu.subIndex and COLORS.selectedText or COLORS.ink)
      g.print(cleanLabel(entry.label), x + 21, ry + offset)
    end

    if scroll > 0 or scroll + visible < #menu.subItems then
      g.setFont(fonts.small)
      setColor(COLORS.muted)
      g.print("MORE", x + w - 52, y + h - 20)
    end
    return
  end

  local party = menu.party or (menu.game.save and menu.game.save.party) or {}
  local mon = party[clamp(menu.index or 1, 1, math.max(1, #party))]
  if not mon then return end
  local maxHP = math.max(1, mon.stats and mon.stats.hp or 1)
  local hp = shownHP(menu, mon)
  local name = monName(menu.game, mon)
  local nameWidth = w - 86
  local nameFont = fonts.body
  if fonts.body:getWidth(name) > nameWidth then nameFont = fonts.small end
  g.setFont(nameFont)
  setColor(COLORS.ink)
  g.print(name, x + 14, y + 39)

  -- Free-standing active battle portrait. No frame is drawn around it; the
  -- transparent prepared art sits directly on the panel background.
  drawPartyBattleSprite(menu.game, mon, x + w - 68, y + 38, 56, 66, 1.15,
                        "party", mon)

  local def = monDefinition(menu.game, mon)
  local types = def and def.types or {}
  drawTypeBadge(types[1], fonts, x + 14, y + 61, 54, 18)
  if types[2] and types[2] ~= types[1] then
    drawTypeBadge(types[2], fonts, x + 72, y + 61, 54, 18)
  end

  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print("LEVEL", x + 14, y + 86)
  setColor(COLORS.ink)
  g.print(tostring(mon.level or "?"), x + 55, y + 86)
  setColor(COLORS.muted)
  g.print("HP", x + 14, y + 104)
  setColor(COLORS.ink)
  g.print(string.format("%d/%d", hp, maxHP), x + 55, y + 104)
  drawHPBar(x + 14, y + 124, w - 28, hp, maxHP)
  drawXPBar(x + 14, y + 134, w - 28,
            levelExpProgress(menu.game, mon, def))

  setColor(COLORS.muted)
  g.print("STATS", x + 14, y + 148)
  setColor(COLORS.ink)
  g.print("ATK " .. statValue(mon, "attack", "atk"), x + 14, y + 165)
  g.print("DEF " .. statValue(mon, "defense", "def"), x + 99, y + 165)
  g.print("SPD " .. statValue(mon, "speed", "spd"), x + 14, y + 181)
  g.print("SPC " .. statValue(mon, "special", "spc", "specialAttack"),
          x + 99, y + 181)

  setColor(COLORS.muted)
  g.print("MOVES", x + 14, y + 194)
  local moves = mon.moves or {}
  for i = 1, math.min(4, #moves) do
    local move = moves[i]
    local def = menu.game.data and menu.game.data.moves
                and menu.game.data.moves[move.id]
    local name = cleanLabel((def and def.name) or move.id or "-")
    setColor(COLORS.ink)
    g.print(name, x + 14, y + 194 + i * 13)
  end
end

local function drawPartyMenu(mod, menu, PartyMenu, fonts)
  local g = love.graphics
  setColor({ 0.11, 0.12, 0.12, 0.96 })
  g.rectangle("fill", 0, 0, DESIGN_W, DESIGN_H)

  drawPanel(9, 8, DESIGN_W - 18, DESIGN_H - 16)
  g.setFont(fonts.title)
  setColor(COLORS.ink)
  g.print("POKÉMON", 25, 22)
  setColor(COLORS.accent)
  g.rectangle("fill", 126, 31, 276, 3)

  local party = menu.party or (menu.game.save and menu.game.save.party) or {}
  if #party == 0 then
    g.setFont(fonts.body)
    setColor(COLORS.ink)
    g.print("No POKEMON!", 28, 70)
    return
  end

  drawPartyRows(mod, menu, PartyMenu, fonts, 23, 49, 382)
  drawPartySidePanel(menu, fonts, 422, 49, 195, 268)

  setColor(COLORS.paper2)
  g.rectangle("fill", 23, 322, 594, 24)
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  local prompt = cleanLabel(menu:bottomMessage())
  g.print(prompt, 31, 328)
  local controls = menu.submenu and "A SELECT   B BACK" or "A OPEN   B CLOSE"
  g.print(controls, 609 - fonts.small:getWidth(controls), 328)
end

local function presentationStackIndex(game, background)
  local states = game and game.stack and game.stack.states
  if type(states) ~= "table" then return nil end
  for i, state in ipairs(states) do
    if state == background then return i end
  end
  return nil
end

local function presentationRange(game, background)
  local states = game and game.stack and game.stack.states
  local first = presentationStackIndex(game, background)
  if not first then return nil end
  -- An opaque screen above this presenter correctly replaces it. Non-opaque
  -- states are messages/choices/effects that must be composited over the
  -- widescreen background instead of reviving its native draw underneath.
  for i = first + 1, #states do
    if states[i].isOpaque then return nil end
  end
  return first, #states
end

local function expForNextLevel(game, mon, def)
  local level = tonumber(mon.level) or 1
  if level >= 100 then return 0 end
  local ok, Growth = pcall(require, "src.pokemon.Growth")
  if ok and Growth and type(Growth.expForLevel) == "function" then
    local growth = def and (def.growthRate or def.growth)
    local rates = game and game.data and game.data.growth_rates
    local calcOk, target = pcall(Growth.expForLevel, growth, level + 1, rates)
    if calcOk and target then
      return math.max(0, math.floor(target - (tonumber(mon.exp) or 0)))
    end
  end
  return nil
end

levelExpProgress = function(game, mon, def)
  local level = tonumber(mon.level) or 1
  if level >= 100 then return 1 end
  local ok, Growth = pcall(require, "src.pokemon.Growth")
  if not (ok and Growth and type(Growth.expForLevel) == "function") then
    return 0
  end
  local growth = def and (def.growthRate or def.growth)
  local rates = game and game.data and game.data.growth_rates
  local baseOk, base = pcall(Growth.expForLevel, growth, level, rates)
  local nextOk, nextLevel = pcall(Growth.expForLevel, growth, level + 1, rates)
  if not (baseOk and nextOk and base and nextLevel) or nextLevel <= base then
    return 0
  end
  return clamp(((tonumber(mon.exp) or base) - base) / (nextLevel - base), 0, 1)
end

local function summaryStatus(mon)
  local status = mon and mon.status
  if status == nil or status == false or status == 0 or status == "" then
    return "OK"
  end
  return cleanLabel(tostring(status):gsub("_", " "))
end

local function drawSummaryShared(summary, fonts, x, y, w, h)
  local g, mon, game = love.graphics, summary.mon, summary.game
  local def = monDefinition(game, mon)
  drawPanel(x, y, w, h)

  local name = monName(game, mon)
  local nameFont = fonts.title
  if nameFont:getWidth(name) > w - 30 then nameFont = fonts.small end
  g.setFont(nameFont)
  setColor(COLORS.ink)
  g.print(name, x + 14, y + 13)

  g.setFont(fonts.small)
  setColor(COLORS.muted)
  local dex = def and (def.dex or def.number or def.id)
  if dex then
    g.print(string.format("No. %03d", tonumber(dex) or 0), x + 14, y + 38)
  end

  -- The same resolver used by Party: Battle Art static/animated 2D fronts,
  -- then the engine's active front-sprite resolver. Stadium models are never
  -- requested by this path.
  drawPartyBattleSprite(game, mon, x + 16, y + 53, w - 32, 142, nil,
                        "summary", mon)

  local player = game and game.save and game.save.player or {}
  setColor(COLORS.muted)
  g.print("OT", x + 14, y + 205)
  g.print("ID No.", x + 14, y + 231)
  setColor(COLORS.ink)
  g.print(cleanLabel(mon.ot or player.name or "-"), x + 65, y + 205)
  g.print(tostring(mon.otId or player.id or "-"), x + 65, y + 231)
end

local function drawSummaryPageOne(summary, fonts, x, y, w, h)
  local g, mon = love.graphics, summary.mon
  local def = monDefinition(summary.game, mon)
  local maxHP = math.max(1, mon.stats and mon.stats.hp or 1)
  local hp = math.floor(mon.hp or 0)
  drawPanel(x, y, w, h)

  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print("LEVEL", x + 15, y + 18)
  g.print("STATUS", x + 190, y + 18)
  setColor(COLORS.ink)
  g.print(tostring(mon.level or "?"), x + 15, y + 37)
  g.print(summaryStatus(mon), x + 190, y + 37)

  setColor(COLORS.muted)
  g.print("HP", x + 15, y + 61)
  local hpText = string.format("%d/%d", hp, maxHP)
  setColor(COLORS.ink)
  g.print(hpText, x + w - 15 - fonts.small:getWidth(hpText), y + 61)
  drawHPBar(x + 15, y + 82, w - 30, hp, maxHP)

  setColor(COLORS.muted)
  g.print("STATS", x + 15, y + 101)
  local cards = {
    { "ATTACK", statValue(mon, "attack", "atk") },
    { "DEFENSE", statValue(mon, "defense", "def") },
    { "SPEED", statValue(mon, "speed", "spd") },
    { "SPECIAL", statValue(mon, "special", "spc", "specialAttack") },
  }
  for i, entry in ipairs(cards) do
    local col = (i - 1) % 2
    local row = math.floor((i - 1) / 2)
    local cx, cy = x + 15 + col * 170, y + 120 + row * 42
    setColor(COLORS.paper2)
    g.rectangle("fill", cx, cy, 155, 34)
    setColor(COLORS.muted)
    g.print(entry[1], cx + 8, cy + 8)
    setColor(COLORS.ink)
    g.print(entry[2], cx + 145 - fonts.small:getWidth(entry[2]), cy + 8)
  end

  setColor(COLORS.muted)
  g.print("TYPE", x + 15, y + 216)
  local types = def and def.types or {}
  drawTypeBadge(types[1], fonts, x + 73, y + 211, 78, 21)
  if types[2] and types[2] ~= types[1] then
    drawTypeBadge(types[2], fonts, x + 158, y + 211, 78, 21)
  end
end

local function drawSummaryPageTwo(summary, fonts, x, y, w, h)
  local g, mon, game = love.graphics, summary.mon, summary.game
  local def = monDefinition(game, mon)
  drawPanel(x, y, w, h)
  g.setFont(fonts.small)

  setColor(COLORS.muted)
  g.print("EXP POINTS", x + 15, y + 14)
  g.print("NEXT LEVEL", x + 190, y + 14)
  setColor(COLORS.ink)
  g.print(tostring(math.floor(tonumber(mon.exp) or 0)), x + 15, y + 33)
  local nextExp = expForNextLevel(game, mon, def)
  g.print(nextExp ~= nil and tostring(nextExp) or "-", x + 190, y + 33)

  setColor(COLORS.muted)
  g.print("LEVEL PROGRESS", x + 15, y + 55)
  drawXPBar(x + 125, y + 59, w - 140, levelExpProgress(game, mon, def))

  setColor(COLORS.muted)
  g.print("MOVES", x + 15, y + 84)
  local moves = mon.moves or {}
  for i = 1, 4 do
    local move = moves[i]
    local mdef = move and game.data and game.data.moves
                 and game.data.moves[move.id]
    local ry = y + 104 + (i - 1) * 37
    setColor(COLORS.paper2)
    g.rectangle("fill", x + 15, ry, w - 30, 30)
    setColor(COLORS.ink)
    local moveName = fitLabel(fonts.small,
      (mdef and mdef.name) or (move and move.id) or "-", 154)
    g.print(moveName, x + 25, ry + 6)
    if move then
      drawTypeBadge(mdef and mdef.type, fonts, x + 190, ry + 6, 65, 18)
      local maxPP = tonumber(mdef and mdef.pp) or tonumber(move.pp) or 0
      local ups = tonumber(move.ppUps) or 0
      maxPP = maxPP + ups * math.floor(maxPP / 5)
      local pp = tostring(move.pp or 0) .. "/" .. tostring(maxPP)
      setColor(COLORS.muted)
      g.print("PP " .. pp, x + w - 25 - fonts.small:getWidth("PP " .. pp),
              ry + 6)
    end
  end
end

local function drawSummaryMenu(summary, fonts)
  local g = love.graphics
  setColor({ 0.11, 0.12, 0.12, 0.96 })
  g.rectangle("fill", 0, 0, DESIGN_W, DESIGN_H)
  drawPanel(9, 8, DESIGN_W - 18, DESIGN_H - 16)
  g.setFont(fonts.title)
  setColor(COLORS.ink)
  local summaryTitle = "POKEMON SUMMARY"
  g.print(summaryTitle, 25, 22)
  setColor(COLORS.accent)
  local lineX = 25 + fonts.title:getWidth(summaryTitle) + 15
  g.rectangle("fill", lineX, 31, math.max(20, 402 - lineX), 3)
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  local page = clamp(tonumber(summary.page) or 1, 1, 2)
  g.print(page .. " / 2", 579, 24)

  drawSummaryShared(summary, fonts, 23, 49, 202, 267)
  if page == 1 then
    drawSummaryPageOne(summary, fonts, 240, 49, 377, 267)
  else
    drawSummaryPageTwo(summary, fonts, 240, 49, 377, 267)
  end

  setColor(COLORS.paper2)
  g.rectangle("fill", 23, 322, 594, 24)
  g.setFont(fonts.small)
  setColor(COLORS.muted)
  g.print(page == 1 and "POKEMON DATA" or "MOVES & EXPERIENCE", 31, 328)
  local controls = page == 1 and "A / B NEXT" or "A / B CLOSE"
  g.print(controls, 609 - fonts.small:getWidth(controls), 328)
end

local function visibleTextBoxLine(box, shownIndex)
  local shown = box.shown and box.shown[shownIndex]
  local page = box.pages and box.pages[box.pageIndex]
  if not (shown and page) then return "" end
  local sourceIndex = box.lineIndex - (#box.shown - shownIndex)
  local source = page[sourceIndex] or ""
  if not (EngineFont and EngineFont.split) then
    return source:sub(1, math.min(#source, #shown))
  end
  local spans = EngineFont.split(source)
  local count = math.min(#shown, #spans)
  if count <= 0 then return "" end
  return source:sub(1, spans[count].to)
end

local function drawWideTextBox(box, fonts, viewW, viewH)
  local g = love.graphics
  viewW, viewH = viewW or DESIGN_W, viewH or DESIGN_H
  local x, w, h = 12, math.max(296, viewW - 24), 92
  local y = math.max(12, viewH - h - 12)
  drawPanel(x, y, w, h)
  g.setFont(fonts.body)
  setColor(COLORS.ink)
  -- TextBox's native draw owns the retained-line scroll countdown. Because
  -- Widescreen suppresses that draw while presenting this box, advance the
  -- same 2px-per-frame state here. The update method, typing cadence, page
  -- waits and callbacks remain entirely native.
  local nativeOff = tonumber(box.scrollPx) or 0
  if nativeOff > 0 then
    nativeOff = math.max(0, nativeOff - 2)
    box.scrollPx = nativeOff > 0 and nativeOff or nil
  end
  local lineStep = 28
  local retainedOff = nativeOff > 0
    and math.floor(nativeOff * lineStep / 8 + 0.5) or 0
  for i = 1, math.min(2, #(box.shown or {})) do
    local lineY = y + 19 + (i - 1) * lineStep
    if i == 1 then lineY = lineY + retainedOff end
    g.print(visibleTextBoxLine(box, i), x + 20, math.floor(lineY))
  end
  if (box.waiting or (box.done and not box.choice and not box.auto
                      and not box.stay)) and (box.blink or 0) < 30 then
    setColor(COLORS.accent)
    g.polygon("fill", x + w - 29, y + h - 25,
              x + w - 15, y + h - 25,
              x + w - 22, y + h - 15)
  end
end

local function drawWideChoiceBox(choice, fonts, viewW, viewH, aboveText)
  local g = love.graphics
  viewW, viewH = viewW or DESIGN_W, viewH or DESIGN_H
  local w, h = 154, 82
  local textTop = math.max(12, viewH - 104)
  local x = math.max(12, viewW - w - 12)
  local y = aboveText and math.max(12, textTop - h - 8)
    or math.max(12, viewH - h - 12)
  drawPanel(x, y, w, h)
  local rowH = 28
  for i = 1, 2 do
    local ry = y + 13 + (i - 1) * rowH
    if i == choice.index then
      setColor(COLORS.selected)
      g.rectangle("fill", x + 9, ry, w - 18, rowH - 2)
      setColor(COLORS.accent)
      g.rectangle("fill", x + 9, ry, 4, rowH - 2)
    end
  end
  g.setFont(fonts.body)
  setColor(choice.index == 1 and COLORS.selectedText or COLORS.ink)
  g.print("YES", x + 24, y + 18)
  setColor(choice.index == 2 and COLORS.selectedText or COLORS.ink)
  g.print("NO", x + 24, y + 46)
end

local function drawNativeOverlay(state)
  if not (state and type(state.draw) == "function") then return end
  local g = love.graphics
  g.push("all")
  -- Generic non-opaque effects use the engine's 160x144 coordinate space.
  -- Stretching a full-screen veil is exact; custom TextBox/Choice presenters
  -- above avoid stretching text or borders.
  g.scale(DESIGN_W / 160, DESIGN_H / 144)
  pcall(state.draw, state)
  g.pop()
end

local function drawPresentationOverlays(game, first, last, fonts, viewW, viewH)
  local states = game.stack.states
  for i = first + 1, last do
    local state = states[i]
    local mt = getmetatable(state)
    if TextBoxClass and mt == TextBoxClass then
      drawWideTextBox(state, fonts, viewW, viewH)
    elseif ChoiceBoxClass and mt == ChoiceBoxClass then
      local aboveText = false
      for under = first + 1, i - 1 do
        if TextBoxClass and getmetatable(states[under]) == TextBoxClass then
          aboveText = true
          break
        end
      end
      drawWideChoiceBox(state, fonts, viewW, viewH, aboveText)
    else
      drawNativeOverlay(state)
    end
  end
end

local function drawInDesignSpace(drawFn)
  local g = love.graphics
  local ww, wh = g.getDimensions()
  if ww <= 0 or wh <= 0 then return end
  local scale = math.min(ww / DESIGN_W, wh / DESIGN_H)
  local ox = math.floor((ww - DESIGN_W * scale) / 2)
  local oy = math.floor((wh - DESIGN_H * scale) / 2)
  g.push("all")
  g.translate(ox, oy)
  g.scale(scale, scale)
  drawFn()
  g.pop()
end

-- Battles use the same uniform pixel scale as the 640x360 presentation, but
-- expose the entire physical window to the HUD. This keeps 16:9 unchanged and
-- anchors chrome to the real top/bottom edges on taller 4:3 displays without
-- changing the world renderer, camera, or battle arena geometry.
local function drawInBattleSpace(drawFn)
  local g = love.graphics
  local ww, wh = g.getDimensions()
  if ww <= 0 or wh <= 0 then return end
  local scale = math.min(ww / DESIGN_W, wh / DESIGN_H)
  if scale <= 0 then return end
  local viewW = math.floor(ww / scale + 0.5)
  local viewH = math.floor(wh / scale + 0.5)
  g.push("all")
  g.scale(scale, scale)
  drawFn(viewW, viewH)
  g.pop()
end

return function(mod)
  local providerErrors = {}
  local warnedForcedBattleHud = false
  battleMoveInspectorLogError = function(message)
    message = tostring(message)
    if providerErrors[message] then return end
    providerErrors[message] = true
    mod.log:error("Widescreen UI Move Inspector: %s", message)
  end

  local battleHudOverlayErrors = {}
  battleHudOverlayLogError = function(message)
    message = tostring(message)
    if battleHudOverlayErrors[message] then return end
    battleHudOverlayErrors[message] = true
    mod.log:error("Widescreen UI Battle HUD overlay: %s", message)
  end
  mod.exports.battleHudOverlayApiVersion = BATTLE_HUD_OVERLAY_API_VERSION
  mod.exports.registerBattleHudOverlay = function(spec)
    if type(spec) ~= "table" then
      return nil, "provider descriptor must be a table"
    end
    if type(spec.owner) ~= "string" or spec.owner == "" then
      return nil, "provider owner must be a non-empty string"
    end
    if spec.apiVersion ~= BATTLE_HUD_OVERLAY_API_VERSION then
      return nil, "unsupported Battle HUD overlay API version"
    end
    if type(spec.draw) ~= "function" then
      return nil, "provider draw must be a function"
    end
    for i, provider in ipairs(battleHudOverlayProviders) do
      if provider.owner == spec.owner then
        battleHudOverlayProviders[i] = {
          owner = spec.owner, draw = spec.draw, failed = false,
        }
        return true, "replaced"
      end
    end
    battleHudOverlayProviders[#battleHudOverlayProviders + 1] = {
      owner = spec.owner, draw = spec.draw, failed = false,
    }
    return true, "registered"
  end
  mod.exports.unregisterBattleHudOverlay = function(owner)
    for i, provider in ipairs(battleHudOverlayProviders) do
      if provider.owner == owner then
        table.remove(battleHudOverlayProviders, i)
        return true, "unregistered"
      end
    end
    return true, "absent"
  end

  local worldHudOverlayErrors = {}
  worldHudOverlayLogError = function(message)
    message = tostring(message)
    if worldHudOverlayErrors[message] then return end
    worldHudOverlayErrors[message] = true
    mod.log:error("Widescreen UI World HUD overlay: %s", message)
  end
  mod.exports.worldHudOverlayApiVersion = WORLD_HUD_OVERLAY_API_VERSION
  mod.exports.registerWorldHudOverlay = function(spec)
    if type(spec) ~= "table" then
      return nil, "provider descriptor must be a table"
    end
    if type(spec.owner) ~= "string" or spec.owner == "" then
      return nil, "provider owner must be a non-empty string"
    end
    if spec.apiVersion ~= WORLD_HUD_OVERLAY_API_VERSION then
      return nil, "unsupported World HUD overlay API version"
    end
    if type(spec.draw) ~= "function" then
      return nil, "provider draw must be a function"
    end
    for i, provider in ipairs(worldHudOverlayProviders) do
      if provider.owner == spec.owner then
        worldHudOverlayProviders[i] = {
          owner = spec.owner, draw = spec.draw, failed = false,
        }
        return true, "replaced"
      end
    end
    worldHudOverlayProviders[#worldHudOverlayProviders + 1] = {
      owner = spec.owner, draw = spec.draw, failed = false,
    }
    return true, "registered"
  end
  mod.exports.unregisterWorldHudOverlay = function(owner)
    for i, provider in ipairs(worldHudOverlayProviders) do
      if provider.owner == owner then
        table.remove(worldHudOverlayProviders, i)
        return true, "unregistered"
      end
    end
    return true, "absent"
  end

  mod.exports.battleMoveInspectorApiVersion = BATTLE_MOVE_INSPECTOR_API_VERSION
  mod.exports.registerBattleMoveInspector = function(spec)
    if type(spec) ~= "table" then return nil, "provider descriptor must be a table" end
    if type(spec.owner) ~= "string" or spec.owner == "" then
      return nil, "provider owner must be a non-empty string"
    end
    if spec.apiVersion ~= BATTLE_MOVE_INSPECTOR_API_VERSION then
      return nil, "unsupported Move Inspector API version"
    end
    if type(spec.snapshot) ~= "function" then
      return nil, "provider snapshot must be a function"
    end
    if battleMoveInspectorProvider
        and battleMoveInspectorProvider.owner ~= spec.owner then
      return nil, "Move Inspector provider already owned by "
        .. battleMoveInspectorProvider.owner
    end
    local replaced = battleMoveInspectorProvider ~= nil
    battleMoveInspectorProvider = {
      owner = spec.owner,
      apiVersion = spec.apiVersion,
      snapshot = spec.snapshot,
    }
    providerErrors = {}
    return true, replaced and "replaced" or "registered"
  end
  mod.exports.unregisterBattleMoveInspector = function(owner)
    if not battleMoveInspectorProvider then return true, "absent" end
    if owner ~= battleMoveInspectorProvider.owner then
      return nil, "provider is owned by " .. battleMoveInspectorProvider.owner
    end
    battleMoveInspectorProvider = nil
    providerErrors = {}
    warnedForcedBattleHud = false
    return true, "unregistered"
  end
  mod.exports.activeBattleMoveInspectorOwner = function()
    return battleMoveInspectorProvider and battleMoveInspectorProvider.owner or nil
  end

  local pokedexProviderErrors = {}
  pokedexProviderLogError = function(message)
    message = tostring(message)
    if pokedexProviderErrors[message] then return end
    pokedexProviderErrors[message] = true
    mod.log:error("Widescreen UI Pokedex provider: %s", message)
  end
  mod.exports.pokedexProviderApiVersion = POKEDEX_PROVIDER_API_VERSION
  mod.exports.registerPokedexProvider = function(spec)
    if type(spec) ~= "table" then return nil, "provider descriptor must be a table" end
    if type(spec.owner) ~= "string" or spec.owner == "" then
      return nil, "provider owner must be a non-empty string"
    end
    if spec.apiVersion ~= POKEDEX_PROVIDER_API_VERSION
        and spec.apiVersion ~= PokedexProviderUI.compatVersion then
      return nil, "unsupported Pokedex provider API version"
    end
    if type(spec.match) ~= "function" or type(spec.snapshot) ~= "function" then
      return nil, "provider match and snapshot must be functions"
    end
    if type(spec.actions) ~= "table" then
      return nil, "provider actions must be a table"
    end
    if pokedexProvider and pokedexProvider.owner ~= spec.owner then
      return nil, "Pokedex provider already owned by " .. pokedexProvider.owner
    end
    local replaced = pokedexProvider ~= nil
    pokedexProvider = {
      owner = spec.owner,
      apiVersion = spec.apiVersion,
      match = spec.match,
      snapshot = spec.snapshot,
      actions = spec.actions,
    }
    pokedexProviderErrors = {}
    PokedexProviderUI.lastValid = setmetatable({}, { __mode = "k" })
    PokedexProviderUI.hitRegions = setmetatable({}, { __mode = "k" })
    PokedexProviderUI.views = setmetatable({}, { __mode = "k" })
    return true, replaced and "replaced" or "registered"
  end
  mod.exports.unregisterPokedexProvider = function(owner)
    if not pokedexProvider then return true, "absent" end
    if owner ~= pokedexProvider.owner then
      return nil, "provider is owned by " .. pokedexProvider.owner
    end
    pokedexProvider = nil
    pokedexProviderErrors = {}
    PokedexProviderUI.lastValid = setmetatable({}, { __mode = "k" })
    PokedexProviderUI.hitRegions = setmetatable({}, { __mode = "k" })
    PokedexProviderUI.views = setmetatable({}, { __mode = "k" })
    return true, "unregistered"
  end
  mod.exports.activePokedexProviderOwner = function()
    return pokedexProvider and pokedexProvider.owner or nil
  end
  local function pokedexProviderOwnsState(state)
    if not (pokedexProvider and type(state) == "table") then return false end
    local ok, matched = pcall(pokedexProvider.match, state)
    if not ok then
      pokedexProviderLogError("match exception: " .. tostring(matched))
      return false
    end
    return matched and true or false
  end
  mod.exports.invokePokedexProviderAction = function(actionId, game, state, ...)
    if not pokedexProvider then return nil, "no active Pokedex provider" end
    local action = pokedexProvider.actions[actionId]
    if type(action) ~= "function" then
      return nil, "unsupported Pokedex action " .. tostring(actionId)
    end
    local ok, value, reason = pcall(action, game, state, ...)
    if not ok then
      pokedexProviderLogError("action " .. tostring(actionId)
        .. " exception: " .. tostring(value))
      return nil, value
    end
    return value, reason
  end
  mod.exports.updatePokedexProviderInput = function(game, state, dt)
    if not pokedexProviderOwnsState(state) then
      return nil, "state is not owned by the active Pokedex provider"
    end
    if topState(game) ~= state then return false, "state is not focused" end
    local input = game and game.input
    if not (input and type(input.wasPressed) == "function") then
      return false, "input unavailable"
    end
    local views = PokedexProviderUI.views[state]
    local entryView = views and views.entryViewport
    if entryView and entryView.focused and entryView.available then
      -- Entry focus is presenter-owned transient state. It never asks the
      -- semantic provider to understand coordinates, wrapping or raw input.
      if input:wasPressed("b") or input:wasPressed("start")
          or input:wasPressed("a") or input:wasPressed("select") then
        return PokedexProviderUI.applyEntryAction(state, "entryBlur")
      elseif input:wasPressed("up") then
        return PokedexProviderUI.applyEntryAction(state, "entryScroll", -1)
      elseif input:wasPressed("down") then
        return PokedexProviderUI.applyEntryAction(state, "entryScroll", 1)
      elseif input:wasPressed("left") then
        return PokedexProviderUI.applyEntryAction(state, "entryScroll", -5)
      elseif input:wasPressed("right") then
        return PokedexProviderUI.applyEntryAction(state, "entryScroll", 5)
      end
      return false
    end
    if input:wasPressed("select") and entryView and entryView.available then
      return PokedexProviderUI.applyEntryAction(state, "entryFocus", true)
    end
    -- One semantic action per fixed update. B has first refusal so closing a
    -- submenu/page can never also move a newly exposed list in the same frame.
    local action
    if input:wasPressed("b") or input:wasPressed("start") then
      action = "back"
    elseif input:wasPressed("a") then
      action = "select"
    elseif input:wasPressed("up") then
      action = "up"
    elseif input:wasPressed("down") then
      action = "down"
    elseif input:wasPressed("left") then
      action = "pageUp"
    elseif input:wasPressed("right") then
      action = "pageDown"
    end
    if not action then return false end
    return mod.exports.invokePokedexProviderAction(action, game, state, dt)
  end
  if mod.hooks and type(mod.hooks.wrap) == "function" then
    mod.hooks:wrap("input.pointer", function(next, game, event)
      local state = topState(game)
      if not pokedexProviderOwnsState(state) or type(event) ~= "table"
          or event.phase ~= "pressed"
          or (event.source == "mouse" and event.button ~= nil
              and event.button ~= 1) then
        return next(game, event)
      end
      local regions = PokedexProviderUI.hitRegions[state]
      if type(regions) ~= "table" then return next(game, event) end
      local g = love and love.graphics
      local ww, wh
      if g and g.getDimensions then ww, wh = g.getDimensions() end
      if not ww or not wh or ww <= 0 or wh <= 0 then
        return next(game, event)
      end
      local scale = math.min(ww / DESIGN_W, wh / DESIGN_H)
      local ox = math.floor((ww - DESIGN_W * scale) / 2)
      local oy = math.floor((wh - DESIGN_H * scale) / 2)
      local px = ((tonumber(event.x) or -1) - ox) / scale
      local py = ((tonumber(event.y) or -1) - oy) / scale
      -- Reverse order gives the submenu, which is drawn last, first refusal
      -- over the detail panel beneath it.
      for i = #regions, 1, -1 do
        local region = regions[i]
        if px >= region.x and px <= region.x + region.w
            and py >= region.y and py <= region.y + region.h then
          if region.action == "entryFocus" or region.action == "entryScroll"
              or region.action == "entryBlur" then
            PokedexProviderUI.applyEntryAction(state, region.action, region.value)
          elseif region.value ~= nil then
            mod.exports.invokePokedexProviderAction(region.action,
              game, state, region.value)
          else
            mod.exports.invokePokedexProviderAction(region.action, game, state)
          end
          return true
        end
      end
      return next(game, event)
    end, 12000)
  end

  ShinyArtResolver = function(mon)
    local shinyMod = mod.find and mod:find("gen1_shiny_system")
    local use = shinyMod and shinyMod.exports
      and shinyMod.exports.shouldUseShinyArt
    if type(use) ~= "function" then return nil end
    local ok, value = pcall(use, mon)
    return ok and (value and true or false) or nil
  end
  ShinyBattleImage = function(game, mon, side)
    local shinyMod = mod.find and mod:find("gen1_shiny_system")
    local resolve = shinyMod and shinyMod.exports
      and shinyMod.exports.battleImage
    if type(resolve) ~= "function" then return nil end
    return resolve(game, mon, side)
  end
  BattleArtProviderImage = function(game, mon, side, purpose)
    local handles = game and game.mods and game.mods.exports
    local handle = handles and handles.gen1_battle_art_replacer
    if not handle and mod.find then
      local ok, found = pcall(mod.find, mod, "gen1_battle_art_replacer")
      if ok then handle = found end
    end
    local exports = handle and (handle.exports or handle)
    local resolve = exports and exports.resolvePokemonImage
    if type(resolve) ~= "function" then return nil end
    return resolve(game, mon, side, purpose)
  end
  BattleArtProviderPresentation = function(game, mon, side, context)
    local handles = game and game.mods and game.mods.exports
    local handle = handles and handles.gen1_battle_art_replacer
    if not handle and mod.find then
      local ok, found = pcall(mod.find, mod, "gen1_battle_art_replacer")
      if ok then handle = found end
    end
    local exports = handle and (handle.exports or handle)
    if not (exports and tonumber(exports.presentationApiVersion) == 1
        and type(exports.resolvePokemonPresentation) == "function") then
      return nil, false
    end
    return exports.resolvePokemonPresentation(game, mon, side, context), true
  end

  mod.options:define({
    {
      key = "start_menu",
      type = "toggle",
      label = "WIDESCREEN START MENU",
      default = true,
    },
    {
      key = "title_menu",
      type = "toggle",
      label = "WIDESCREEN MAIN MENU",
      default = true,
    },
    {
      key = "load_report",
      type = "toggle",
      label = "WIDESCREEN LOAD REPORT",
      default = true,
    },
    {
      key = "options_menu",
      type = "toggle",
      label = "WIDESCREEN OPTIONS MENU",
      default = true,
    },
    {
      key = "party_screen",
      type = "toggle",
      label = "WIDESCREEN POKEMON SCREEN",
      default = true,
    },
    {
      key = "summary_screen",
      type = "toggle",
      label = "WIDESCREEN STAT SCREEN",
      default = true,
    },
    {
      key = "pokedex_screen",
      type = "toggle",
      label = "WIDESCREEN POKEDEX",
      default = true,
    },
    {
      key = "battle_hud",
      type = "toggle",
      label = "WIDESCREEN BATTLE HUD",
      default = true,
    },
    {
      key = "dialogue_boxes",
      type = "toggle",
      label = "WIDESCREEN DIALOGUE BOXES",
      default = true,
    },
  })

  local function optionEnabled(key)
    local ok, value = pcall(mod.options.get, mod.options, key)
    if key == "battle_hud" and battleMoveInspectorProvider then
      if ok and value == false and not warnedForcedBattleHud then
        warnedForcedBattleHud = true
        mod.log:warn("Widescreen UI: WIDESCREEN BATTLE HUD is required by Move Inspector provider %s; the disabled setting is ignored while it is active",
          battleMoveInspectorProvider.owner)
      end
      return true
    end
    if key == "pokedex_screen" and pokedexProvider then return true end
    return not ok or value ~= false
  end

  local fonts = {
    title = loadFont(16),
    body = loadFont(16),
    small = loadFont(12),
    tiny = loadFont(10),
  }
  if not fonts.title or not fonts.body or not fonts.small or not fonts.tiny then
    mod.log:warn("Widescreen UI: could not create screen-space fonts")
  end

  local okSpriteDeps, spriteDepsErr = pcall(function()
    PokemonSprites = require("src.pokemon.Sprites")
    Assets = require("src.render.Assets")
    PaletteFX = require("src.render.PaletteFX")
    Stats = require("src.pokemon.Stats")
    EngineFont = require("src.render.Font")
    TextBoxClass = require("src.render.TextBox")
    ChoiceBoxClass = require("src.ui.ChoiceBox")
    local function optionalRequire(name)
      local loaded, value = pcall(require, name)
      return loaded and value or nil
    end
    ListMenuClass = optionalRequire("src.ui.ListMenu")
    MenuClass = optionalRequire("src.ui.Menu")
    PokedexMenuClass = optionalRequire("src.ui.PokedexMenu")
    DexEntryMenuClass = optionalRequire("src.ui.DexEntryMenu")
    TitleStateClass = optionalRequire("src.ui.TitleState")
    QuarantineReportClass = optionalRequire("src.ui.QuarantineReport")
    OptionsMenuClass = optionalRequire("src.ui.OptionsMenu")
    ManagerStateClass = optionalRequire("src.mods.ManagerState")
    BattleState = require("src.battle.BattleState")
    if Assets.register then
      Assets.register(function()
        partyBattleSpriteCache = {}
        partyIconSheetCache = {}
        battleArtPreview = setmetatable({}, { __mode = "k" })
      end)
    end
  end)
  if not okSpriteDeps then
    mod.log:warn("Widescreen UI: battle portrait resolver unavailable: %s",
                 tostring(spriteDepsErr))
  end

  -- The engine's WIDE battle compositor and Dramatic Shape's snapped HUD are
  -- both presentations of the same battle state.  While this option is on,
  -- keep the simulation/input untouched but route drawing through the classic
  -- battlefield layer with its native HUD/text passes suppressed.  The final
  -- 640x360 presenter below then becomes the single owner of battle chrome.
  local activeBattle
  local okBattlePatch, battlePatchErr = pcall(function()
    if not BattleState or BattleState.__widescreenUiBattleWrapped then return end
    local originalWideLayout = BattleState.wideLayout
    local originalDrawHUDs = BattleState.drawHUDs
    local originalDrawTextArea = BattleState.drawTextArea
    local originalUpdate = BattleState.update

    BattleState.wideLayout = function(self, ...)
      if optionEnabled("battle_hud") then return false end
      return originalWideLayout(self, ...)
    end
    BattleState.drawHUDs = function(self, ...)
      if optionEnabled("battle_hud") then return end
      return originalDrawHUDs(self, ...)
    end
    BattleState.drawTextArea = function(self, ...)
      if optionEnabled("battle_hud") then return end
      return originalDrawTextArea(self, ...)
    end
    if type(originalUpdate) == "function" then
      BattleState.update = function(self, dt, ...)
        -- Rendering uses the classic battlefield layer so its native chrome
        -- can be suppressed cleanly. Preserve the 2x2 navigation promised by
        -- the visible move grid explicitly while A/B/SELECT remain native.
        if optionEnabled("battle_hud") and self and self.game
            and self.game.input and type(self.game.input.wasPressed) == "function"
            and (self.phase == "moveSelect" or self.phase == "mimicSelect") then
          local moves = self.phase == "moveSelect"
            and self.player and self.player.curMoves or self.mimicMoves
          local key = self.phase == "moveSelect" and "moveIndex" or "mimicIndex"
          local index = tonumber(self[key]) or 1
          local count = #(moves or {})
          local input = self.game.input
          local direction
          for _, candidate in ipairs({ "left", "right", "up", "down" }) do
            if input:wasPressed(candidate) then
              direction = candidate
              break
            end
          end
          if direction == "left" or direction == "right" then
            local row = math.floor((index - 1) / 2)
            local col = (index - 1) % 2
            local other = row * 2 + (1 - col) + 1
            if other <= count then self[key] = other end
          elseif direction == "up" or direction == "down" then
            local row = math.floor((index - 1) / 2)
            local col = (index - 1) % 2
            local other = (1 - row) * 2 + col + 1
            if other <= count then self[key] = other end
          end
          if direction then
            -- wideLayout is false only for drawing suppression. Prevent the
            -- classic +/-1 navigation from applying after the grid step.
            local originalWasPressed = input.wasPressed
            input.wasPressed = function(obj, pressedKey)
              if pressedKey == "left" or pressedKey == "right"
                  or pressedKey == "up" or pressedKey == "down" then
                return false
              end
              return originalWasPressed(obj, pressedKey)
            end
            local ok, a, b, c = pcall(originalUpdate, self, dt, ...)
            input.wasPressed = originalWasPressed
            if not ok then error(a, 0) end
            return a, b, c
          end
        end
        return originalUpdate(self, dt, ...)
      end
    end
    BattleState.__widescreenUiBattleWrapped = true
  end)
  if not okBattlePatch then
    mod.log:error("Widescreen UI: battle-state patch failed: %s",
                  tostring(battlePatchErr))
  end

  local battleProviderAdapters = {}
  local function patchBattleProvider(game, providerId)
    if battleProviderAdapters[providerId] then return true end
    local exports = game and game.mods and game.mods.exports
    local handle = exports and exports[providerId]
    if not handle and mod.find then
      local ok, found = pcall(mod.find, mod, providerId)
      if ok then handle = found end
    end
    local lib = handle and (handle.lib
      or (handle.exports and handle.exports.lib))
    if not (lib and type(lib.require) == "function") then return false end
    local okOB, OB = pcall(lib.require, "OverworldBattle")
    local okBH, BH = pcall(lib.require, "BattleHud")
    if not (okOB and OB and okBH and BH) then return false end

    local originalSnapHUDs = OB.snapHUDs
    local originalDrawHudPanels = OB.drawHudPanels
    local originalPanel = BH.panel
    OB.snapHUDs = function(battle, shot, ...)
      if optionEnabled("battle_hud") then
        return battle ~= nil and shot ~= nil and shot.canvas ~= nil
          and (tonumber(shot.scale) or 0) > 0
      end
      return originalSnapHUDs(battle, shot, ...)
    end
    OB.drawHudPanels = function(battle, ...)
      if optionEnabled("battle_hud") then return end
      return originalDrawHudPanels(battle, ...)
    end
    BH.panel = function(rect, box, world, ...)
      if optionEnabled("battle_hud") then return true end
      return originalPanel(rect, box, world, ...)
    end
    battleProviderAdapters[providerId] = {
      overworldBattle = OB, battleHud = BH,
    }
    return true
  end

  local function patchDramaticShapeBattle(game)
    local dramatic = patchBattleProvider(game, "DRAMATIC_SHAPE")
    local battleArt = patchBattleProvider(game, "BATTLE_ART_VOXEL_FORK")
    return dramatic or battleArt
  end

  -- Install before the first render pass when the loader exposes the mod
  -- handle. Dramatic Shape builds its snapped HUD during world composition,
  -- which occurs before render.hud; waiting until that hook is one frame too
  -- late and can also miss the captured native draw closure entirely.
  patchDramaticShapeBattle(nil)

  -- The voxel providers capture the engine HUD into a private texture before
  -- render.hud. Patch them at battle creation as well, covering load orders in
  -- which their exported library was not yet available during this mod's init.
  if mod.events and type(mod.events.on) == "function" then
    mod.events:on("battle.started", function(payload)
      local battle = payload and payload.battle
      patchDramaticShapeBattle(battle and battle.game)
    end)
  end

  mod.hooks:wrap("battle.overlay", function(next, battle)
    patchDramaticShapeBattle(battle and battle.game)
    local result = next(battle)
    activeBattle = battle
    return result
  end, 11000)

  local activeStart
  local okPatch, patchErr = pcall(function()
    local StartMenu = require("src.ui.StartMenu")
    if StartMenu.__widescreenUiWrapped then return end
    local originalNew = StartMenu.new
    StartMenu.new = function(game, ...)
      local menu = originalNew(game, ...)
      menu.__widescreenUiStart = true
      menu.__widescreenUiOriginalDraw = menu.draw
      -- An instance method is intentional: it wins over other mods that wrap
      -- generic Menu.draw, so two final-pass START presenters cannot both arm
      -- themselves merely because of load order.
      menu.draw = function(self, ...)
        if not optionEnabled("start_menu") and self.__widescreenUiOriginalDraw then
          return self.__widescreenUiOriginalDraw(self, ...)
        end
      end
      activeStart = menu
      return menu
    end
    StartMenu.__widescreenUiWrapped = true
  end)

  if not okPatch then
    mod.log:error("Widescreen UI: START menu patch failed: %s",
                  tostring(patchErr))
  end

  local activeParty
  local PartyMenu
  local okPartyPatch, partyPatchErr = pcall(function()
    PartyMenu = require("src.ui.PartyMenu")
    if PartyMenu.__widescreenUiWrapped then return end
    local originalNew = PartyMenu.new
    PartyMenu.new = function(game, opts)
      local menu = originalNew(game, opts)
      menu.__widescreenUiParty = true
      menu.__widescreenUiOriginalDraw = menu.draw
      menu.draw = function(self, ...)
        if not optionEnabled("party_screen")
            and self.__widescreenUiOriginalDraw then
          return self.__widescreenUiOriginalDraw(self, ...)
        end
        activeParty = self
      end
      activeParty = menu
      return menu
    end
    PartyMenu.__widescreenUiWrapped = true
  end)

  if not okPartyPatch then
    mod.log:error("Widescreen UI: Pokemon screen patch failed: %s",
                  tostring(partyPatchErr))
  end

  local activeSummary
  local SummaryMenu
  local okSummaryPatch, summaryPatchErr = pcall(function()
    SummaryMenu = require("src.ui.SummaryMenu")
    if SummaryMenu.__widescreenUiWrapped then return end
    local originalNew = SummaryMenu.new
    SummaryMenu.new = function(game, mon, ...)
      local summary = originalNew(game, mon, ...)
      summary.__widescreenUiSummary = true
      summary.__widescreenUiOriginalDraw = summary.draw
      summary.draw = function(self, ...)
        if not optionEnabled("summary_screen")
            and self.__widescreenUiOriginalDraw then
          return self.__widescreenUiOriginalDraw(self, ...)
        end
        activeSummary = self
      end
      activeSummary = summary
      return summary
    end
    SummaryMenu.__widescreenUiWrapped = true
  end)

  if not okSummaryPatch then
    mod.log:error("Widescreen UI: stat screen patch failed: %s",
                  tostring(summaryPatchErr))
  end

  -- TitleState keeps animating beneath the menu, but its original 160x144
  -- Menu box must never be drawn once the final-resolution presenter owns the
  -- title flow. The callbacks/update path remain on the original Menu object.
  if MenuClass and type(MenuClass.draw) == "function"
      and not MenuClass.__widescreenUiTitleDrawWrapped then
    local originalMenuDraw = MenuClass.draw
    MenuClass.draw = function(self, ...)
      if optionEnabled("title_menu") and self and self.titleUiBox then return end
      return originalMenuDraw(self, ...)
    end
    MenuClass.__widescreenUiTitleDrawWrapped = true
  end

  local okPokedexPatch, pokedexPatchErr = pcall(function()
    if not PokedexMenuClass or PokedexMenuClass.__widescreenUiWrapped then return end
    local originalNew = PokedexMenuClass.new
    PokedexMenuClass.new = function(game, opts, ...)
      local list = originalNew(game, opts, ...)
      list.__widescreenUiPokedexRoot = true
      return list
    end
    PokedexMenuClass.__widescreenUiWrapped = true
  end)
  if not okPokedexPatch then
    mod.log:error("Widescreen UI: Pokedex presentation patch failed: %s",
                  tostring(pokedexPatchErr))
  end

  local function isNativePokedexList(state)
    if type(state) ~= "table" or getmetatable(state) ~= ListMenuClass then
      return false
    end
    local title = tostring(state.title or "")
      :gsub("é", "E"):gsub("É", "E"):upper():gsub("[^A-Z]", "")
    return title == "POKEDEX"
  end

  local function pokedexRootRange(game)
    local states = game and game.stack and game.stack.states
    if type(states) ~= "table" then return nil end
    for i, state in ipairs(states) do
      if state.__widescreenUiPokedexRoot or isNativePokedexList(state) then
        return i, #states
      end
    end
  end

  local function validatePokedexSnapshot(snapshot)
    if type(snapshot) ~= "table" then return nil, "snapshot must be a table" end
    local function finite(value)
      return type(value) == "number" and value == value
        and value ~= math.huge and value ~= -math.huge
    end
    local function integer(value)
      return finite(value) and value % 1 == 0
    end
    local function nonempty(value)
      return type(value) == "string" and value ~= ""
    end
    local function rowsCommon(rows, label)
      if type(rows) ~= "table" then return nil, label .. " rows must be a table" end
      for i, row in ipairs(rows) do
        if type(row) ~= "table" then
          return nil, label .. " row " .. tostring(i) .. " must be a table"
        end
      end
      return true
    end
    if snapshot.schemaVersion == PokedexProviderUI.compatVersion then
      if type(snapshot.screen) ~= "string" then
        return nil, "v1 snapshot screen must be a string"
      end
      local ok, reason = rowsCommon(snapshot.rows, "v1")
      if not ok then return nil, reason end
      if not finite(snapshot.selectedIndex) then
        return nil, "v1 snapshot selectedIndex must be numeric"
      end
      for i, row in ipairs(snapshot.rows) do
        if type(row.label) ~= "string" and type(row.name) ~= "string" then
          return nil, "v1 snapshot row " .. tostring(i)
            .. " must have a label or species name"
        end
      end
      return snapshot
    end
    if snapshot.schemaVersion ~= POKEDEX_PROVIDER_API_VERSION then
      return nil, "unsupported snapshot schemaVersion"
    end
    local screens = {
      pokedex = true, pokedex_habitat = true, pokedex_stats = true,
      pokedex_learnset = true, pokedex_evolution = true,
    }
    if not screens[snapshot.screen] then
      return nil, "unsupported v2 screen " .. tostring(snapshot.screen)
    end
    local okRows, rowsReason = rowsCommon(snapshot.rows, snapshot.screen)
    if not okRows then return nil, rowsReason end
    if not integer(snapshot.selectedIndex) then
      return nil, "v2 selectedIndex must be an integer"
    end
    if snapshot.scroll ~= nil and (not integer(snapshot.scroll) or snapshot.scroll < 0) then
      return nil, "v2 scroll must be a non-negative integer"
    end
    if snapshot.screen == "pokedex" then
      for i, row in ipairs(snapshot.rows) do
        if not nonempty(row.speciesId) or not nonempty(row.number)
            or type(row.seen) ~= "boolean" or type(row.owned) ~= "boolean"
            or type(row.hidden) ~= "boolean" then
          return nil, "pokedex row " .. tostring(i)
            .. " must define speciesId, number and privacy flags"
        end
        if row.owned and not row.seen then
          return nil, "pokedex row " .. tostring(i) .. " cannot be owned but unseen"
        end
        if row.seen and not nonempty(row.name) then
          return nil, "seen pokedex row " .. tostring(i) .. " requires a name"
        end
      end
      if type(snapshot.counts) ~= "table"
          or not integer(snapshot.counts.seen)
          or not integer(snapshot.counts.owned)
          or not integer(snapshot.counts.total) then
        return nil, "pokedex counts must contain integer seen/owned/total"
      end
      local detail = snapshot.detail
      if type(detail) ~= "table" or type(detail.portrait) ~= "table" then
        return nil, "pokedex detail and portrait are required"
      end
      if type(detail.seen) ~= "boolean" or type(detail.owned) ~= "boolean"
          or type(detail.hidden) ~= "boolean" or (detail.owned and not detail.seen) then
        return nil, "pokedex detail requires consistent privacy flags"
      end
      if detail.hidden or detail.seen == false then
        if detail.portrait.kind ~= "unknown" then
          return nil, "unseen detail must use an unknown portrait"
        end
      else
        if not nonempty(detail.speciesId) or not nonempty(detail.number)
            or not nonempty(detail.name) or detail.portrait.kind ~= "pokemon"
            or detail.portrait.speciesId ~= detail.speciesId
            or detail.portrait.side ~= "front"
            or detail.portrait.purpose ~= "pokedex"
            or detail.portrait.shiny ~= false then
          return nil, "seen detail requires matching normal Pokemon portrait data"
        end
      end
      if snapshot.submenu ~= nil then
        local submenu = snapshot.submenu
        local expected = { "habitat", "stats", "learnset", "evolution", "cry" }
        if type(submenu) ~= "table" or not integer(submenu.selectedIndex)
            or type(submenu.rows) ~= "table" or #submenu.rows ~= #expected then
          return nil, "submenu must contain selectedIndex and five ordered rows"
        end
        for i, id in ipairs(expected) do
          local row = submenu.rows[i]
          if type(row) ~= "table" or row.id ~= id or not nonempty(row.label) then
            return nil, "submenu row " .. tostring(i) .. " must be " .. id
          end
        end
      end
      return snapshot
    end

    if not nonempty(snapshot.speciesId) or not nonempty(snapshot.number)
        or not nonempty(snapshot.name) then
      return nil, snapshot.screen .. " requires speciesId, number and name"
    end
    if snapshot.gated then
      if not nonempty(snapshot.message) then
        return nil, snapshot.screen .. " gated state requires a message"
      end
      return snapshot
    end
    if #snapshot.rows == 0 then
      return nil, snapshot.screen .. " requires an explicit typed or message row"
    end
    if snapshot.screen == "pokedex_habitat" then
      for i, row in ipairs(snapshot.rows) do
        if row.kind == "habitat" then
          if not nonempty(row.mapId) or not nonempty(row.mapName)
              or not nonempty(row.method) or not integer(row.minLevel)
              or not integer(row.maxLevel) or row.minLevel > row.maxLevel
              or (row.slotChance ~= nil and not finite(row.slotChance))
              or (row.stepChance ~= nil and not finite(row.stepChance))
              or (row.conditions ~= nil and type(row.conditions) ~= "table") then
            return nil, "invalid habitat row " .. tostring(i)
          end
        elseif row.kind ~= "message" or not nonempty(row.label or row.message) then
          return nil, "habitat row " .. tostring(i) .. " has an unsupported kind"
        end
      end
    elseif snapshot.screen == "pokedex_stats" then
      if snapshot.types ~= nil and type(snapshot.types) ~= "table" then
        return nil, "stats types must be a table"
      end
      for i, row in ipairs(snapshot.rows) do
        if row.kind ~= "stat" and row.kind ~= "total" and row.kind ~= "message" then
          return nil, "stats row " .. tostring(i) .. " has an unsupported kind"
        end
        if not nonempty(row.label or row.id) then
          return nil, "stats row " .. tostring(i) .. " requires a label"
        end
        -- Malformed or absent stat values are valid semantic input: the
        -- presenter renders an em dash and never silently coerces them to 0.
      end
    elseif snapshot.screen == "pokedex_learnset" then
      for i, row in ipairs(snapshot.rows) do
        if row.kind == "move" then
          if not nonempty(row.moveId) or not nonempty(row.moveName)
              or not nonempty(row.typeId or row.typeName)
              or (row.power ~= nil and not finite(row.power))
              or (row.accuracy ~= nil and not finite(row.accuracy))
              or (row.pp ~= nil and not finite(row.pp)) then
            return nil, "invalid learnset move row " .. tostring(i)
          end
        elseif row.kind == "section" or row.kind == "message" then
          if not nonempty(row.label or row.message) then
            return nil, "learnset row " .. tostring(i) .. " requires a label"
          end
        else
          return nil, "learnset row " .. tostring(i) .. " has an unsupported kind"
        end
      end
    elseif snapshot.screen == "pokedex_evolution" then
      for i, row in ipairs(snapshot.rows) do
        if row.kind == "evolution" then
          if not nonempty(row.method) then
            return nil, "evolution row " .. tostring(i) .. " requires method text"
          end
          if not row.targetHidden and not nonempty(row.targetName or row.targetSpeciesId) then
            return nil, "visible evolution row " .. tostring(i) .. " requires a target"
          end
        elseif row.kind ~= "message" or not nonempty(row.label or row.message) then
          return nil, "evolution row " .. tostring(i) .. " has an unsupported kind"
        end
      end
    end
    return snapshot
  end

  local function invalidProviderPokedexSnapshot(reason)
    return {
      schemaVersion = POKEDEX_PROVIDER_API_VERSION,
      screen = "pokedex", title = "POKEDEX",
      rows = {}, selectedIndex = 1, scroll = 0,
      counts = { seen = 0, owned = 0, total = 0 },
      detail = {
        number = "---", seen = false, owned = false, hidden = true,
        portrait = { kind = "unknown" },
      },
      providerError = tostring(reason or "PROVIDER DATA UNAVAILABLE"),
    }
  end

  local function providerPokedexPresentation(game)
    local provider = pokedexProvider
    local states = game and game.stack and game.stack.states
    if not provider or type(states) ~= "table" then return nil end
    for i = #states, 1, -1 do
      local state = states[i]
      if pokedexProviderOwnsState(state) then
        local okSnapshot, value, reason = pcall(provider.snapshot, game, state)
        if not okSnapshot then
          pokedexProviderLogError("snapshot exception: " .. tostring(value))
          value, reason = nil, value
        end
        if value == nil then
          pokedexProviderLogError("provider returned no snapshot: " .. tostring(reason))
          local fallback = PokedexProviderUI.lastValid[state]
            or invalidProviderPokedexSnapshot(reason)
          return state, i, #states, fallback
        end
        local snapshot, invalid = validatePokedexSnapshot(value)
        if not snapshot or snapshot.schemaVersion ~= provider.apiVersion then
          invalid = invalid or ("snapshot schemaVersion does not match registered API "
            .. tostring(provider.apiVersion))
          pokedexProviderLogError("invalid snapshot: " .. tostring(invalid))
          local fallback = PokedexProviderUI.lastValid[state]
            or invalidProviderPokedexSnapshot(invalid)
          return state, i, #states, fallback
        end
        PokedexProviderUI.lastValid[state] = snapshot
        return state, i, #states, snapshot
      end
    end
  end

  local function pokedexPresentation(game)
    if not optionEnabled("pokedex_screen") then return nil end
    local providerState, providerFirst, providerLast, snapshot =
      providerPokedexPresentation(game)
    if providerState then
      if snapshot.schemaVersion == POKEDEX_PROVIDER_API_VERSION then
        return "provider_v2", providerState, providerFirst, providerLast,
          snapshot
      end
      local rows = {}
      for _, row in ipairs(snapshot.rows) do
        local copy = {}
        for key, value in pairs(row) do copy[key] = value end
        if not copy.label then
          local number = copy.number and (tostring(copy.number) .. " ") or ""
          copy.label = number .. (copy.hidden and "?????" or copy.name)
        end
        if copy.owned then copy.marker = true end
        rows[#rows + 1] = copy
      end
      local footer = snapshot.footer
      if not footer and type(snapshot.counts) == "table" then
        footer = ("SEEN %03d     OWN %03d     A OPEN     B BACK"):format(
          tonumber(snapshot.counts.seen) or 0,
          tonumber(snapshot.counts.owned) or 0)
      end
      local model = {
        title = snapshot.title or "POKEDEX",
        rows = rows,
        index = snapshot.selectedIndex,
        scroll = snapshot.scroll or 0,
        footer = footer,
      }
      return "list", providerState, providerFirst, providerLast, model
    end
    local first, last = pokedexRootRange(game)
    if not first then return nil end
    local states = game.stack.states
    local baseIndex = last
    while baseIndex > first do
      local mt = getmetatable(states[baseIndex])
      if mt == TextBoxClass or mt == ChoiceBoxClass then
        baseIndex = baseIndex - 1
      else
        break
      end
    end
    local state = states[baseIndex]
    local mt = getmetatable(state)
    if mt == DexEntryMenuClass then
      return "entry", state, baseIndex, last
    end
    if mt == ListMenuClass or mt == MenuClass then
      return "list", state, baseIndex, last, nil
    end
    return nil
  end

  local function titlePresentation(game)
    if not optionEnabled("title_menu") then return nil end
    if not (TitleStateClass and MenuClass) then return nil end
    local states = game and game.stack and game.stack.states
    if type(states) ~= "table" or #states < 1 then return nil end
    local title
    for _, state in ipairs(states) do
      if getmetatable(state) == TitleStateClass then title = state break end
    end
    if not title then return nil end
    local top = states[#states]
    if top == title then return "title", title, nil end
    if getmetatable(top) == MenuClass and top.titleUiBox then
      return "menu", title, top
    end
    if top.title == title and type(top.save) == "table" then
      return "continue", title, top
    end
  end

  local function loadReportPresentation(game)
    if not optionEnabled("load_report") then return nil end
    if not QuarantineReportClass then return nil end
    local state = topState(game)
    if state and getmetatable(state) == QuarantineReportClass then return state end
  end

  local function optionsPresentation(game)
    if not optionEnabled("options_menu") or not OptionsMenuClass then return nil end
    local state = topState(game)
    if state and getmetatable(state) == OptionsMenuClass then return state end
  end

  local function managerPresentation(game)
    if not optionEnabled("options_menu") or not ManagerStateClass then return nil end
    local state = topState(game)
    if state and getmetatable(state) == ManagerStateClass then return state end
  end

  -- Return the contiguous native dialogue/choice layer at the top of the
  -- stack. This is deliberately presentation-only: TextBox and ChoiceBox
  -- continue to own typing, text speed, page/control markers, input and every
  -- callback. A non-dialogue modal on top ends Widescreen ownership so an
  -- unknown third-party screen can retain its own native presentation.
  local function dialoguePresentation(game)
    if not optionEnabled("dialogue_boxes") then return nil end
    local states = game and game.stack and game.stack.states
    if type(states) ~= "table" or #states < 1 then return nil end
    local last = #states
    local first = last
    while first >= 1 do
      local mt = getmetatable(states[first])
      if mt ~= TextBoxClass and mt ~= ChoiceBoxClass then break end
      first = first - 1
    end
    if first == last then return nil end
    return first, last
  end

  local function convertedDialogueRange(game, background)
    local first, last = presentationRange(game, background)
    if not first then return nil end
    local states = game.stack.states
    for i = first + 1, last do
      local mt = getmetatable(states[i])
      if mt ~= TextBoxClass and mt ~= ChoiceBoxClass then return nil end
    end
    return first, last
  end

  local function dialogueBackedState(game, class, predicate)
    if not class then return nil end
    local first, last = dialoguePresentation(game)
    if not first or first < 1 then return nil end
    local state = game.stack.states[first]
    if class and getmetatable(state) ~= class then return nil end
    if predicate and not predicate(state) then return nil end
    return state, first, last
  end

  -- Native TextBox and ChoiceBox render in the engine's 160x144 viewport.
  -- When one sits over a widescreen background, drawing it before our final
  -- presenter leaves a second box docked below the custom UI. Suppress only
  -- that native pass; drawPresentationOverlays recreates the active overlay
  -- afterward in 640x360 design space. Other game screens remain untouched.
  local function customBackgroundOwnsStack(game)
    if optionEnabled("start_menu") and activeStart
        and convertedDialogueRange(game, activeStart) then
      return true
    end
    if optionEnabled("summary_screen") and activeSummary
        and presentationRange(game, activeSummary) then
      return true
    end
    if optionEnabled("party_screen") and activeParty
        and presentationRange(game, activeParty) then
      return true
    end
    if optionEnabled("battle_hud") and activeBattle
        and convertedDialogueRange(game, activeBattle) then
      return true
    end
    if pokedexPresentation(game) then return true end
    return false
  end

  local function suppressNativeOverlayDraw(class, marker)
    if not (class and type(class.draw) == "function") or class[marker] then
      return
    end
    local originalDraw = class.draw
    class.draw = function(self, ...)
      local game = self and self.game
      if customBackgroundOwnsStack(game) or dialoguePresentation(game) then
        return
      end
      return originalDraw(self, ...)
    end
    class[marker] = true
  end
  suppressNativeOverlayDraw(TextBoxClass, "__widescreenUiTextDrawWrapped")
  suppressNativeOverlayDraw(ChoiceBoxClass, "__widescreenUiChoiceDrawWrapped")

  if OptionsMenuClass and type(OptionsMenuClass.draw) == "function"
      and not OptionsMenuClass.__widescreenUiDrawWrapped then
    local originalOptionsDraw = OptionsMenuClass.draw
    OptionsMenuClass.draw = function(self, ...)
      if optionEnabled("options_menu") then return end
      return originalOptionsDraw(self, ...)
    end
    OptionsMenuClass.__widescreenUiDrawWrapped = true
  end
  if ManagerStateClass and type(ManagerStateClass.draw) == "function"
      and not ManagerStateClass.__widescreenUiDrawWrapped then
    local originalManagerDraw = ManagerStateClass.draw
    ManagerStateClass.draw = function(self, ...)
      if optionEnabled("options_menu") then
        local game = self and self.game
        local backed = dialogueBackedState(game, ManagerStateClass)
        if topState(game) == self or backed == self then return end
      end
      return originalManagerDraw(self, ...)
    end
    ManagerStateClass.__widescreenUiDrawWrapped = true
  end

  mod.hooks:wrap("render.hud", function(next, game, viewport)
    patchDramaticShapeBattle(game)
    local result = next(game, viewport)
    if not fonts.body then return result end

    if activeStart and not stateInStack(game, activeStart) then
      activeStart = nil
    end
    if activeParty and not stateInStack(game, activeParty) then
      activeParty = nil
    end
    if activeSummary and not stateInStack(game, activeSummary) then
      activeSummary = nil
    end
    if activeBattle and not stateInStack(game, activeBattle) then
      activeBattle = nil
    end

    local top = topState(game)
    local summaryFirst, summaryLast
    if optionEnabled("summary_screen") and activeSummary and SummaryMenu then
      summaryFirst, summaryLast = presentationRange(game, activeSummary)
    end
    local partyFirst, partyLast
    if optionEnabled("party_screen") and activeParty and PartyMenu then
      partyFirst, partyLast = presentationRange(game, activeParty)
    end
    local startFirst, startLast
    if optionEnabled("start_menu") and activeStart then
      startFirst, startLast = convertedDialogueRange(game, activeStart)
    end
    local battleFirst, battleLast
    if optionEnabled("battle_hud") and activeBattle then
      battleFirst, battleLast = convertedDialogueRange(game, activeBattle)
    end
    local dexKind, dexState, dexFirst, dexLast, dexModel = pokedexPresentation(game)
    local titleKind, titleState, titleOverlay = titlePresentation(game)
    local loadReport = loadReportPresentation(game)
    local optionsState = optionsPresentation(game)
    local managerState = managerPresentation(game)
    local dialogueFirst, dialogueLast = dialoguePresentation(game)
    local managerDialogue, managerDialogueFirst, managerDialogueLast =
      dialogueBackedState(game, ManagerStateClass)
    local optionsDialogue, optionsDialogueFirst, optionsDialogueLast =
      dialogueBackedState(game, OptionsMenuClass)
    local loadDialogue, loadDialogueFirst, loadDialogueLast =
      dialogueBackedState(game, QuarantineReportClass)
    local titleDialogue, titleDialogueFirst, titleDialogueLast =
      dialogueBackedState(game, MenuClass, function(state)
        return state and state.titleUiBox
      end)
    local dialogueTitleState
    if titleDialogue then
      for _, state in ipairs(game.stack.states) do
        if getmetatable(state) == TitleStateClass then
          dialogueTitleState = state
          break
        end
      end
    end
    if managerState then
      drawInBattleSpace(function(viewW, viewH)
        drawModManager(managerState, fonts, viewW, viewH)
      end)
    elseif managerDialogue then
      drawInBattleSpace(function(viewW, viewH)
        drawModManager(managerDialogue, fonts, viewW, viewH)
        drawPresentationOverlays(game, managerDialogueFirst,
          managerDialogueLast, fonts, viewW, viewH)
      end)
    elseif optionsState then
      drawInBattleSpace(function(viewW, viewH)
        drawOptionsMenu(optionsState, fonts, viewW, viewH)
      end)
    elseif optionsDialogue then
      drawInBattleSpace(function(viewW, viewH)
        drawOptionsMenu(optionsDialogue, fonts, viewW, viewH)
        drawPresentationOverlays(game, optionsDialogueFirst,
          optionsDialogueLast, fonts, viewW, viewH)
      end)
    elseif loadReport then
      drawInBattleSpace(function(viewW, viewH)
        drawLoadReport(loadReport, fonts, viewW, viewH)
      end)
    elseif loadDialogue then
      drawInBattleSpace(function(viewW, viewH)
        drawLoadReport(loadDialogue, fonts, viewW, viewH)
        drawPresentationOverlays(game, loadDialogueFirst,
          loadDialogueLast, fonts, viewW, viewH)
      end)
    elseif titleKind then
      drawInBattleSpace(function(viewW, viewH)
        if titleKind == "continue" then
          drawContinueInfo(titleState, titleOverlay, fonts, viewW, viewH)
        elseif titleKind == "title" then
          drawTitleStandby(titleState, fonts, viewW, viewH)
        else
          drawTitleMenu(titleState, titleOverlay, fonts, viewW, viewH)
        end
      end)
    elseif titleDialogue and dialogueTitleState then
      drawInBattleSpace(function(viewW, viewH)
        drawTitleMenu(dialogueTitleState, titleDialogue, fonts, viewW, viewH)
        drawPresentationOverlays(game, titleDialogueFirst,
          titleDialogueLast, fonts, viewW, viewH)
      end)
    elseif summaryFirst then
      drawInDesignSpace(function()
        drawSummaryMenu(activeSummary, fonts)
        drawPresentationOverlays(game, summaryFirst, summaryLast, fonts)
      end)
    elseif partyFirst then
      drawInDesignSpace(function()
        drawPartyMenu(mod, activeParty, PartyMenu, fonts)
        drawPresentationOverlays(game, partyFirst, partyLast, fonts)
      end)
    elseif dexKind then
      drawInDesignSpace(function()
        if dexKind == "provider_v2" then
          PokedexProviderUI.draw(game, dexState, dexModel, fonts)
        elseif dexKind == "entry" then
          drawPokedexEntry(dexState, fonts)
        else
          drawPokedexList(dexState, fonts, dexModel)
        end
        drawPresentationOverlays(game, dexFirst, dexLast, fonts)
      end)
    elseif startFirst then
      drawInDesignSpace(function()
        drawStartMenu(activeStart, fonts)
        drawPresentationOverlays(game, startFirst, startLast, fonts)
      end)
    elseif battleFirst then
      drawInBattleSpace(function(viewW, viewH)
        drawBattleHUD(activeBattle, fonts, viewW, viewH)
        drawPresentationOverlays(game, battleFirst, battleLast, fonts,
                                 viewW, viewH)
      end)
    elseif dialogueFirst then
      drawInBattleSpace(function(viewW, viewH)
        drawPresentationOverlays(game, dialogueFirst, dialogueLast, fonts,
                                 viewW, viewH)
      end)
    end
    if #worldHudOverlayProviders > 0 then
      drawInBattleSpace(function(viewW, viewH)
        drawWorldHudExtensions(game, fonts, viewW, viewH)
      end)
    end
    return result
  end, 12000)

  mod.exports.designWidth = DESIGN_W
  mod.exports.designHeight = DESIGN_H
  mod.exports.resolve2dPokemonPortrait = selectedBattleSpriteImage
  mod.exports.draw2dPokemonPortrait = drawPartyBattleSprite
  mod.exports.portraitPolicy = "battle_art_2d_only"
  mod.exports.prototype = "title_start_party_summary_pokedex_report_and_battle"
  mod.exports.battleHud = "responsive_640x360"
  mod.exports.battleMoveInspectorContract = "v1"
  mod.exports.dialoguePresentation = "native_behavior_responsive_skin_v1"
  mod.exports.pokedexPresentation = "native_independent_style_v1"
  mod.exports.pokedexProviderContract = "v2_with_v1_compat"
end
