# Asset provenance

## FRLG player batch

- Source supplied by the user: `Game Boy Advance - Pokemon FireRed _ LeafGreen - Playable Characters - Player Sprites.png`.
- Source dimensions: 673x638 RGBA.
- Depicted game/source: Pokemon FireRed and Pokemon LeafGreen (Game Boy Advance).
- Sheet compiler/ripper: not identified in the supplied file. The filename and sheet labeling are preserved here; no unsupported author attribution is invented.
- Transformation: exact reviewed rectangles were cropped; the sheet's orange `#ff7f27` and green `#22b14c` matte colors were converted to transparent alpha. Walk, the distinct authored Running Shoes block, and bicycle frames were reordered from the source's `step A | neutral idle | step B` columns into twelve-pose idle/step-A/step-B sequences covering down/up/left/right, while Surf retains its six-pose source coverage. Running uses source columns x=68/85/102 and Red/Leaf direction rows y=42/75/108/141 and y=309/342/375/408 respectively. No interpolation, recoloring, generative processing, or ROM content outside this supplied sheet was used.
- Reproduction tool: `tools/extract_frlg_player_batch.py` in the editable source tree.
- Machine-readable dimensions and SHA-256 hashes: `FRLG_EXTRACTION_REPORT.json`.
- Output assets: Red/Leaf walk, run, bicycle, Surf composition, player front, battle back, and main-menu presentation images.
- Rights: these are game-derived graphics supplied by the user for this mod. They are not covered by the code license. No ROM is included.

The full source sheet is intentionally not packaged in the release.

## FRLG overworld NPC and item-ball batch

- Source supplied by the user: `Game Boy Advance - Pokemon FireRed _ LeafGreen - Trainers & Non-Playable Characters - Overworld NPCs.png`.
- Source dimensions: 238x2967 RGBA.
- Depicted game/source: Pokemon FireRed and Pokemon LeafGreen (Game Boy Advance).
- Sheet compiler/ripper: not identified in the supplied file; no unsupported attribution is invented.
- Scope: human overworld NPCs and the single overworld item-ball icon only.
  The Pokémon section and every other miscellaneous element are excluded.
- Transformation: exact source frames were identified by opaque-pixel identity
  against the corresponding pret/pokefirered object-event graphics, then
  cropped from the supplied atlas. Orange `#ff7f27` and green `#22b14c` mattes
  were converted to transparent alpha. Common walkers were reordered into the
  engine's down/up/left idle and walk sequence; static source roles remain
  static. No interpolation, recoloring, or generative processing was used.
- Reproduction tools: `tools/map_frlg_overworld_sheet.py` and
  `tools/extract_frlg_overworld_npcs.py`.
- Machine-readable source coordinates, reference hashes, output dimensions,
  and SHA-256 hashes: `FRLG_NPC_EXTRACTION_REPORT.json`.
- Output assets: 49 human NPC sheets and one 16x16 overworld item-ball icon.
- Pokémon object art is not copied from this atlas. At runtime it is requested
  from HGSS Simple Follower through its public Overworld Sprite API v1.
- Rights: these are game-derived graphics supplied by the user for this mod.
  They are not covered by the code license. No ROM is included.

The full source sheet and the pret reference tree are intentionally not
packaged in the release.

## FRLG trainer and player-throw batch

- Source supplied by the user: `Game Boy Advance - Pokemon FireRed _ LeafGreen - Trainers & Non-Playable Characters - Trainers.png`.
- Source dimensions: 536x1400 RGBA.
- Depicted game/source: Pokemon FireRed and Pokemon LeafGreen (Game Boy Advance).
- Sheet host: The Spriters Resource trainer asset page; individual ripper attribution was not embedded in the supplied PNG, so none is invented here.
- Transformation: exact 64x64 cells were cropped and the orange `#ff7f27` matte was converted to transparent alpha. Enemy mappings follow direct Kanto class equivalents; unsupported special portraits retain ROM art.
- Reproduction tool: `tools/extract_frlg_trainers_batch.py` in the editable source tree.
- Machine-readable dimensions and SHA-256 hashes: `FRLG_TRAINER_EXTRACTION_REPORT.json`.
- Output assets: 45 extracted trainer fronts (44 mapped to Gen 1 opponent
  classes) plus five Red and five Leaf player-back throw frames.
- Rights: these are game-derived graphics supplied by the user for this mod. They are not covered by the code license. No ROM is included.

The full source sheet is intentionally not packaged in the release.
