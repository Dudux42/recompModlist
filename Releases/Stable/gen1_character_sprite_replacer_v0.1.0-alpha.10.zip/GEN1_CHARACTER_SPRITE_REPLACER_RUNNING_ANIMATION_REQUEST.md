# Request: Running animation consumer for Running State API v1

Send this request to the agent responsible for **Gen1 Character Sprite
Replacer**.

## 1. Owning provider

- Mod: Gen1 Character Sprite Replacer
- Manifest ID: `gen1_character_sprite_replacer`
- Audited version: `0.1.0-alpha.8`
- Existing public surface: Character Appearance API v1, including
  `resolvePlayerOverworld(role, context)` and `invalidate()`
- Relevant owned source surface: the `RoleSprite` walk-frame selection and
  player `pose()` adapter in `main.lua`, plus the provider's player sheets and
  descriptors

This mod owns player appearance and animation selection. Do not implement its
running art or pose mapping in the QoL mod.

## 2. Dependent use case

Gen1 Unified Quality of Life (`gen1_quality_of_life`) version
`0.1.0-alpha.7` adds always-available Running Shoes. Holding B during an
ordinary walking step shortens movement duration to an exact 1.5x average
speed. It exports Running State API v1 so this appearance provider can show a
dedicated running animation during those steps.

## 3. Verified evidence and uncertainty

Verified:

- Gen1Recomp's public `movement.speed` context identifies the player, input,
  bicycle state, and Surf state. QoL uses that hook and does not patch Player.
- QoL exports `runningStateApiVersion = 1`,
  `runningSpeedMultiplier = 1.5`, `runningStateSnapshot(game?)`, and
  `isPlayerSprinting(game?)`.
- Character Sprite Replacer alpha.8 already owns live player `sprite`,
  `bikeSprite`, and `surfSprite` wrapping and walk-frame selection.
- Its documented enhanced FRLG sheets contain neutral and two authored walking
  poses for all four directions. Those are verified walking frames, not
  verified running frames.

Unresolved: authentic compatible Red/Leaf running frames have not been
verified in the supplied assets. Inspect the owned source assets first. If no
appropriate frames exist, report the exact asset specification needed; do not
mislabel stretched or accelerated walk frames as a completed running
animation.

## 4. Smallest provider-side change

Optionally discover `gen1_quality_of_life` and consume Running State API v1
during the provider's existing player pose/frame-selection path. When the
snapshot says `sprinting = true` and the selected appearance has authored run
frames, select the correct direction and cadence from owner-controlled assets.
Otherwise preserve the current walk result.

Keep all new frame descriptors, asset validation, animation cadence, native
2D drawing, and Dramatic Shape adaptation inside Character Sprite Replacer.

## 5. Non-goals

- Do not change movement speed, B-button input, collision, tile timing, field
  moves, bicycle, Surf, fishing, ledge hops, or scripted movement.
- Do not copy the QoL movement algorithm or infer sprinting from raw B input.
- Do not add running art or appearance logic to the QoL mod.
- Do not replace ROM-mode art with FRLG art.
- Do not install either mod automatically.

## 6. Contract and compatibility requirements

Discover the optional provider dynamically and require
`runningStateApiVersion == 1`. Call `runningStateSnapshot(game?)`; the returned
table has value fields only:

```lua
{
  schemaVersion = 1,
  sprinting = boolean,
  bHeld = boolean,
  moving = boolean,
  landed = boolean,
  onBike = boolean,
  surfing = boolean,
  facing = string | nil,
  stepFrames = number | nil,
  baseStepFrames = number | nil,
  speedMultiplier = 1 | 1.5,
}
```

Only `sprinting` is authoritative for selecting a running pose. It is true
only during a sprinted moving step or its landing frame; holding B while idle
does not qualify. Treat absent providers, lookup failures, thrown calls,
unknown API versions, false/nil sprint state, ROM mode, and appearances without
authored running frames as normal walking. Cache no live snapshot across
frames. Re-resolve after `mods.loaded` and the provider's existing invalidation
events so load order and runtime option/pack changes fail open.

Preserve nearest-neighbor filtering, native 2D behavior, Dramatic Shape
compatibility, the Character Appearance API v1 contract, and all existing
walk/bike/surf/fishing/battle presentation behavior.

## 7. Acceptance tests and audits

Add Lua 5.1 coverage for:

- no QoL mod and incompatible/missing API: unchanged walking;
- B held while idle: unchanged standing pose;
- ordinary walking: current walk animation;
- active QoL sprint: direction-correct running animation;
- B released before the next step: next step uses walking;
- bicycle, Surf, fishing, ledge hop, and scripted movement: unchanged;
- ROM selection or a pack without authored running frames: ROM/current
  fallback, with no fabricated pose;
- all four directions and both Red/Leaf packs that actually provide run art;
- native 2D and Dramatic Shape paths remain valid;
- API call failure is contained and does not break rendering.

Visually audit pixel alignment, no linear filtering, no frame-edge bleed, no
idle flash between chained tiles, and consistent landing frames. Build a flat,
root-only release ZIP and audit it for duplicates, nested paths, missing files,
and unexpected files. Do not install it.

## 8. Version and dependency changes

Bump Character Sprite Replacer from `0.1.0-alpha.8` to the next owner-selected
version. Add an optional dependency on
`gen1_quality_of_life@>=0.1.0-alpha.7 <0.2.0`; absence must remain supported.
Do not change Character Appearance API v1 unless this work independently
requires a provider-owned public contract change. Document the optional
Running State API v1 consumption and asset fallback in the README.

## 9. Required return artifacts

Return:

1. every changed/added file and the new manifest version;
2. whether authentic running frames were found, their provenance, and their
   exact descriptor/frame mapping—or a precise asset request if blocked;
3. the finalized consumer behavior and failure/fallback rules;
4. exact test commands and results;
5. visual-audit evidence for native 2D and Dramatic Shape where available;
6. the flat release ZIP path and archive inventory/audit result.

