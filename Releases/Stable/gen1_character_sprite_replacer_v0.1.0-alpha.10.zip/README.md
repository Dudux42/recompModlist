# Gen1 Character Sprite Replacer

Current build: **0.1.0-alpha.10**

The player appearance selector provides:

- `FRLG RED (MALE)`
- `FRLG LEAF (FEMALE)`
- `ROM`

It also provides an independent `ENEMY TRAINERS` selector:

- `ROM`
- `GEN 3 (FRLG)`

And an independent `OVERWORLD NPCS` selector:

- `ROM`
- `GEN 3 (FRLG)`

The male/female labels describe the selected visual character. The mod does not change player name, save identity, gender semantics, collision, movement, scripts, parties, battle rules, or world geometry.

## Implemented surfaces

- Native 2D walking and bicycle animation using the neutral center-column idle,
  both authored FRLG step frames, and all four authored directions, plus
  standard Surf composition.
- Authentic Red/Leaf Running Shoes animation from the supplied sheet's
  separate running block. It is selected only while optional Unified QoL
  Running State API v1 reports `sprinting = true`; each direction retains
  neutral, step-A, and step-B authored frames.
- New-game/Oak-intro player front through the engine's live `player.sprite` seam.
- Trainer Card player front.
- Hall of Fame player front and player-back sweep.
- Normal player battle back/send-out presentation.
- Five-frame FRLG Red/Leaf player throw animation during the opening battle
  send-out, with a smooth 40-frame synchronized trainer-back slide. When the
  Widescreen battle HUD is active, that presenter owns the single visible copy.
- Mapped FRLG enemy trainer portraits for 44 Gen 1 opponent classes,
  including rivals, Gym Leaders, and the Elite Four. They remain static and
  use the engine's original single battle placement.
- Mapped FRLG overworld art for 60 Red/Blue/Yellow human role IDs, backed by
  49 exact human assets from the supplied NPC sheet. Static source characters
  remain static; walking roles retain the native Gen 1 movement clock and
  collision footprint.
- FRLG overworld Poké Ball icons for visible item objects. Other miscellaneous
  icons and the supplied sheet's entire Pokémon section are excluded.
- ROM-authored overworld Pokémon objects use HGSS Simple Follower's public
  Overworld Sprite API v1 when that optional provider is installed. Static
  encounters use their extracted species; named ambient Pokémon use a reviewed
  object-name crosswalk. Copycat dolls, Bill's transformed object, and runtime
  objects owned by other mods are deliberately excluded. Provider absence or
  failure falls back to the exact ROM renderer.
- Versioned Character Appearance API v1, including a dedicated main-menu presentation descriptor.
- Same-subject ROM fallback for missing assets and explicit `ROM` mode.

Trainer Card, Hall of Fame, intro, and battle use the same selected Red or Leaf pack. Old Man and Yellow Professor Oak tutorial backs remain ROM-owned.

## Optional running-state integration

`gen1_quality_of_life >= 0.1.0-alpha.7 < 0.2.0` is optional. When present,
this mod dynamically resolves `runningStateApiVersion == 1` and calls
`runningStateSnapshot()` on each pose decision. Only `sprinting == true`
selects the authored run sheet. Holding B while idle, ordinary or scripted
walking, released B, bike, Surf, provider failure, unknown API versions, ROM
mode, and packs without run art retain their existing renderer. No movement
speed, input, collision, step timing, or QoL state is changed here.

## Optional overworld-Pokémon integration

`hgss_simple_follower >= 0.1.0-alpha.24 < 0.2.0` is optional. With
`OVERWORLD NPCS = GEN 3 (FRLG)`, this mod calls only its public
`overworldSpriteApiVersion == 1` / `createOverworldSprite` contract. The
follower mod owns Pokémon art and renderer construction; this mod owns only
recognition of ROM map objects and assignment to those objects. No party
follower, encounter, collision, movement, or spawn behavior is changed.

## Honest first-batch fallbacks and blockers

- Fishing keeps the ROM player pose. The engine builds fishing from an 8px Gen 1 hand tile plus a separate rod effect, while this supplied FRLG sheet contains full, inseparable rods. Compositing it directly would double or sever the rod.
- Surfing Pikachu and Fly bird art remain ROM-owned because they are Pokemon/nonhuman effects.
- Enemy-trainer overworld objects use the same human role mapping as other
  NPCs; there is no separate trainer-overworld option.
- Professor Oak and Yellow's special Jessie/James portrait remain ROM-owned
  because the supplied sheet has no direct matching front portrait.
- Widescreen's responsive START/title main-menu presenters do not yet consume a player-character provider. The mod publishes `resolvePlayerPresentation`, and the exact owner request is in `GEN1_WIDESCREEN_UI_CHARACTER_PRESENTATION_REQUEST.md`.
- Dramatic Shape 1.8.0 hardcodes 16x16 billboard geometry, UV steps, and the
  legacy two-frame walk cadence. Alpha 5 installs a scoped runtime adapter
  from this mod for Character Appearance API v1 definitions only. It supplies
  correct frame UVs, the correctly ordered idle/step frames and all four
  authored walk/bicycle directions, 16x32/32x32
  visible geometry, bottom anchoring, mirroring, shadows, and ghost silhouettes
  without editing Dramatic Shape files or affecting ROM or foreign sprites.
  FRLG NPC descriptors use the same scoped adapter. If the
  adapter cannot be installed, the safe alpha 2 ROM-overworld fallback remains.

## Public API

```lua
exports.characterAppearanceApiVersion = 1
exports.activePack()
exports.resolvePlayerOverworld(role, context)
exports.activeNpcPack()
exports.resolveNpcOverworld(spriteId, mapId, objectDef)
exports.resolveTrainerOverworld(trainerClass, context)
exports.resolveTrainerBattle(trainerClass, context)
exports.resolvePlayerBattle(role, context)
exports.resolvePlayerPresentation(role, context)
exports.invalidate()
exports.auditCoverage(game)
```

Resolvers return `nil` for ROM mode, unsupported roles, or missing art. The
NPC resolver returns a descriptor for mapped humans/items and a species ID for
provider-backed Pokémon objects. `run`
is a provider-owned overworld role for consumers that need the authored run
descriptor. Descriptors include the asset path, frame dimensions/count,
ground anchor, logical 16x16 footprint, pack ID, role, and visual-gender label.

## Installation

Import the versioned ZIP through the Gen1 Recomp launcher. Do not unpack it into the installed Mods directory manually. The archive is flat: every entry is at ZIP root.

## License and provenance

Code is MIT licensed. Game-derived images are not covered by the MIT license; see `ASSET_PROVENANCE.md`. No ROM is included.
