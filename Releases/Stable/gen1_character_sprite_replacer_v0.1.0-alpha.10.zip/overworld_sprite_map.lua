-- Gen 1 object sprite id -> reviewed FRLG human/object-event asset.
-- Player roles and every Pokemon-shaped ROM sprite are intentionally absent.
-- Pokemon objects are resolved separately through HGSS Simple Follower's
-- public Overworld Sprite API so this atlas's Pokemon section is never used.

local function npc(name, frames, width, walker)
  return {
    image = "frlg_npc_" .. name .. ".png",
    frames = frames or 6,
    frameWidth = width or 16,
    frameHeight = 32,
    anchorX = (width or 16) / 2,
    anchorY = 32,
    walker = walker ~= false,
    trueColor = true,
  }
end

return {
  humans = {
    SPRITE_OAK = npc("prof_oak"),
    SPRITE_YOUNGSTER = npc("youngster"),
    SPRITE_COOLTRAINER_F = npc("cooltrainer_f"),
    SPRITE_COOLTRAINER_M = npc("cooltrainer_m"),
    SPRITE_LITTLE_GIRL = npc("little_girl"),
    SPRITE_MIDDLE_AGED_MAN = npc("man"),
    SPRITE_GAMBLER = npc("rich_boy"),
    SPRITE_SUPER_NERD = npc("poke_maniac"),
    SPRITE_GIRL = npc("lass"),
    SPRITE_HIKER = npc("hiker"),
    SPRITE_BEAUTY = npc("beauty"),
    SPRITE_GENTLEMAN = npc("gentleman"),
    SPRITE_DAISY = npc("daisy"),
    SPRITE_BIKER = npc("biker", 6, 32),
    SPRITE_SAILOR = npc("sailor"),
    SPRITE_COOK = npc("chef"),
    SPRITE_BIKE_SHOP_CLERK = npc("clerk"),
    SPRITE_MR_FUJI = npc("mr_fuji"),
    SPRITE_GIOVANNI = npc("giovanni"),
    SPRITE_ROCKET = npc("rocket_m"),
    SPRITE_CHANNELER = npc("channeler"),
    SPRITE_WAITER = npc("clerk"),
    SPRITE_SILPH_WORKER_F = npc("worker_f"),
    SPRITE_MIDDLE_AGED_WOMAN = npc("woman_2"),
    SPRITE_BRUNETTE_GIRL = npc("woman_1"),
    SPRITE_LANCE = npc("lance", 3, 16, false),
    SPRITE_UNUSED_SCIENTIST = npc("scientist"),
    SPRITE_SCIENTIST = npc("scientist"),
    SPRITE_ROCKER = npc("rocker"),
    SPRITE_SWIMMER = npc("swimmer_m_land"),
    SPRITE_SAFARI_ZONE_WORKER = npc("worker_m"),
    SPRITE_GYM_GUIDE = npc("gym_guy"),
    SPRITE_GRAMPS = npc("old_man_1"),
    SPRITE_CLERK = npc("clerk"),
    SPRITE_FISHING_GURU = npc("fisher"),
    SPRITE_GRANNY = npc("old_woman"),
    SPRITE_NURSE = npc("nurse", 3, 16, false),
    SPRITE_LINK_RECEPTIONIST = npc("cable_club_receptionist", 3, 16, false),
    SPRITE_SILPH_PRESIDENT = npc("old_man_2"),
    SPRITE_SILPH_WORKER_M = npc("worker_m"),
    SPRITE_WARDEN = npc("balding_man"),
    SPRITE_CAPTAIN = npc("captain"),
    SPRITE_FISHER = npc("fisher"),
    SPRITE_KOGA = npc("koga", 3, 16, false),
    SPRITE_GUARD = npc("policeman"),
    SPRITE_UNUSED_GUARD = npc("policeman"),
    SPRITE_MOM = npc("mom", 3, 16, false),
    SPRITE_BALDING_GUY = npc("balding_man"),
    SPRITE_LITTLE_BOY = npc("little_boy"),
    SPRITE_UNUSED_GAMEBOY_KID = npc("gba_kid", 3, 16, false),
    SPRITE_GAMEBOY_KID = npc("gba_kid", 3, 16, false),
    SPRITE_AGATHA = npc("agatha", 3, 16, false),
    SPRITE_BRUNO = npc("bruno", 3, 16, false),
    SPRITE_LORELEI = npc("lorelei"),
    SPRITE_GAMBLER_ASLEEP = npc("old_man_lying_down", 1, 32, false),
    SPRITE_UNUSED_GAMBLER_ASLEEP_1 = npc("old_man_lying_down", 1, 32, false),
    SPRITE_UNUSED_GAMBLER_ASLEEP_2 = npc("old_man_lying_down", 1, 32, false),

    -- Yellow-only human roles.
    SPRITE_OFFICER_JENNY = npc("policeman"),
    SPRITE_JESSIE = npc("rocket_f"),
    SPRITE_JAMES = npc("rocket_m"),
  },

  items = {
    SPRITE_POKE_BALL = {
      image = "frlg_overworld_item_ball.png",
      frames = 1,
      frameWidth = 16,
      frameHeight = 16,
      anchorX = 8,
      anchorY = 16,
      walker = false,
      trueColor = true,
    },
  },

  -- Yellow has unambiguous species-specific sprite ids. Snorlax is also
  -- unambiguous in Red/Blue. Generic MONSTER/BIRD/FAIRY/SEEL ids are resolved
  -- from the extracted object name or static-encounter species instead.
  pokemonBySprite = {
    SPRITE_PIKACHU = "PIKACHU",
    SPRITE_SANDSHREW = "SANDSHREW",
    SPRITE_ODDISH = "ODDISH",
    SPRITE_BULBASAUR = "BULBASAUR",
    SPRITE_JIGGLYPUFF = "JIGGLYPUFF",
    SPRITE_CLEFAIRY = "CLEFAIRY",
    SPRITE_CHANSEY = "CHANSEY",
    SPRITE_SNORLAX = "SNORLAX",
  },
}
