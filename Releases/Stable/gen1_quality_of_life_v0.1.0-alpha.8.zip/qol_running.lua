-- Running Shoes: hold B while walking for an exact 1.5x average speed.

local M = {}

local API_VERSION = 1
local SPEED_MULTIPLIER = 1.5

local function buttonDown(input, button)
  if not input or type(input.isDown) ~= "function" then return false end
  local ok, down = pcall(input.isDown, input, button)
  return ok and down and true or false
end

function M.install(mod)
  local states = setmetatable({}, { __mode = "k" })

  local function stateFor(player)
    if not player then return nil end
    local state = states[player]
    if not state then
      state = { remainder = 0, sprinting = false }
      states[player] = state
    end
    return state
  end

  local function stopSprinting(state)
    if not state then return end
    state.remainder = 0
    state.sprinting = false
    state.baseStepFrames = nil
    state.stepFrames = nil
  end

  mod.hooks:wrap("movement.speed", function(next, frames, context)
    -- Compose after earlier providers so their terrain or movement rule remains
    -- authoritative and Running Shoes scales the resulting walking duration.
    local baseFrames = tonumber(next(frames, context)) or tonumber(frames)
    local player = type(context) == "table" and context.player or nil
    local state = stateFor(player)
    local eligible = baseFrames and baseFrames > 0
      and player ~= nil
      and not context.onBike
      and not context.surfing
      and buttonDown(context.input, "b")

    if not eligible then
      stopSprinting(state)
      return baseFrames or frames
    end

    -- The engine floors movement durations. Carry the fractional remainder
    -- across steps: 16-frame walking becomes 10, 11, 11 frames, for 32
    -- sprint frames per 48 walking frames (exactly 1.5x over the cadence).
    local scaled = baseFrames * 2 + state.remainder
    local sprintFrames = math.max(1, math.floor(scaled / 3))
    state.remainder = scaled - sprintFrames * 3
    state.sprinting = true
    state.baseStepFrames = baseFrames
    state.stepFrames = sprintFrames
    return sprintFrames
  end, 100)

  local function resolveGame(game)
    if game then return game end
    return mod.world and mod.world.game or nil
  end

  local function resolvePlayer(game)
    if mod.world and type(mod.world.overworld) == "function" then
      local ok, overworld = pcall(mod.world.overworld, mod.world)
      if ok and overworld and overworld.player then return overworld.player end
    end
    if game and game.stack and type(game.stack.top) == "function" then
      local ok, screen = pcall(game.stack.top, game.stack)
      if ok and screen and screen.player then return screen.player end
    end
    return nil
  end

  local function snapshot(game)
    game = resolveGame(game)
    local player = resolvePlayer(game)
    local state = player and states[player] or nil
    local save = game and game.save or nil
    local input = game and game.input or nil
    local moving = player and player.moving and true or false
    local landed = player and player.stepLanded and true or false
    local onBike = (save and save.onBike) or (player and player.onBike) or false
    local surfing = player and player.surfing and true or false
    local sprinting = state and state.sprinting and (moving or landed)
      and not onBike and not surfing or false

    return {
      schemaVersion = API_VERSION,
      sprinting = sprinting and true or false,
      bHeld = buttonDown(input, "b"),
      moving = moving,
      landed = landed,
      onBike = onBike and true or false,
      surfing = surfing,
      facing = player and player.facing or nil,
      stepFrames = state and state.stepFrames or nil,
      baseStepFrames = state and state.baseStepFrames or nil,
      speedMultiplier = sprinting and SPEED_MULTIPLIER or 1,
    }
  end

  mod.exports.runningStateApiVersion = API_VERSION
  mod.exports.runningSpeedMultiplier = SPEED_MULTIPLIER
  mod.exports.runningStateSnapshot = snapshot
  mod.exports.isPlayerSprinting = function(game)
    return snapshot(game).sprinting
  end

  return { snapshot = snapshot }
end

return M
