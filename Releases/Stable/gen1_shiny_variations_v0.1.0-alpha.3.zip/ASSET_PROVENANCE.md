# Asset provenance

## Bulbasaur Variant 1

- Supplied by the user on 2026-08-19 as `E:\new shiny\001 bulbasaur.png`.
- Supplied source dimensions: 443×104 RGBA.
- Intended identity: fan-supplied alternate Bulbasaur shiny color design; it is
  not described as an official game shiny.
- Imported scope: all eleven `Normal Animation` frames and all ten `Special
  Animation` frames. Only the text labels and cyan background are excluded.
- Loop reference: PokéAPI's Bulbasaur resource links the Generation V
  Black/White animated front GIF at
  `PokeAPI/sprites/.../generation-v/black-white/animated/1.gif`. The exact
  audited reference is retained read-only at
  `.audit/gen5_animated_gifs/001.gif` and has 51 frames.
- Transformation: exact `#80FFFF` matte key to transparency; no scaling or
  interpolation. Source frames are aligned on the reference 37×38 canvas.
  The generated loop contains the 200 ms opener, three normal cycles, two idle
  frames, and the wrapped special cycle. Frame 1 is also emitted as the static
  image.
- Timing: reference-authored 200 ms first frame followed by fifty 100 ms frames.
- Filtering: nearest-neighbor at runtime; no interpolation or runtime recolor.
- Generated outputs:
  - `shinyvar_001_variant_1_gen5_static.png`
  - `shinyvar_001_variant_1_gen5_animated.png`

SHA-256 checksums:

- Supplied source: `f660085325f49aca1f3ac4227e7205fc742157d24fc57d071dc38a0d28272833`
- Static output: `d2d31f55dc662b247b7471e14f98fb5e5fb2711a62bd7cccb65fa89549ca5772`
- Animated output: `6c9a112584ed87e7123c2533f82548c0f2f7a30736883bae7e7bec85fbca07d2`
- Visual audit: `58486a7fad0772f7aa2dceee3b76ef52ee443891a243ebcdf03c01a689b1acad`

`tools/build_assets.py` reproduces these files and `ASSET_CHECKSUMS.txt`.

Pokémon artwork remains copyright its respective owners. This private mod
package does not include a ROM and grants no license to the supplied artwork.
