# Changelog

## 0.1.0-alpha.3 — Stable — 2026-08-20

- Raised the mandatory Battle Art floor to `0.1.0-alpha.13`, the first release
  with Shiny Variation Provider API v1.
- Validated the real consumer/provider path for Default and Bulbasaur Variant 1
  static and animated presentation, live option invalidation, load-order retry,
  Shiny System present/absent policy, and exact same-set fallback behavior.
- Produced the first flat/root-only Stable ZIP without installing or promoting
  it to Released.

## 0.1.0-alpha.2 — source candidate — 2026-08-20

- Widened only the optional Gen1 Shiny System ceiling to `<2.0.0`, preserving
  the existing `0.1.0-alpha.3` lower bound and compatibility with released
  Shiny System 1.0.0.
- Preserved the mandatory Battle Art alpha 12 declaration and all variant,
  option, asset, and ownership behavior.
- Kept Stable packaging blocked because Battle Art alpha 12 still lacks Shiny
  Variation Provider API v1.

## 0.1.0-alpha.1 — source candidate

- Added Dex-ordered saved options for all 151 Gen 1 species, all defaulting to
  `DEFAULT`.
- Added Bulbasaur `VARIANT` as the first supplied Gen 5 front mapping.
- Added a static asset and a 51-frame animated atlas built deterministically
  from all eleven supplied normal frames and all ten supplied special frames,
  ordered and timed from the PokeAPI Generation V Bulbasaur GIF.
- Added a fail-closed consumer for the planned Battle Art Shiny Variation
  Provider API v1.
- Kept every non-Gen-5 collection, ROM mode, and non-front surface untouched.
