-- Gen1 Shiny Variations v0.1.0-alpha.3
-- Gen 5 front variants only; Battle Art remains the sole renderer/loader.

local OWNER = "gen1_shiny_variations"
local API_VERSION = 1
local VERSION = "0.1.0-alpha.3"

return function(mod)
  local compile = loadstring or load
  local function loadModule(path)
    local source, reason = mod:read(path)
    if not source then error("cannot read " .. path .. ": " .. tostring(reason), 0) end
    local chunk, compileError = compile(source, "@" .. tostring(mod.path or OWNER) .. "/" .. path)
    if not chunk then error("cannot compile " .. path .. ": " .. tostring(compileError), 0) end
    return chunk()
  end

  local catalog = loadModule("variant_catalog.lua")
  local byOption = {}
  local schema = {}
  local registered = false
  local registeredExports
  local logged = {}

  local function logOnce(message)
    message = tostring(message)
    if logged[message] then return end
    logged[message] = true
    if mod.log and type(mod.log.error) == "function" then
      mod.log:error("Gen1 Shiny Variations: %s", message)
    end
  end

  local function variantById(entry, id)
    for _, variant in ipairs(entry and entry.variants or {}) do
      if variant.id == id then return variant end
    end
    return nil
  end

  for dex, speciesId in ipairs(catalog.order) do
    local entry = assert(catalog.species[speciesId], "missing catalog species " .. speciesId)
    local choices = { { "DEFAULT", "default" } }
    for _, variant in ipairs(entry.variants) do
      choices[#choices + 1] = { variant.label, variant.id }
    end
    schema[#schema + 1] = {
      key = entry.optionKey,
      type = "choice",
      label = string.format("#%03d %s", dex, entry.label),
      default = "default",
      choices = choices,
      help = #entry.variants > 0
        and "Choose the supplied Gen 5 front shiny design for this species."
        or "No alternate Gen 5 front shiny design has been supplied yet.",
    }
    byOption[entry.optionKey] = entry
  end
  mod.options:define(schema)

  local function selectedVariant(entry)
    local saved = mod.options:get(entry.optionKey)
    if saved == nil or saved == "default" then return nil end
    return variantById(entry, saved)
  end

  local function copyMetadata(source)
    if type(source) ~= "table" then return nil end
    local durations = {}
    for index, value in ipairs(source.durations or {}) do durations[index] = value end
    return {
      width = source.width,
      height = source.height,
      columns = source.columns,
      frames = source.frames,
      durations = durations,
    }
  end

  local function resolve(request)
    if type(request) ~= "table" or request.apiVersion ~= API_VERSION then return nil end
    if request.requestedKind ~= "static" and request.requestedKind ~= "animated" then return nil end
    if request.side ~= "front" or request.fileSet ~= "gen5" or request.artSet ~= "gen5" then
      return nil
    end
    local entry = catalog.species[request.species]
    if not entry or tonumber(request.dex) ~= entry.dex then return nil end
    local variant = selectedVariant(entry)
    if not variant then return nil end
    local mapping = variant.assets and variant.assets.gen5
    if type(mapping) ~= "table" then return nil end

    local wantsAnimated = request.requestedKind == "animated"
    local relative = wantsAnimated and mapping.animated or mapping.static
    local kind = wantsAnimated and mapping.animated and "animated" or "static"
    if not relative and wantsAnimated then relative = mapping.static end
    if not relative then return nil end
    return {
      apiVersion = API_VERSION,
      owner = OWNER,
      variantId = variant.id,
      kind = kind,
      path = mod.assets:path(relative),
      metadata = kind == "animated" and copyMetadata(mapping.metadata) or nil,
    }
  end

  local function battleArtExports()
    local handle = type(mod.find) == "function" and mod:find("gen1_battle_art_replacer") or nil
    return handle and handle.exports or nil
  end

  local function ensureRegistered(context)
    local exports = battleArtExports()
    if type(exports) ~= "table"
        or exports.shinyVariationProviderApiVersion ~= API_VERSION
        or type(exports.registerShinyVariationProvider) ~= "function"
        or type(exports.invalidateShinyVariationProvider) ~= "function" then
      registered, registeredExports = false, nil
      logOnce("requires a Battle Art release with Shiny Variation Provider API v1")
      return false
    end
    if registered and exports == registeredExports then return true end
    local ok, accepted, reason = pcall(exports.registerShinyVariationProvider, OWNER, resolve)
    if not ok or not accepted then
      registered, registeredExports = false, nil
      logOnce("provider registration failed at " .. tostring(context) .. ": "
        .. tostring(ok and reason or accepted))
      return false
    end
    registered, registeredExports = true, exports
    return true
  end

  local function invalidate()
    if not ensureRegistered("option change") then return false end
    local ok, accepted = pcall(registeredExports.invalidateShinyVariationProvider, OWNER)
    if not ok or accepted == false then
      registered = false
      logOnce("Battle Art rejected provider invalidation")
      return false
    end
    return true
  end

  mod.exports.version = VERSION
  mod.exports.catalogApiVersion = 1
  mod.exports.catalog = catalog
  mod.exports.resolveShinyVariation = resolve
  mod.exports.ensureRegistered = ensureRegistered
  mod.exports.invalidate = invalidate

  ensureRegistered("initialization")
  if mod.events and type(mod.events.on) == "function" then
    mod.events:on("mods.loaded", function() ensureRegistered("mods.loaded") end)
    mod.events:on("game.ready", function() ensureRegistered("game.ready") end)
    mod.events:on("mod.options_changed", function(payload)
      if payload and payload.mod == mod.id
          and (payload.key == nil or byOption[payload.key]) then invalidate() end
    end)
  end
end
