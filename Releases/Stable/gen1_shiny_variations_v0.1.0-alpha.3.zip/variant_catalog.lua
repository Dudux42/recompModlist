-- Gen1 Shiny Variations catalog v1.
-- This is the sole source of truth for option order and available variants.

local species = {
  "BULBASAUR","IVYSAUR","VENUSAUR","CHARMANDER","CHARMELEON","CHARIZARD",
  "SQUIRTLE","WARTORTLE","BLASTOISE","CATERPIE","METAPOD","BUTTERFREE",
  "WEEDLE","KAKUNA","BEEDRILL","PIDGEY","PIDGEOTTO","PIDGEOT","RATTATA",
  "RATICATE","SPEAROW","FEAROW","EKANS","ARBOK","PIKACHU","RAICHU",
  "SANDSHREW","SANDSLASH","NIDORAN_F","NIDORINA","NIDOQUEEN","NIDORAN_M",
  "NIDORINO","NIDOKING","CLEFAIRY","CLEFABLE","VULPIX","NINETALES",
  "JIGGLYPUFF","WIGGLYTUFF","ZUBAT","GOLBAT","ODDISH","GLOOM","VILEPLUME",
  "PARAS","PARASECT","VENONAT","VENOMOTH","DIGLETT","DUGTRIO","MEOWTH",
  "PERSIAN","PSYDUCK","GOLDUCK","MANKEY","PRIMEAPE","GROWLITHE","ARCANINE",
  "POLIWAG","POLIWHIRL","POLIWRATH","ABRA","KADABRA","ALAKAZAM","MACHOP",
  "MACHOKE","MACHAMP","BELLSPROUT","WEEPINBELL","VICTREEBEL","TENTACOOL",
  "TENTACRUEL","GEODUDE","GRAVELER","GOLEM","PONYTA","RAPIDASH","SLOWPOKE",
  "SLOWBRO","MAGNEMITE","MAGNETON","FARFETCHD","DODUO","DODRIO","SEEL",
  "DEWGONG","GRIMER","MUK","SHELLDER","CLOYSTER","GASTLY","HAUNTER",
  "GENGAR","ONIX","DROWZEE","HYPNO","KRABBY","KINGLER","VOLTORB",
  "ELECTRODE","EXEGGCUTE","EXEGGUTOR","CUBONE","MAROWAK","HITMONLEE",
  "HITMONCHAN","LICKITUNG","KOFFING","WEEZING","RHYHORN","RHYDON","CHANSEY",
  "TANGELA","KANGASKHAN","HORSEA","SEADRA","GOLDEEN","SEAKING","STARYU",
  "STARMIE","MR_MIME","SCYTHER","JYNX","ELECTABUZZ","MAGMAR","PINSIR",
  "TAUROS","MAGIKARP","GYARADOS","LAPRAS","DITTO","EEVEE","VAPOREON",
  "JOLTEON","FLAREON","PORYGON","OMANYTE","OMASTAR","KABUTO","KABUTOPS",
  "AERODACTYL","SNORLAX","ARTICUNO","ZAPDOS","MOLTRES","DRATINI","DRAGONAIR",
  "DRAGONITE","MEWTWO","MEW",
}

local display = {
  NIDORAN_F = "NIDORAN F", NIDORAN_M = "NIDORAN M",
  FARFETCHD = "FARFETCH'D", MR_MIME = "MR. MIME",
}

local catalog = { apiVersion = 1, species = {}, order = species }
for dex, id in ipairs(species) do
  catalog.species[id] = {
    dex = dex,
    species = id,
    label = display[id] or id:gsub("_", " "),
    optionKey = string.format("species_%03d", dex),
    variants = {},
  }
end

catalog.species.BULBASAUR.variants = {
  {
    id = "variant_1",
    label = "VARIANT",
    assets = {
      gen5 = {
        static = "shinyvar_001_variant_1_gen5_static.png",
        animated = "shinyvar_001_variant_1_gen5_animated.png",
        metadata = {
          width = 37,
          height = 38,
          columns = 16,
          frames = 51,
          durations = {
            200,
            100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
            100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
            100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
            100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
            100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
          },
        },
      },
    },
  },
}

return catalog
