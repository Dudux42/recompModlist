# Gen1 Shiny Variations

Stable build: **0.1.0-alpha.4**  
Runtime status: **Battle Art Shiny Variation Provider API v1 integrated**

This cosmetic expansion supplies player-selectable alternate shiny designs to
Gen1 Battle Art Replacer. The initial asset scope is deliberately limited to **Gen 5 front
sprites**. It never changes shiny odds, DVs, shiny state, normal art, back
sprites, icons, followers, overworld art, models, sparkles, or sounds.

## Options

All 151 Gen 1 species have a Dex-ordered saved option and default to `DEFAULT`.
A species receives additional choices only when its corresponding Gen 5 front
asset has been supplied:

- Bulbasaur: `DEFAULT`, `VARIANT`.
- All other species in this build: `DEFAULT` only.

Stable save keys are `species_001` through `species_151`. Alternate save values
use stable IDs such as `variant_1`; labels may later become `VARIANT 1` and
`VARIANT 2` without invalidating saves.

## Bulbasaur asset

Bulbasaur Variant 1 comes from the user-supplied `001 bulbasaur.png`. It contains
eleven normal-animation frames and ten special-animation frames. The
deterministic build keys the exact cyan matte, preserves the supplied pixels,
aligns them to Battle Art's existing 37×38 Bulbasaur canvas, and emits:

- `shinyvar_001_variant_1_gen5_static.png` — first frame;
- `shinyvar_001_variant_1_gen5_animated.png` — 51-frame, 16-column atlas.

The full loop follows the 51-frame Generation V Black/White animated front GIF
linked by [PokéAPI's Bulbasaur resource](https://pokeapi.co/api/v2/pokemon/bulbasaur/):

1. one 200 ms opening frame;
2. three 12-frame normal cycles;
3. two idle frames;
4. one 12-frame special cycle, wrapping from supplied special frame 10 into
   supplied frames 1–9 with two held transition poses.

All frames after the opener use the GIF's 100 ms timing. The special sequence
is therefore part of the periodic authored loop; it is not incorrectly tied to
an attack event that Battle Art does not expose.

## Integration and fallback

The mod registers only through Battle Art Shiny Variation Provider API v1. Its
resolver returns `nil` for Default, non-shiny calls (which Battle Art must never
make), ROM, non-Gen-5 art, non-front sides, unknown species, stale saved values,
or missing mappings. Battle Art remains responsible for image loading, frame
decoding, timing, nearest filtering, caching, invalidation, and every consumer.

Battle Art `0.1.0-alpha.13` supplies this API. The mandatory dependency floor is
therefore exactly `gen1_battle_art_replacer@>=0.1.0-alpha.13 <0.2.0`; alpha 12
is intentionally rejected because it has no provider seam. If the provider is
temporarily unavailable at load time, the mod retries on `mods.loaded` and
`game.ready` and otherwise fails closed to Battle Art's original same-set shiny.

The optional Gen1 Shiny System range now includes released `1.0.0` through
`gen1_shiny_system@>=0.1.0-alpha.3 <2.0.0`. Shiny Variations still never reads,
rolls, or changes shiny state; Battle Art remains the only integration point.

This build targets the current Gen1Recomp launcher/runtime line through
`game_version >=0.2.11 <0.3.0` and remains explicitly Gen-1-only.

## Packaging

The launcher ZIP is flat/root-only and must be imported manually. No build from
this project is installed automatically or promoted to Released.
