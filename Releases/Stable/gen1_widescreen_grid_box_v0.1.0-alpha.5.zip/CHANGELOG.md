# Changelog

## 0.1.0-alpha.5

- Raised the verified launcher range to Gen1Recomp `>=0.2.11 <0.3.0`.
- Raised the required presenter to Gen1 Widescreen UI alpha 15.13, the first
  Widescreen release that claims the same Gen1Recomp 0.2.11 baseline.
- Audited the mod loader, Bill's PC, Boxes, Stats, Summary, sound, TextBox,
  state-stack, and Yellow follower contracts against the installed 0.2.11
  engine archive.
- Replaced the frozen alpha 14.38 provider gate with a current-launcher gate
  that compares Widescreen alpha 15.13 source and ZIP and verifies the live
  engine contracts consumed by Grid Box.
- Repaired the Stable release builder and made package checks derive their
  version from the canonical manifest.

## 0.1.0-alpha.4

- Recovered the editable alpha 3 source from its exact release ZIP.
- Preserved alpha 3's blank held-origin presentation and keyboard-aware hints.
- Bound popup actions to the originally selected record and locked Box
  browsing while a popup is open.
- Added visible disabled reasons for full-party, full-Box, last-party and
  Yellow sleeping-starter popup actions.
- Cancelled transient holds after target or stale-identity validation failure.
- Kept empty-slot selection as a footer hint without opening a TextBox.
- Calculated Summary stats without calling `Stats.ensure`; the native ensure
  path now runs exactly when a boxed record enters the party.
- Included PP Up bonuses in displayed maximum PP.
- Restored native-style success messages and string-buffer fields after
  Withdraw and Deposit.
- Reconstructed transaction, state, provider, Widescreen gate, and package
  audits.

## 0.1.0-alpha.3

- Made the held origin visibly empty and expanded keyboard/Party hints.
- Raised the Widescreen dependency floor to alpha 14.36.
