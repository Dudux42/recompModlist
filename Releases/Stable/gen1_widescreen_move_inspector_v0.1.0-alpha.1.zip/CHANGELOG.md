# Changelog

## 0.1.0-alpha.1 - 2026-08-10

- First release.
- Adds immutable highlighted-move snapshot API v1.
- Registers with Gen1 Widescreen UI Battle Move Inspector API v1.
- Covers live type, PP, base/status/fixed/special power, accuracy, type-chart
  multiplier, STAB, and disabled state without drawing or changing mechanics.
