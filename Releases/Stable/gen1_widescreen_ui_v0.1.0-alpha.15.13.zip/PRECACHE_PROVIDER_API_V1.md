# Pre-cache Provider API v1

Owning presenter: `gen1_widescreen_ui`

This optional API lets enabled mods contribute bounded warm-up tasks to the
`PRE-CACHE` action on the title menu. It shifts selected first-use decoding or
GPU upload work into a visible, cancellable loading screen. It does not promise
higher steady-state frame rates and must not be used to scan whole mod folders,
load every alternate pack, or fully buffer streamed music.

## Exports

- `precacheProviderApiVersion = 1`
- `registerPrecacheProvider(provider)`
- `unregisterPrecacheProvider(owner)`
- `listPrecacheProviderOwners()`

More than one provider may register. Owner IDs are unique and provider tasks
are appended in owner-ID order after Widescreen's built-in tasks. A duplicate
owner is rejected deterministically; replacement requires unregistering first.

## Registration

```lua
local ok, reason = widescreen.registerPrecacheProvider({
  owner = "example_sprite_pack",
  apiVersion = 1,
  snapshot = function(game)
    return {
      schemaVersion = 1,
      tasks = {
        { id = "active_fronts", label = "Active battle fronts" },
        { id = "party_icons", label = "Party menu icons" },
      },
    }
  end,
  actions = {
    warm = function(game, taskId)
      -- Load only the bounded group identified by taskId.
    end,
  },
})
```

Provider snapshots are read once when the loading screen opens. Each task is
copied to an internal `{owner,id,label}` descriptor; providers do not receive
Widescreen task tables. IDs must be unique within that provider and no provider
may publish more than 512 tasks. IDs are limited to 96 characters and labels
to 160 characters.

## Scheduling and failures

Widescreen invokes one `warm(game, taskId)` action per update. A provider should
therefore keep each declared group reasonably small. Errors are caught, shown
with the failing task label, deduplicated in the log, and the remaining tasks
continue. Pressing B cancels before the next task. Once complete or cancelled,
A, B or Start returns to the title.

## Ownership boundary

Widescreen owns the title-menu row, progress UI, focus, cancellation, ordering,
failure isolation and built-in Widescreen/current-area warm-up. The built-in
area pass covers registry-backed overworld tilesets and actor sheets, a bounded
two-hop map/warp neighbourhood, current party and nearby encounter art, plus
the immediate Dramatic Shape mesh ring when that optional mod is active.
Providers own
which of their active assets are useful and how those assets enter their own
caches. Providers must not mutate gameplay state, inventory, saves, settings or
the state stack during `snapshot` or `warm`.

Recommended tasks include the currently selected sprite atlas, current style's
UI textures, custom render-pipeline geometry, or current party/nearby entity
art. Avoid inactive themes, every map-specific variant, all alternate
generations, fully buffered music streams and unbounded directory enumeration.
Asset caches are process-local: running PRE-CACHE again after an asset/mod hot
reload is expected.
