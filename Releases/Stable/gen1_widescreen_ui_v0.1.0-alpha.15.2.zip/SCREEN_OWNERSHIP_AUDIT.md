# Gen1 Widescreen UI screen-ownership audit

Audited against Gen1Recomp 0.1.83 on 2026-08-15.

This audit separates real UI fallbacks from full-screen game content. A ROM
cinematic is not a UI fallback merely because it uses the native logical
surface. Widescreen should replace menus and overlays; it should not silently
replace game sequences or minigames.

## Widescreen-owned reusable UI

- `Menu`, `ListMenu`, and their `QuantityBox` overlay: generic responsive
  presenters cover script menus, shops (including quantity/running price),
  Fly destinations, elevators and other ordinary lists. Specialized screens
  take priority.
- `TextBox` and `ChoiceBox`: responsive dialogue and choice presenters are
  used globally and over every converted background.
- `NamingScreen`: one responsive presenter covers captured-Pokemon nicknames,
  the Name Rater, player/rival names and mod text settings. Native navigation,
  validation and callbacks remain authoritative.
- `BagMenu`, item action `Menu`, `QuantityBox`, Bag messages and the party
  target picker: Widescreen owns presentation, while native inventory and
  item-use callbacks remain authoritative. A pushed target screen explicitly
  takes ownership away from the Bag. Rare Candy retains that Party surface
  through the growth TextBox and stat-gain panel.

## Widescreen-owned specialized UI

Title/Main Menu and Continue; load report; Options; Mod Manager; Oak's New
Game lecture; Start Menu; Party; Summary; move learning; level-up panels;
evolution; Trainer Card; Pokedex list/details/post-capture entry; native PC;
Pokemon Storage Provider; Bag Provider; battle HUD; and dialogue overlays.

## Intentional native game content

The following are not treated as UI fallbacks: `IntroMovie`, `YellowIntro`,
`Credits`, `HallOfFame`, `TradeAnim`, `SlotMachine`, and
`SurfingMinigame`. They are cinematics or interactive game scenes with their
own timing, animation and rendering contracts. Reskinning them is separate
feature work, not a safe generic-menu conversion.

## Remaining dedicated-layout work

`TownMap`, `Diploma`, key-bindings editing and the touch-controls editor still
need purpose-built layouts. Their ordinary nested `Menu`, `ListMenu`,
`TextBox`, and `ChoiceBox` overlays are already protected by the reusable
presenters, but their unique central content is intentionally not stretched or
guessed at by the generic fallback.

## Regression rules

1. A presenter may suppress native drawing only while it can validate the
   complete state range it owns.
2. Unknown opaque destinations win immediately; the underlying Bag, PC,
   Party, or other presenter must yield.
3. Native update/input/callback methods remain the semantic owner.
4. Specialized presenters precede generic `Menu`/`ListMenu` presentation.
5. Cinematics and minigames are never classified as generic UI.
