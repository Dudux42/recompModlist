# HGSS Menu Icons

Current build: **0.1.0-alpha.4**

This focused art mod replaces the menu icon for every Gen 1 Pokemon with its
two-frame 32x32 HeartGold/SoulSilver icon. Shiny Pokemon automatically use
the matching shiny two-frame sheet. Detection honors the shared Gen1 Shiny
System API, native shiny DVs, and the explicit
`mon.shiny` compatibility flag. It changes no follower, battle,
world, encounter, or gameplay behavior.

## Compatibility

- No mandatory dependencies.
- For shiny-aware Gen1 Widescreen UI rows, use `gen1_widescreen_ui`
  **alpha.7.12 or newer**.
- Disable/uninstall `new_icons` and `unique_menu_icons`; these mods own the
  same icon registry and are therefore declared as conflicts.
- The stock Party menu receives a narrowly scoped 32x32 two-frame renderer.
  It activates only while this mod's own descriptor is selected, allowing a
  later icon provider to replace it cleanly.

## Packaging

The release ZIP is intentionally root-only because the current launcher has
shown recursion/import failures with asset subdirectories. It contains 151
151 `icon_NNN.png` and 151 `shiny_icon_NNN.png` files, each a 32x64 RGBA
sheet: frame 1 above frame 2.

The normal artwork was decoded from a user-supplied Pokemon HeartGold ROM.
The shiny variants were palette-derived from shiny reference artwork and then
manually audited/corrected. The ROM is not included. Pokemon and the original
icon artwork belong to Nintendo, Creatures, and Game Freak; this is an
unofficial, non-commercial mod.
