-- HGSS Menu Icons v0.1.0-alpha.4
-- Registers normal and shiny two-frame 32x32 menu icons for Gen 1 species.

local SPECIES = {
  "BULBASAUR", "IVYSAUR", "VENUSAUR", "CHARMANDER", "CHARMELEON",
  "CHARIZARD", "SQUIRTLE", "WARTORTLE", "BLASTOISE", "CATERPIE",
  "METAPOD", "BUTTERFREE", "WEEDLE", "KAKUNA", "BEEDRILL", "PIDGEY",
  "PIDGEOTTO", "PIDGEOT", "RATTATA", "RATICATE", "SPEAROW", "FEAROW",
  "EKANS", "ARBOK", "PIKACHU", "RAICHU", "SANDSHREW", "SANDSLASH",
  "NIDORAN_F", "NIDORINA", "NIDOQUEEN", "NIDORAN_M", "NIDORINO",
  "NIDOKING", "CLEFAIRY", "CLEFABLE", "VULPIX", "NINETALES",
  "JIGGLYPUFF", "WIGGLYTUFF", "ZUBAT", "GOLBAT", "ODDISH", "GLOOM",
  "VILEPLUME", "PARAS", "PARASECT", "VENONAT", "VENOMOTH", "DIGLETT",
  "DUGTRIO", "MEOWTH", "PERSIAN", "PSYDUCK", "GOLDUCK", "MANKEY",
  "PRIMEAPE", "GROWLITHE", "ARCANINE", "POLIWAG", "POLIWHIRL",
  "POLIWRATH", "ABRA", "KADABRA", "ALAKAZAM", "MACHOP", "MACHOKE",
  "MACHAMP", "BELLSPROUT", "WEEPINBELL", "VICTREEBEL", "TENTACOOL",
  "TENTACRUEL", "GEODUDE", "GRAVELER", "GOLEM", "PONYTA", "RAPIDASH",
  "SLOWPOKE", "SLOWBRO", "MAGNEMITE", "MAGNETON", "FARFETCHD", "DODUO",
  "DODRIO", "SEEL", "DEWGONG", "GRIMER", "MUK", "SHELLDER", "CLOYSTER",
  "GASTLY", "HAUNTER", "GENGAR", "ONIX", "DROWZEE", "HYPNO", "KRABBY",
  "KINGLER", "VOLTORB", "ELECTRODE", "EXEGGCUTE", "EXEGGUTOR", "CUBONE",
  "MAROWAK", "HITMONLEE", "HITMONCHAN", "LICKITUNG", "KOFFING", "WEEZING",
  "RHYHORN", "RHYDON", "CHANSEY", "TANGELA", "KANGASKHAN", "HORSEA",
  "SEADRA", "GOLDEEN", "SEAKING", "STARYU", "STARMIE", "MR_MIME",
  "SCYTHER", "JYNX", "ELECTABUZZ", "MAGMAR", "PINSIR", "TAUROS",
  "MAGIKARP", "GYARADOS", "LAPRAS", "DITTO", "EEVEE", "VAPOREON",
  "JOLTEON", "FLAREON", "PORYGON", "OMANYTE", "OMASTAR", "KABUTO",
  "KABUTOPS", "AERODACTYL", "SNORLAX", "ARTICUNO", "ZAPDOS", "MOLTRES",
  "DRATINI", "DRAGONAIR", "DRAGONITE", "MEWTWO", "MEW",
}

return function(mod)
  local paths = {}
  local registered = 0

  for dex, species in ipairs(SPECIES) do
    local rel = string.format("icon_%03d.png", dex)
    local shinyRel = string.format("shiny_icon_%03d.png", dex)
    if mod:read(rel) and mod:read(shinyRel) then
      local path = mod.assets:path(rel)
      local shinyPath = mod.assets:path(shinyRel)
      paths[species] = { normal = path, shiny = shinyPath }
      mod.content.icons:register(species, {
        image = path,
        shinyImage = shinyPath,
        frames = 2,
        hgssMenuIcon = true,
      })
      registered = registered + 1
    else
      mod.log:warn("HGSS MENU ICONS: missing %s for %s", rel, species)
    end
  end

  -- The stock PartyMenu renders 16x16 Game Boy icons. Intercept only this
  -- mod's active descriptors so the HGSS 32x32 sheets retain their detail.
  local ok, err = pcall(function()
    local Assets = require("src.render.Assets")
    local PartyMenu = require("src.ui.PartyMenu")
    local PaletteFX = require("src.render.PaletteFX")
    local Stats = require("src.pokemon.Stats")

    local function isShiny(mon)
      if type(mon) ~= "table" then return false end
      local shinyMod = mod:find("gen1_shiny_system")
      local use = shinyMod and shinyMod.exports
        and shinyMod.exports.shouldUseShinyArt
      if type(use) == "function" then
        local ok, value = pcall(use, mon)
        if ok then return value and true or false end
      end
      -- SHINY_POKEMON persists an explicit flag and deliberately considers it
      -- authoritative before checking Gen 2 DVs. Mirror that contract so a
      -- mod-flagged shiny cannot display a normal menu icon.
      if mon.shiny == true then return true end
      return Stats.isShiny and Stats.isShiny(mon.dvs) and true or false
    end

    PartyMenu._hgssMenuIconPaths = paths
    PartyMenu._hgssMenuIconCache = PartyMenu._hgssMenuIconCache or {}

    if not PartyMenu._hgssMenuIconCacheInvalidation then
      Assets.register(function() PartyMenu._hgssMenuIconCache = {} end)
      PartyMenu._hgssMenuIconCacheInvalidation = true
    end

    if not PartyMenu._hgssMenuIconWrapped then
      PartyMenu._hgssMenuIconOriginalDrawIcon = PartyMenu.drawIcon

      local function loadSheet(path)
        local cache = PartyMenu._hgssMenuIconCache
        local hit = cache[path]
        if hit ~= nil then return hit or nil end

        local imageOk, image = pcall(love.graphics.newImage, Assets.resolve(path))
        if not imageOk or not image then
          cache[path] = false
          return nil
        end
        pcall(function() image:setFilter("nearest", "nearest") end)
        local iw, ih = image:getDimensions()
        if iw ~= 32 or ih ~= 64 then
          cache[path] = false
          return nil
        end
        hit = {
          image = image,
          quads = {
            love.graphics.newQuad(0, 0, 32, 32, iw, ih),
            love.graphics.newQuad(0, 32, 32, 32, iw, ih),
          },
        }
        cache[path] = hit
        return hit
      end

      function PartyMenu.drawIcon(game, mon, x, y, selected, counter, forceAlt)
        local species = mon and mon.species
        local wanted = species and PartyMenu._hgssMenuIconPaths[species]
        local icons = game and game.data and game.data.icons
        local entry = icons and icons.bySpecies and icons.bySpecies[species]
        if wanted and type(entry) == "table" and entry.image == wanted.normal then
          local selectedPath = isShiny(mon) and wanted.shiny or wanted.normal
          local sheet = loadSheet(selectedPath)
          if sheet then
            local alternate = forceAlt == true
            if selected then
              local maxHP = mon.stats and mon.stats.hp or 1
              local hp = mon.hp or maxHP
              local pixels = math.floor(hp * 48 / math.max(1, maxHP))
              local speed = pixels >= 27 and 5 or pixels >= 10 and 16 or 32
              alternate = math.floor((counter or 0) / speed) % 2 == 1
            end
            love.graphics.setColor(1, 1, 1, 1)
            love.graphics.draw(sheet.image,
              sheet.quads[alternate and 2 or 1], x, y, 0, 0.5, 0.5)
            PaletteFX.markTrueColor(x, y, 16, 16)
            return true
          end
        end
        return PartyMenu._hgssMenuIconOriginalDrawIcon(
          game, mon, x, y, selected, counter, forceAlt)
      end

      PartyMenu._hgssMenuIconWrapped = true
    end
  end)

  if not ok then
    mod.log:warn("HGSS MENU ICONS: stock PartyMenu patch failed: %s", tostring(err))
  end
  mod.log:info("HGSS MENU ICONS: registered %d/151 animated normal/shiny icon pairs", registered)
end
