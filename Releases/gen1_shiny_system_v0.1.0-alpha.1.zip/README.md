# Gen1 Shiny System

Current build: **0.1.0-alpha.1**

A focused shiny implementation for the Invoker/Codex mod compilation. It owns
shiny encounter rolls, persistent shiny state, battle recoloring and sparkle
effects. Presentation is delegated directly to our existing mods:

- Gen1 Widescreen UI selects shiny portraits and menu-icon descriptors.
- HGSS Menu Icons selects the audited two-frame shiny icon sheets.
- HGSS Simple Follower selects the ROM-derived shiny overworld sheets and
  draws lightweight looping sparkles.

The original `SHINY_POKEMON` mod must be disabled because both mods wrap wild
Pokemon creation and battle presentation.

## Options

Pause **OPTIONS -> SHINY POKEMON -> OPEN**:

- **SHINY POKEMON** — master enable.
- **SHINY RATE** — OFF, 1/8192, 1/4096, 1/1024, 1/512, 1/100, 1/10 or 100%.
- **SHINY COLORS** — enables shiny battle art, menu icons and followers.
- **SHINY INTRO** — enables battle/follower sparkle effects and battle SFX.
- **DEBUG OW** — diagnostic logging; normally leave this disabled.

Existing natural Gen 2 shiny DVs and an explicit `mon.shiny` flag are both
recognized. Newly rolled shinies receive valid Gen 2 shiny DVs and retain the
explicit flag when caught.

## Attribution

The official Crystal palette table is reused from masterwebx's MIT-licensed
Shiny Pokemon mod. See `THIRD_PARTY_LICENSE.txt`. All other integration code in
this package was written specifically for this compilation.
