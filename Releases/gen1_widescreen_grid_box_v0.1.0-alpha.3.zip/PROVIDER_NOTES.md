# Provider integration notes

Widescreen Grid Box registers one owner with Pokemon Storage Provider API v1:

- owner: `gen1_widescreen_grid_box`
- match marker: `state.isGridBox == true`
- schema: `schemaVersion = 1`
- actions: up/down/left/right, previousBox/nextBox, select/back,
  selectCell/selectPartySlot/selectPopup/selectPartyButton

The state calls Widescreen's public `updatePokemonStorageProviderInput` from
its own `update` method. It never patches Widescreen classes or tables.

Snapshots contain fresh semantic copies only. They do not expose `game`,
`save`, `boxes`, or mutable storage records. `identityToken` values are stable
for the state lifetime. Widescreen resolves icons and large 2D portraits from
the semantic `presentation` copies and forces icon frame 1.

Provider registration is verified before `src.ui.BoxMenu.new` is decorated.
If API v1 is missing or another owner controls it, native Bill's PC is returned
unchanged. If the provider registration changes while a Grid Box is open, the
state clears its transient hold and closes without storage mutation.

Canonical Widescreen alpha 14.33 fixes the held-descriptor validation defect
recorded in `WIDESCREEN_STORAGE_HELD_VALIDATION_FIX_REQUEST.md`. Canonical
Widescreen alpha 14.36 fixes the held-icon animation speed (was reusing the
native Party menu's low-HP-alarm blink cadence), the PARTY button's
header/bottom-navigation contradiction, and the active-target "black box"
fill, all recorded in
`WIDESCREEN_STORAGE_HELD_ANIMATION_SPEED_AND_PARTY_BUTTON_REQUEST.md`; this
mod's dependency floor therefore now starts at alpha 14.36.
