# Widescreen Grid Box

Current release: **0.1.0-alpha.3**

Widescreen Grid Box replaces Bill's list-based Pokemon storage workflows with
a semantic 5×4 Grid Box, a six-slot Party drawer, and deferred atomic Move
Pokemon transactions. Gen1 Widescreen UI owns the complete 640×360
presentation; this mod performs no drawing.

## Requirements

- Gen1Recomp `>=0.1.83 <0.2.0`, API 2
- Gen 1 only (`games: ["gen1"]`)
- Gen1 Widescreen UI Pokemon Storage Provider API v1
- Conflict: `advanced_box_system`

The manifest requires
`gen1_widescreen_ui >=0.1.0-alpha.14.36 <0.2.0`. Alpha 14.33 resolves the held
Pokemon validation defect documented in
`WIDESCREEN_STORAGE_HELD_VALIDATION_FIX_REQUEST.md`. Alpha 14.36 resolves the
held-icon animation speed, PARTY button placement, and active-target fill
defects documented in
`WIDESCREEN_STORAGE_HELD_ANIMATION_SPEED_AND_PARTY_BUTTON_REQUEST.md`.

## Bill's PC

The root order is:

1. WITHDRAW POKEMON
2. DEPOSIT POKEMON
3. MOVE POKEMON
4. CHANGE BOX
5. PRINT BOX (Yellow only)
6. SEE YA!

Release is absent. Change Box and Yellow Print Box retain the engine's own
callbacks. Browsing another grid never changes `save.currentBox`.

## Storage rules

- All twelve native 20-Pokemon boxes remain dense arrays.
- Pickup never mutates the save; a validated drop commits once.
- Occupied targets swap. Only the first empty dense tail is a distinct empty
  destination.
- A full destination accepts swaps but not transfers.
- Party size remains 1–6 and every box remains 0–20.
- Box Pokemon receive `Stats.ensure` only when they actually enter the party.
- Pokemon leaving the party pass the Yellow starter guard and apply the native
  `DEPOSITED` happiness event exactly once after commit.
- Provider loss, replacement, cancellation, or validation failure discards
  the transient hold without removing a Pokemon.
- Box detail and Summary preparation calculate missing stats on semantic
  copies; highlighting never writes `mon.stats` into a boxed record.

## Controls

- A: select, open an action popup, pick up, or place
- B: back; while holding, cancel
- L/R (gamepad) or Q/E (keyboard): browse boxes without changing the active
  capture Box
- Move mode: move down from the bottom grid row to PARTY, then A to open the
  six-slot drawer; this is also reachable while holding a Pokemon

Keyboard and pointer/touch input are routed by Widescreen to the same named
provider actions. The on-screen hint text always names both the gamepad and
keyboard bindings (`L/R OR Q/E: BOX`) so keyboard players are not misled by a
gamepad-only label.

While a Pokemon is held, its origin slot renders blank (not just re-marked)
so it is visually obvious which Pokemon has been physically picked up.

## Development tests

From the project root, using the official 0.1.83 `lua51.dll` runner:

```powershell
python gen1_widescreen_grid_box/tests/run_lua51_test.py storage_transaction_test.lua
python gen1_widescreen_grid_box/tests/run_lua51_test.py grid_box_state_test.lua
python gen1_widescreen_grid_box/tests/run_lua51_test.py provider_integration_test.lua
```

`widescreen_provider_gate_test.py` verifies the canonical alpha 14.33 held
Pokemon validator, along with the alpha 14.36 held-icon animation speed,
PARTY button placement, and active-target fill fixes, before packaging.

The focused 640x360 Move-mode audit is retained at
`tests/audits/provider_storage_move_held_alpha_14_33.png`. Exact Lua 5.1 and
provider-renderer checks pass; final Red, Blue, and Yellow launcher testing
with the user's complete mod stack remains a manual acceptance step.

## Ownership and provenance

This implementation was written from Gen1Recomp's public storage contracts,
the public Widescreen provider contract, and the project handoff. Advanced Box
System was treated only as a behavioral reference; none of its source,
documentation, or assets is included.

Licensed under the included MIT License. No ROM or ROM cache is included.
