-- Widescreen Grid Box
-- Version 0.1.0-alpha.3
-- Bill's PC storage semantics for Widescreen Pokemon Storage Provider API v1.

local OWNER = "gen1_widescreen_grid_box"
local API_VERSION = 1
local PATCH_KEY = "__gen1_widescreen_grid_box_dispatch_v1"

return function(mod)
  local compile = loadstring or load
  local function loadModule(path)
    local source, readError = mod:read(path)
    if not source then error("cannot read " .. path .. ": " .. tostring(readError), 0) end
    local chunk, compileError = compile(source,
      "@" .. tostring(mod.path or OWNER) .. "/" .. path)
    if not chunk then error("cannot compile " .. path .. ": " .. tostring(compileError), 0) end
    return chunk()
  end

  local Transaction = loadModule("storage_transaction.lua")
  local GridBoxState = loadModule("grid_box_state.lua")
  local registered = false
  local providerGeneration = 0
  local installed = false

  local function logOnce(message)
    message = tostring(message)
    mod.__gridBoxLogs = mod.__gridBoxLogs or {}
    if mod.__gridBoxLogs[message] then return end
    mod.__gridBoxLogs[message] = true
    if mod.log then mod.log:error("Widescreen Grid Box: %s", message) end
  end

  local function widescreenExports()
    local widescreen = type(mod.find) == "function" and mod:find("gen1_widescreen_ui") or nil
    return widescreen and widescreen.exports or nil
  end

  local function ensureProvider()
    local exports = widescreenExports()
    if type(exports) ~= "table"
        or exports.pokemonStorageProviderApiVersion ~= API_VERSION
        or type(exports.registerPokemonStorageProvider) ~= "function"
        or type(exports.updatePokemonStorageProviderInput) ~= "function" then
      registered = false
      logOnce("requires Gen1 Widescreen UI Pokemon Storage Provider API v1")
      return false
    end
    if registered and type(exports.activePokemonStorageProviderOwner) == "function" then
      local ok, owner = pcall(exports.activePokemonStorageProviderOwner)
      if ok and owner == OWNER then return true end
      registered = false
    end
    local ok, reason = exports.registerPokemonStorageProvider({
      owner = OWNER, apiVersion = API_VERSION,
      match = function(state)
        return type(state) == "table" and state.isGridBox == true
      end,
      snapshot = function(_, state) return state:immutableSnapshot() end,
      actions = GridBoxState.Actions,
    })
    if not ok then
      registered = false
      logOnce("provider registration failed: " .. tostring(reason))
      return false
    end
    registered = true
    providerGeneration = providerGeneration + 1
    return true
  end

  local function dependencies()
    local stateGeneration = providerGeneration
    local Stats = require("src.pokemon.Stats")
    local Follower = require("src.world.PikachuFollower")
    local Screens = require("src.ui.Screens")
    local Sound = require("src.core.Sound")
    local TextBox = require("src.render.TextBox")
    return {
      Transaction = Transaction, Stats = Stats, Follower = Follower,
      pushSummary = function(game, mon) return Screens.push(game, "SummaryMenu", mon) end,
      playCry = function(game, mon)
        if mon and mon.species then Sound.playCry(game.data, mon.species) end
      end,
      pushMessage = function(game, text) game.stack:push(TextBox.new(game, text)) end,
      updateInput = function(game, state, dt)
        if not ensureProvider() then return nil, "provider unavailable" end
        if stateGeneration ~= providerGeneration then
          return nil, "provider registration changed"
        end
        local exports = widescreenExports()
        return exports.updatePokemonStorageProviderInput(game, state, dt)
      end,
      logError = function(reason)
        logOnce("provider input dispatch failed: " .. tostring(reason))
      end,
    }
  end

  local function pushGrid(game, mode)
    if not ensureProvider() then return false end
    require("src.pokemon.Boxes").ensure(game.save)
    local state = GridBoxState.new(game, mode, dependencies())
    game.stack:push(state)
    return true
  end

  local function nativeItemByLabel(items, needle)
    needle = needle:upper()
    for _, item in ipairs(items or {}) do
      local label = tostring(item.label or ""):upper()
      if label:find(needle, 1, true) then return item end
    end
    return nil
  end

  local function decorateRoot(game, nativeRoot)
    if not ensureProvider() then return nativeRoot end
    local Strings = require("src.core.Strings")
    local nativeItems = nativeRoot.items or {}
    local change = nativeItemByLabel(nativeItems, "CHANGE BOX")
    local printBox = nativeItemByLabel(nativeItems, "PRINT BOX")
    local seeYa = nativeItemByLabel(nativeItems, "SEE YA") or nativeItems[#nativeItems]
    if not change or not seeYa then
      logOnce("native BoxMenu rows changed; leaving Bill's PC unmodified")
      return nativeRoot
    end
    local items = {
      { label = Strings("WITHDRAW <PK><MN>"), keepOpen = true,
        onSelect = function() pushGrid(game, "withdraw") end },
      { label = Strings("DEPOSIT <PK><MN>"), keepOpen = true,
        onSelect = function() pushGrid(game, "deposit") end },
      { label = Strings("MOVE <PK><MN>"), keepOpen = true,
        onSelect = function() pushGrid(game, "move") end },
      change,
    }
    if printBox then items[#items + 1] = printBox end
    items[#items + 1] = seeYa
    nativeRoot.items = items
    nativeRoot.index = math.max(1, math.min(tonumber(nativeRoot.index) or 1, #items))
    if type(nativeRoot.clampScroll) == "function" then nativeRoot:clampScroll() end
    return nativeRoot
  end

  local function install(game)
    if not game or not ensureProvider() then return false end
    local ok, BoxMenu = pcall(require, "src.ui.BoxMenu")
    if not ok or type(BoxMenu) ~= "table" or type(BoxMenu.new) ~= "function" then
      logOnce("src.ui.BoxMenu is unavailable")
      return false
    end
    local dispatch = rawget(_G, PATCH_KEY)
    if not dispatch then
      dispatch = { baseNew = BoxMenu.new }
      rawset(_G, PATCH_KEY, dispatch)
      BoxMenu.new = function(currentGame, ...)
        local root = dispatch.baseNew(currentGame, ...)
        if type(dispatch.decorate) == "function" then
          return dispatch.decorate(currentGame, root)
        end
        return root
      end
    end
    dispatch.decorate = function(currentGame, root)
      return decorateRoot(currentGame, root)
    end
    installed = true
    return true
  end

  mod.exports.apiVersion = 1
  mod.exports.transaction = Transaction
  mod.exports.state = GridBoxState
  mod.exports.actions = GridBoxState.Actions
  mod.exports.ensureProvider = ensureProvider
  mod.exports.open = function(game, mode) return pushGrid(game, mode) end

  if mod.events and type(mod.events.on) == "function" then
    mod.events:on("game.ready", function(event)
      if install(event and event.game) and mod.log then
        mod.log:info("Widescreen Grid Box alpha 3 installed")
      end
    end)
    mod.events:on("mods.loaded", function()
      ensureProvider()
      if installed and mod.game then install(mod.game) end
    end)
  end
  ensureProvider()
end
