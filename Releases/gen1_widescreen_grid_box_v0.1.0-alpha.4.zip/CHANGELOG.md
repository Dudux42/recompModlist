# Changelog

## 0.1.0-alpha.4

- Recovered the editable alpha 3 source from its exact release ZIP.
- Preserved alpha 3's blank held-origin presentation and keyboard-aware hints.
- Bound popup actions to the originally selected record and locked Box
  browsing while a popup is open.
- Added visible disabled reasons for full-party, full-Box, last-party and
  Yellow sleeping-starter popup actions.
- Cancelled transient holds after target or stale-identity validation failure.
- Kept empty-slot selection as a footer hint without opening a TextBox.
- Calculated Summary stats without calling `Stats.ensure`; the native ensure
  path now runs exactly when a boxed record enters the party.
- Included PP Up bonuses in displayed maximum PP.
- Restored native-style success messages and string-buffer fields after
  Withdraw and Deposit.
- Reconstructed transaction, state, provider, Widescreen gate, and package
  audits.

## 0.1.0-alpha.3

- Made the held origin visibly empty and expanded keyboard/Party hints.
- Raised the Widescreen dependency floor to alpha 14.36.
