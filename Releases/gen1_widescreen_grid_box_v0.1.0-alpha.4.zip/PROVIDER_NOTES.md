# Provider integration notes

Widescreen Grid Box registers one owner with Pokemon Storage Provider API v1:

- owner: `gen1_widescreen_grid_box`
- match marker: `state.isGridBox == true`
- schema: `schemaVersion = 1`
- actions: up/down/left/right, previousBox/nextBox, select/back,
  selectCell/selectPartySlot/selectPopup/selectPartyButton

The state calls Widescreen's public `updatePokemonStorageProviderInput` from
its own `update` method. It never patches Widescreen classes or tables.

Snapshots contain fresh semantic copies only. They do not expose `game`,
`save`, `boxes`, or mutable storage records. `identityToken` values are stable
for the state lifetime. Widescreen resolves icons and large 2D portraits from
the semantic `presentation` copies and forces icon frame 1.

Provider registration is verified before `src.ui.BoxMenu.new` is decorated.
If API v1 is missing or another owner controls it, native Bill's PC is returned
unchanged. If the provider registration changes while a Grid Box is open, the
state clears its transient hold and closes without storage mutation.

The dependency floor starts at Widescreen alpha 14.36. The verified alpha
14.38 source and ZIP retain the completed held-descriptor validation,
presenter-owned one-second held-icon cadence, bottom-left PARTY button,
ACTIVE badge, target-state patterns, disabled-reason footer, and explicit
`selectPartyButton` pointer routing. The provider locks shoulder Box browsing
while a popup owns a record and commits through the popup's original identity
descriptor; Widescreen never infers or executes a transaction.
