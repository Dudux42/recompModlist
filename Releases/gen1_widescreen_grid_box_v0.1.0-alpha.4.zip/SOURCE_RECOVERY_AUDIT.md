# Alpha 3 source recovery audit

Date: **2026-08-15**

The editable recovery baseline was extracted from
`Releases/gen1_widescreen_grid_box_v0.1.0-alpha.3.zip`. Before any alpha 4
edit, all seven extracted entries matched their ZIP bytes by SHA-256:

| Entry | SHA-256 |
|---|---|
| `manifest.json` | `0404f50a03d80f0a12de41ca87d4186283d134aa900eb0be984f88352b403c67` |
| `main.lua` | `60b03d596e1e388f97cc4b32c8aa8f5842b4dc6a3307635010ca9076cba1dcb1` |
| `storage_transaction.lua` | `2eefe2e2262fdf8ce247bef0398bc2896b3c38727105319ba6a2a91198914ce0` |
| `grid_box_state.lua` | `001b996792cb352393b99075950d91adc4e977a9cc6ebfe0eba953102bf19860` |
| `README.md` | `51e4912ecddba75303df935e4a5abd7ce6c4d85bb9edee37a2ba5fc157046c16` |
| `PROVIDER_NOTES.md` | `46e96c6db1905e1552e6876330c40a9b4e96cad3884b3d1f0a4a0443e0b82f13` |
| `LICENSE` | `ea45ebe519ec104d3c3790affc1e9b143d4ca6a9fcc3d1d4845116bd087fe4ea` |

Alpha 3 was therefore treated as the recovered donor, never modified in its
release ZIP, and superseded by a newly versioned alpha 4 source/release.
