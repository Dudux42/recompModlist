-- Widescreen Grid Box semantic state.
-- Widescreen UI owns every draw pass and maps input to these named actions.

local State = {}
State.__index = State

local function clamp(value, low, high)
  value = tonumber(value) or low
  return math.max(low, math.min(high, math.floor(value)))
end

local function plainCopy(value, depth, seen)
  local kind = type(value)
  if kind ~= "table" then
    if kind == "string" or kind == "number" or kind == "boolean" then return value end
    return nil
  end
  depth = depth or 0
  if depth >= 5 then return {} end
  seen = seen or {}
  if seen[value] then return nil end
  seen[value] = true
  local out = {}
  for key, child in pairs(value) do
    if type(key) == "string" or type(key) == "number" then
      local copy = plainCopy(child, depth + 1, seen)
      if copy ~= nil then out[key] = copy end
    end
  end
  seen[value] = nil
  return out
end

local function sequenceCopy(source)
  local out = {}
  for i, value in ipairs(source or {}) do out[i] = value end
  return out
end

local function boxAt(self, index)
  return self.game.save.boxes[index]
end

local function containerAt(self, region, box)
  if region == "party" then return self.game.save.party end
  return boxAt(self, box or self.viewedBox)
end

local function speciesDef(self, mon)
  return self.game.data and self.game.data.pokemon
    and self.game.data.pokemon[mon and mon.species] or nil
end

local function displayName(self, mon)
  local def = speciesDef(self, mon)
  return tostring(mon and mon.nickname or def and def.name or mon and mon.species or "POKEMON")
end

local function tokenFor(self, mon)
  if type(mon) ~= "table" then return nil end
  local token = self.identityTokens[mon]
  if not token then
    self.nextIdentityToken = self.nextIdentityToken + 1
    token = "grid-box:" .. tostring(self.nextIdentityToken)
    self.identityTokens[mon] = token
  end
  return token
end

local function presentationCopy(mon)
  return plainCopy(mon) or {}
end

local function descriptorFor(self, mon, targetState, enabled, reason)
  if type(mon) ~= "table" then
    return { empty = true, state = targetState or "empty",
      enabled = enabled ~= false, disabledReason = reason }
  end
  return {
    identityToken = tokenFor(self, mon),
    speciesId = tostring(mon.species or "UNKNOWN"),
    name = displayName(self, mon),
    shiny = mon.shiny == true,
    presentation = presentationCopy(mon),
    state = targetState or "occupied",
    enabled = enabled ~= false,
    disabledReason = reason,
  }
end

local function calculatedStats(self, mon)
  if type(mon.stats) == "table" then return plainCopy(mon.stats) end
  local def = speciesDef(self, mon)
  if def and type(self.deps.Stats) == "table" and type(self.deps.Stats.calc) == "function" then
    local ok, stats = pcall(self.deps.Stats.calc, def, mon.level or 1,
      mon.dvs or {}, mon.statExp)
    if ok and type(stats) == "table" then return plainCopy(stats) end
  end
  local base = def and def.baseStats or {}
  return {
    hp = tonumber(mon.hp) or tonumber(base.hp) or 1,
    attack = tonumber(base.attack) or 0,
    defense = tonumber(base.defense) or 0,
    speed = tonumber(base.speed) or 0,
    special = tonumber(base.special) or 0,
  }
end

local function detailFor(self, mon)
  if type(mon) ~= "table" then return nil end
  local def = speciesDef(self, mon) or {}
  local stats = calculatedStats(self, mon)
  local maxHp = math.max(1, math.floor(tonumber(stats.hp) or tonumber(mon.hp) or 1))
  local moves = {}
  for i = 1, math.min(4, #(mon.moves or {})) do
    local record = mon.moves[i]
    local id = type(record) == "table" and record.id or record
    local move = self.game.data and self.game.data.moves and self.game.data.moves[id] or {}
    local basePp = math.max(0, math.floor(tonumber(move.pp) or 0))
    local ppUps = math.max(0, math.floor(tonumber(
      type(record) == "table" and record.ppUps) or 0))
    moves[#moves + 1] = {
      name = tostring(move.name or id or "EMPTY"),
      pp = math.max(0, math.floor(tonumber(type(record) == "table" and record.pp) or 0)),
      maxPp = basePp + ppUps * math.floor(basePp / 5),
      type = move.type and tostring(move.type) or nil,
    }
  end
  local types = {}
  for i = 1, math.min(2, #(def.types or {})) do types[i] = tostring(def.types[i]) end
  if #types == 0 then types[1] = "NORMAL" end
  local speciesName = tostring(def.name or mon.species or "UNKNOWN")
  local name = displayName(self, mon)
  local nicknamed = mon.nickname ~= nil and tostring(mon.nickname) ~= speciesName
  return {
    identityToken = tokenFor(self, mon), speciesId = tostring(mon.species or "UNKNOWN"),
    name = name, speciesName = speciesName, nicknamed = nicknamed,
    gender = mon.gender and tostring(mon.gender) or nil,
    level = math.max(1, math.floor(tonumber(mon.level) or 1)),
    hp = clamp(tonumber(mon.hp) or maxHp, 0, maxHp), maxHp = maxHp,
    status = mon.status and tostring(mon.status) or nil,
    stats = {
      hp = maxHp,
      attack = math.max(0, math.floor(tonumber(stats.attack) or 0)),
      defense = math.max(0, math.floor(tonumber(stats.defense) or 0)),
      speed = math.max(0, math.floor(tonumber(stats.speed) or 0)),
      special = math.max(0, math.floor(tonumber(stats.special) or 0)),
    },
    types = types, moves = moves, shiny = mon.shiny == true,
    presentation = presentationCopy(mon),
  }
end

local function currentMon(self)
  if self.region == "party" then return self.game.save.party[self.partyIndex] end
  if self.region == "grid" then return boxAt(self, self.viewedBox)[self.gridIndex] end
  if self.popup then return self.popup.mon end
  return self.held and self.held.mon or nil
end

local function setFooter(self, text, showMessage)
  self.footer = text and tostring(text) or nil
  if showMessage and self.footer and type(self.deps.pushMessage) == "function" then
    self.deps.pushMessage(self.game, self.footer)
  end
  return false, self.footer
end

local function popState(self)
  self.held = nil
  if self.game.stack and type(self.game.stack.top) == "function"
      and self.game.stack:top() == self and type(self.game.stack.pop) == "function" then
    self.game.stack:pop()
  end
  return true
end

local function canLeaveParty(self, mon, replacementEntersParty)
  if #self.game.save.party <= 1 and not replacementEntersParty then
    return nil, "You cannot deposit the last Pokemon."
  end
  local Follower = self.deps.Follower
  if type(Follower) == "table" and type(Follower.isFollowingDisabled) == "function"
      and type(Follower.isStarterPikachu) == "function"
      and Follower.isFollowingDisabled(self.game.overworld)
      and Follower.isStarterPikachu(self.game.save, mon) then
    return nil, "There isn't any response..."
  end
  return true
end

local function prepareEnterParty(self, mon)
  local copy = plainCopy(mon) or {}
  local def = speciesDef(self, mon)
  if self.deps.Stats and type(self.deps.Stats.ensure) == "function" then
    self.deps.Stats.ensure(def, copy)
  end
  -- Native Stats.ensure is a no-op for already-shaped records. Preserve the
  -- actual saved stat table in that case instead of replacing it with the
  -- presentation copy made above.
  if type(mon.stats) == "table" then return {} end
  return { stats = copy.stats, hp = copy.hp }
end

local function afterLeaveParty(self, mon)
  local Follower = self.deps.Follower
  if type(Follower) == "table" and type(Follower.modifyHappiness) == "function" then
    Follower.modifyHappiness(self.game.save, "DEPOSITED", mon)
  end
end

local function transactionContext(self)
  return {
    canLeaveParty = function(mon, replacement)
      return canLeaveParty(self, mon, replacement)
    end,
    prepareEnterParty = function(mon) return prepareEnterParty(self, mon) end,
    afterLeaveParty = function(mon) return afterLeaveParty(self, mon) end,
  }
end

local function locationFor(self, region, index)
  if region == "party" then
    return self.Transaction.describe(self.game.save, "party", nil, index)
  end
  return self.Transaction.describe(self.game.save, "box", self.viewedBox, index)
end

local function targetReason(self, region, index)
  if not self.held then return true end
  local origin = self.held.origin
  local destination = locationFor(self, region, index)
  if origin.kind == destination.kind
      and (origin.kind == "party" or origin.box == destination.box)
      and origin.index == destination.index then
    return nil, "This is the held Pokemon's original slot."
  end
  local target = containerAt(self, region, self.viewedBox)
  if index > #target + 1 then return nil, "Use the first empty tail slot." end
  if not target[index] and #target >= (region == "party" and 6 or 20) then
    return nil, region == "party" and "The party is full." or "This Box is full."
  end
  if origin.kind == "party" and region == "box" then
    return canLeaveParty(self, self.held.mon, target[index] ~= nil)
  end
  if origin.kind == "box" and region == "party" and target[index] then
    return canLeaveParty(self, target[index], true)
  end
  if origin.kind == "party" and region == "box" and not target[index]
      and #self.game.save.party <= 1 then
    return nil, "You cannot deposit the last Pokemon."
  end
  return true
end

local function commitHeld(self, region, index)
  local ok, reason = targetReason(self, region, index)
  if not ok then
    self.held = nil
    return setFooter(self, reason, true)
  end
  local destination = locationFor(self, region, index)
  ok, reason = self.Transaction.commit(self.game.save, self.held.origin,
    destination, transactionContext(self))
  if not ok then
    self.held = nil
    return setFooter(self, reason, true)
  end
  local moved = self.held.mon
  self.held = nil
  self.footer = reason == "swap" and "Pokemon switched." or "Pokemon moved."
  if type(self.deps.playCry) == "function" then self.deps.playCry(self.game, moved) end
  return true, reason
end

local function beginHold(self, region, index)
  local mon = containerAt(self, region, self.viewedBox)[index]
  if not mon then return setFooter(self, "That slot is empty.") end
  self.held = { mon = mon, origin = locationFor(self, region, index),
    presentation = presentationCopy(mon) }
  self.footer = "Choose a destination. B cancels."
  return true
end

local function openPopup(self, mode, region, index)
  local mon = containerAt(self, region, self.viewedBox)[index]
  if not mon then return setFooter(self, "That slot is empty.") end
  local action = mode == "withdraw" and "WITHDRAW" or "DEPOSIT"
  local enabled, disabledReason = true, nil
  if mode == "withdraw" and #self.game.save.party >= 6 then
    enabled, disabledReason = false, "The party is full."
  elseif mode == "deposit" and #boxAt(self, self.viewedBox) >= 20 then
    enabled, disabledReason = false, "This Box is full."
  elseif mode == "deposit" then
    enabled, disabledReason = canLeaveParty(self, mon, false)
    enabled = enabled == true
  end
  self.popup = { mode = mode, region = region, index = index, mon = mon,
    origin = locationFor(self, region, index),
    selectedIndex = 1, rows = {
      { id = mode, label = action, enabled = enabled,
        disabledReason = disabledReason },
      { id = "stats", label = "STATS", enabled = true },
      { id = "exit", label = "EXIT", enabled = true },
    } }
  self.region = "popup"
  return true
end

local function safeSummaryCopy(self, mon)
  local copy = plainCopy(mon) or {}
  if type(copy.stats) ~= "table" then
    copy.stats = calculatedStats(self, mon)
    local maximum = math.max(1, math.floor(tonumber(copy.stats.hp) or 1))
    copy.hp = clamp(tonumber(copy.hp) or maximum, 0, maximum)
  end
  return copy
end

local function openSummary(self, mon)
  if type(self.deps.pushSummary) ~= "function" then
    return setFooter(self, "Summary screen is unavailable.")
  end
  self.deps.pushSummary(self.game, safeSummaryCopy(self, mon))
  return true
end

local function executePopup(self)
  local popup = self.popup
  if not popup then return false end
  local row = popup.rows[popup.selectedIndex]
  if not row or row.enabled == false then
    return setFooter(self, row and row.disabledReason, true)
  end
  if row.id == "exit" then self.popup = nil; self.region = popup.region; return true end
  if row.id == "stats" then return openSummary(self, popup.mon) end
  local origin = popup.origin
  local destination
  if row.id == "withdraw" then
    destination = self.Transaction.describe(self.game.save, "party", nil,
      #self.game.save.party + 1)
  else
    destination = self.Transaction.describe(self.game.save, "box", self.viewedBox,
      #boxAt(self, self.viewedBox) + 1)
  end
  local ok, reason = self.Transaction.commit(self.game.save, origin, destination,
    transactionContext(self))
  if not ok then
    self.popup = nil
    self.region = popup.region
    return setFooter(self, reason, true)
  end
  self.popup = nil
  self.region = popup.region
  if popup.region == "grid" then
    self.gridIndex = clamp(self.gridIndex, 1, math.max(1, #boxAt(self, self.viewedBox)))
  else
    self.partyIndex = clamp(self.partyIndex, 1, math.max(1, #self.game.save.party))
  end
  self.footer = row.id == "withdraw" and "Pokemon withdrawn." or "Pokemon deposited."
  if type(self.deps.playCry) == "function" then self.deps.playCry(self.game, popup.mon) end
  self.game.stringBuffer = displayName(self, popup.mon)
  if row.id == "deposit" then self.game.boxNumString = tostring(self.viewedBox) end
  if type(self.deps.pushMessage) == "function" then
    local text = row.id == "withdraw"
      and displayName(self, popup.mon) .. " was taken out."
      or displayName(self, popup.mon) .. " was stored in Box "
        .. tostring(self.viewedBox) .. "."
    self.deps.pushMessage(self.game, text)
  end
  return true
end

function State.new(game, mode, dependencies)
  assert(type(game) == "table" and type(game.save) == "table", "game save required")
  assert(mode == "withdraw" or mode == "deposit" or mode == "move", "invalid mode")
  local self = setmetatable({
    game = game, mode = mode, deps = dependencies or {},
    Transaction = assert(dependencies and dependencies.Transaction, "Transaction required"),
    isGridBox = true, __widescreenPokemonStorageOwned = true,
    viewedBox = clamp(game.save.currentBox or 1, 1, 12),
    region = mode == "deposit" and "party" or "grid",
    gridIndex = 1, partyIndex = 1, popupIndex = 1,
    partyOpen = mode == "deposit", held = nil, popup = nil,
    footer = nil, previousGridIndex = 1,
    identityTokens = setmetatable({}, { __mode = "k" }), nextIdentityToken = 0,
  }, State)
  return self
end

function State:update(dt)
  if type(self.deps.updateInput) ~= "function" then return end
  local ok, value, reason = pcall(self.deps.updateInput, self.game, self, dt)
  if not ok or value == nil then
    self.held = nil
    self.popup = nil
    self.footer = "Storage provider unavailable; move cancelled."
    popState(self)
    if type(self.deps.logError) == "function" then
      self.deps.logError(ok and reason or value)
    end
  end
end
function State:draw() end

function State:immutableSnapshot()
  local box = boxAt(self, self.viewedBox)
  local cells = {}
  for i = 1, 20 do
    local stateName, enabled, reason = box[i] and "occupied" or "empty", true, nil
    local isOrigin = false
    if self.held then
      local ok
      ok, reason = targetReason(self, "box", i)
      enabled = ok == true
      if self.held.origin.kind == "box" and self.held.origin.box == self.viewedBox
          and self.held.origin.index == i then
        stateName = "held_origin"; isOrigin = true
      elseif not enabled then stateName = "invalid_target"
      elseif box[i] then stateName = "valid_swap"
      else stateName = "valid_target" end
    end
    -- The picked-up Pokemon's origin slot renders blank (no icon) while
    -- held, so the player can see it was physically removed from that slot.
    -- The held ghost (snapshot.held, drawn at the cursor by Widescreen) is
    -- the only copy shown until the hold commits or is cancelled.
    -- (Deliberately not `isOrigin and nil or box[i]`: when isOrigin is true
    -- that idiom evaluates `nil or box[i]`, which falls back to box[i]
    -- because nil is falsy -- the classic Lua ternary trap.)
    local cellMon = box[i]
    if isOrigin then cellMon = nil end
    cells[i] = descriptorFor(self, cellMon, stateName, enabled, reason)
  end
  local slots = {}
  for i = 1, 6 do
    local mon = self.game.save.party[i]
    local stateName, enabled, reason = mon and "occupied" or "empty", true, nil
    local isOrigin = false
    if self.held then
      local ok
      ok, reason = targetReason(self, "party", i)
      enabled = ok == true
      if self.held.origin.kind == "party" and self.held.origin.index == i then
        stateName = "held_origin"; isOrigin = true
      elseif not enabled then stateName = "invalid_target"
      elseif mon then stateName = "valid_swap"
      else stateName = "valid_target" end
    end
    local slotMon = mon
    if isOrigin then slotMon = nil end
    slots[i] = descriptorFor(self, slotMon, stateName, enabled, reason)
  end
  local popup
  if self.popup then
    local rows = {}
    for i, row in ipairs(self.popup.rows) do
      rows[i] = { id = row.id, label = row.label,
        enabled = row.enabled ~= false, disabledReason = row.disabledReason }
    end
    popup = { title = "ACTIONS", selectedIndex = self.popup.selectedIndex, rows = rows }
  end
  local selected = currentMon(self) or self.held and self.held.mon
  return {
    schemaVersion = 1,
    screen = self.popup and "popup" or self.partyOpen and "party" or self.mode,
    title = self.mode == "withdraw" and "WITHDRAW POKEMON"
      or self.mode == "deposit" and "DEPOSIT POKEMON" or "MOVE POKEMON",
    box = { viewedIndex = self.viewedBox,
      activeIndex = clamp(self.game.save.currentBox or 1, 1, 12),
      occupancy = #box, capacity = 20 },
    grid = { columns = 5, rows = 4, selectedIndex = self.gridIndex, cells = cells },
    party = { open = self.partyOpen, selectedIndex = self.partyIndex, slots = slots },
    partyButton = self.mode == "move" and { label = "PARTY",
      selected = self.region == "partyButton", enabled = true } or nil,
    selectedRegion = self.region,
    held = self.held and descriptorFor(self, self.held.mon, "occupied", true) or nil,
    detail = detailFor(self, selected), popup = popup,
    footer = self.footer,
    -- Move mode's PARTY drawer is reached by moving down from the bottom
    -- grid row, whether or not a Pokemon is currently held (a held Pokemon
    -- can be dropped into or swapped with a party slot), so both move-mode
    -- hint variants say so explicitly.
    hints = self.held and "A PLACE   B CANCEL   L/R OR Q/E: BOX   DOWN: PARTY"
      or self.mode == "move" and "A PICK UP   B BACK   L/R OR Q/E: BOX   DOWN: PARTY"
      or "A SELECT   B BACK   L/R OR Q/E: BOX",
  }
end

function State:up()
  if self.popup then
    self.popup.selectedIndex = (self.popup.selectedIndex - 2) % #self.popup.rows + 1
  elseif self.region == "party" then
    self.partyIndex = (self.partyIndex - 2) % 6 + 1
  elseif self.region == "partyButton" then
    self.region = "grid"; self.gridIndex = self.previousGridIndex
  else
    self.gridIndex = math.max(1, self.gridIndex - 5)
  end
  return true
end

function State:down()
  if self.popup then
    self.popup.selectedIndex = self.popup.selectedIndex % #self.popup.rows + 1
  elseif self.region == "party" then
    self.partyIndex = self.partyIndex % 6 + 1
  elseif self.region == "grid" and self.mode == "move" and self.gridIndex > 15 then
    self.previousGridIndex = self.gridIndex; self.region = "partyButton"
  elseif self.region == "grid" then
    self.gridIndex = math.min(20, self.gridIndex + 5)
  end
  return true
end

function State:left()
  if self.region == "party" then return true end
  if self.region == "partyButton" then return true end
  local column = (self.gridIndex - 1) % 5
  if column > 0 then self.gridIndex = self.gridIndex - 1 end
  return true
end

function State:right()
  if self.region == "party" then
    if self.mode == "move" then
      self.partyOpen = false; self.region = "grid"; self.gridIndex = self.previousGridIndex
    end
    return true
  end
  if self.region == "partyButton" then return true end
  local column = (self.gridIndex - 1) % 5
  if column < 4 then self.gridIndex = self.gridIndex + 1 end
  return true
end

function State:previousBox()
  if self.popup then return false end
  self.viewedBox = (self.viewedBox - 2) % 12 + 1
  self.gridIndex = clamp(self.gridIndex, 1, 20)
  return true
end

function State:nextBox()
  if self.popup then return false end
  self.viewedBox = self.viewedBox % 12 + 1
  self.gridIndex = clamp(self.gridIndex, 1, 20)
  return true
end


function State:select()
  if self.popup then return executePopup(self) end
  if self.region == "partyButton" then
    self.partyOpen = true; self.region = "party"; return true
  end
  local index = self.region == "party" and self.partyIndex or self.gridIndex
  if self.mode == "move" then
    if self.held then return commitHeld(self, self.region, index) end
    return beginHold(self, self.region, index)
  end
  return openPopup(self, self.mode, self.region, index)
end

function State:back()
  if self.popup then
    local region = self.popup.region; self.popup = nil; self.region = region; return true
  end
  if self.held then self.held = nil; self.footer = "Move cancelled."; return true end
  if self.partyOpen and self.mode == "move" then
    self.partyOpen = false; self.region = "grid"; self.gridIndex = self.previousGridIndex
    return true
  end
  return popState(self)
end

function State:selectCell(index)
  self.region = "grid"; self.gridIndex = clamp(index, 1, 20)
  return self:select()
end

function State:selectPartySlot(index)
  self.partyOpen = true; self.region = "party"; self.partyIndex = clamp(index, 1, 6)
  return self:select()
end

function State:selectPopup(index)
  if not self.popup then return false end
  self.region = "popup"; self.popup.selectedIndex = clamp(index, 1, #self.popup.rows)
  return self:select()
end

function State:selectPartyButton()
  self.region = "partyButton"
  return self:select()
end

State.Actions = {
  up = function(_, state) return state:up() end,
  down = function(_, state) return state:down() end,
  left = function(_, state) return state:left() end,
  right = function(_, state) return state:right() end,
  previousBox = function(_, state) return state:previousBox() end,
  nextBox = function(_, state) return state:nextBox() end,
  select = function(_, state) return state:select() end,
  back = function(_, state) return state:back() end,
  selectCell = function(_, state, index) return state:selectCell(index) end,
  selectPartySlot = function(_, state, index) return state:selectPartySlot(index) end,
  selectPopup = function(_, state, index) return state:selectPopup(index) end,
  selectPartyButton = function(_, state) return state:selectPartyButton() end,
}

return State
