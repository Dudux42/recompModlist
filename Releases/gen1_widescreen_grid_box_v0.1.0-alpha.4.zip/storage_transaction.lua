-- Widescreen Grid Box
-- Pure validate-then-commit storage transactions.

local Transaction = {}

Transaction.BOX_COUNT = 12
Transaction.BOX_CAPACITY = 20
Transaction.PARTY_CAPACITY = 6

local function integer(value)
  return type(value) == "number" and value == value
    and value ~= math.huge and value ~= -math.huge and value % 1 == 0
end

local function sequenceCopy(source)
  local out = {}
  for i, value in ipairs(source or {}) do out[i] = value end
  return out
end

local function replaceSequence(target, source)
  for i = #target, 1, -1 do target[i] = nil end
  for i, value in ipairs(source) do target[i] = value end
end

local function isDense(sequence)
  if type(sequence) ~= "table" then return false end
  local count = 0
  for key in pairs(sequence) do
    if type(key) == "number" then
      if not integer(key) or key < 1 then return false end
      count = count + 1
    end
  end
  return count == #sequence
end

local function defaultFingerprint(mon)
  if type(mon) ~= "table" then return nil end
  return table.concat({
    tostring(mon.species or ""), tostring(mon.nickname or ""),
    tostring(mon.otId or ""), tostring(mon.ot or ""),
    tostring(mon.level or ""), tostring(mon.exp or ""),
  }, "\31")
end

Transaction.fingerprint = defaultFingerprint

local function ensureBoxes(save)
  if type(save) ~= "table" then return nil, "save is unavailable" end
  if type(save.party) ~= "table" then return nil, "party is unavailable" end
  if type(save.boxes) ~= "table" then return nil, "boxes are unavailable" end
  for i = 1, Transaction.BOX_COUNT do
    if type(save.boxes[i]) ~= "table" then
      return nil, "box " .. tostring(i) .. " is unavailable"
    end
  end
  return true
end

local function locate(save, descriptor)
  if type(descriptor) ~= "table" then return nil, "location must be a table" end
  if descriptor.kind == "party" then
    return save.party, Transaction.PARTY_CAPACITY, "party"
  end
  if descriptor.kind == "box" and integer(descriptor.box)
      and descriptor.box >= 1 and descriptor.box <= Transaction.BOX_COUNT then
    return save.boxes[descriptor.box], Transaction.BOX_CAPACITY,
      "box " .. tostring(descriptor.box)
  end
  return nil, "unsupported storage location"
end

local function verifyDescriptor(sequence, descriptor, label, allowEmpty)
  if not integer(descriptor.index) or descriptor.index < 1 then
    return nil, label .. " index is invalid"
  end
  if descriptor.count ~= nil and descriptor.count ~= #sequence then
    return nil, label .. " container changed"
  end
  local current = sequence[descriptor.index]
  if not current and not allowEmpty then return nil, label .. " Pokemon is missing" end
  if descriptor.expected ~= nil and current ~= descriptor.expected then
    return nil, label .. " identity changed"
  end
  if descriptor.fingerprint ~= nil
      and defaultFingerprint(current) ~= descriptor.fingerprint then
    return nil, label .. " fingerprint changed"
  end
  return current
end

local function sameContainer(a, b)
  if a.kind ~= b.kind then return false end
  return a.kind == "party" or a.box == b.box
end

local function proposedStorageIsValid(save, replacements)
  local party = replacements.party or save.party
  if not isDense(party) or #party < 1 or #party > Transaction.PARTY_CAPACITY then
    return nil, "transaction would violate party bounds"
  end
  for i = 1, Transaction.BOX_COUNT do
    local box = replacements.boxes and replacements.boxes[i] or save.boxes[i]
    if not isDense(box) or #box > Transaction.BOX_CAPACITY then
      return nil, "transaction would violate box " .. tostring(i) .. " bounds"
    end
  end
  return true
end

function Transaction.validateStorage(save)
  local ok, reason = ensureBoxes(save)
  if not ok then return nil, reason end
  return proposedStorageIsValid(save, {})
end

function Transaction.describe(save, kind, box, index)
  local descriptor = { kind = kind, box = box, index = index }
  local sequence = kind == "party" and save.party
    or save.boxes and save.boxes[box]
  local mon = sequence and sequence[index]
  descriptor.count = sequence and #sequence or nil
  descriptor.expected = mon
  descriptor.fingerprint = defaultFingerprint(mon)
  return descriptor
end

local function buildSameContainer(sequence, origin, destination)
  if destination.index > #sequence + 1 then
    return nil, "only the first dense empty tail slot is a valid target"
  end
  if destination.index == origin.index then return nil, "origin is not a destination" end
  local out = sequenceCopy(sequence)
  if destination.index <= #out then
    out[origin.index], out[destination.index] = out[destination.index], out[origin.index]
    return out, "swap"
  end
  local mon = table.remove(out, origin.index)
  table.insert(out, mon)
  return out, "reorder"
end

local function shallowFields(mon)
  return { stats = mon and mon.stats, hp = mon and mon.hp }
end

local function applyPrepared(mon, prepared)
  if type(prepared) ~= "table" then return end
  if prepared.stats ~= nil then mon.stats = prepared.stats end
  if prepared.hp ~= nil then mon.hp = prepared.hp end
end

-- context callbacks:
--   canLeaveParty(mon, replacementEntersParty) -> true | nil, reason
--   prepareEnterParty(mon) -> {stats=..., hp=...}   (must not mutate mon)
--   afterLeaveParty(mon)                            (DEPOSITED happiness)
function Transaction.commit(save, origin, destination, context)
  context = type(context) == "table" and context or {}
  local ok, reason = ensureBoxes(save)
  if not ok then return nil, reason end
  ok, reason = Transaction.validateStorage(save)
  if not ok then return nil, reason end

  local source, sourceCapacity, sourceLabel = locate(save, origin)
  if not source then return nil, sourceCapacity end
  local target, targetCapacity, targetLabel = locate(save, destination)
  if not target then return nil, targetCapacity end
  local mon
  mon, reason = verifyDescriptor(source, origin, "origin", false)
  if not mon then return nil, reason end
  if destination.index > targetCapacity then return nil, "destination is outside capacity" end
  local targetMon
  targetMon, reason = verifyDescriptor(target, destination, "destination", true)
  if reason then return nil, reason end

  if sameContainer(origin, destination) then
    local replacement, operation = buildSameContainer(source, origin, destination)
    if not replacement then return nil, operation end
    local replacements = { boxes = {} }
    if origin.kind == "party" then replacements.party = replacement
    else replacements.boxes[origin.box] = replacement end
    ok, reason = proposedStorageIsValid(save, replacements)
    if not ok then return nil, reason end
    replaceSequence(source, replacement)
    return true, operation
  end

  if destination.index > #target + 1 then
    return nil, "only the first dense empty tail slot is a valid target"
  end
  if not targetMon and #target >= targetCapacity then
    return nil, targetLabel .. " is full"
  end

  local leavingParty = origin.kind == "party" and destination.kind == "box"
    and mon or destination.kind == "party" and origin.kind == "box" and targetMon or nil
  local enteringParty = origin.kind == "box" and destination.kind == "party"
    and mon or destination.kind == "box" and origin.kind == "party" and targetMon or nil

  if leavingParty and type(context.canLeaveParty) == "function" then
    ok, reason = context.canLeaveParty(leavingParty, targetMon ~= nil)
    if not ok then return nil, reason or "Pokemon cannot leave the party" end
  end

  local sourceOut, targetOut = sequenceCopy(source), sequenceCopy(target)
  if targetMon then
    sourceOut[origin.index], targetOut[destination.index] = targetMon, mon
  else
    table.remove(sourceOut, origin.index)
    table.insert(targetOut, mon)
  end

  local replacements = { boxes = {} }
  if origin.kind == "party" then replacements.party = sourceOut
  else replacements.boxes[origin.box] = sourceOut end
  if destination.kind == "party" then replacements.party = targetOut
  else replacements.boxes[destination.box] = targetOut end
  ok, reason = proposedStorageIsValid(save, replacements)
  if not ok then return nil, reason end

  local prepared
  if enteringParty and type(context.prepareEnterParty) == "function" then
    ok, prepared = pcall(context.prepareEnterParty, enteringParty)
    if not ok then return nil, "party stat preparation failed: " .. tostring(prepared) end
    if type(prepared) ~= "table" then
      return nil, "party stat preparation returned no result"
    end
  end

  local sourceBefore, targetBefore = sequenceCopy(source), sequenceCopy(target)
  local enterBefore = shallowFields(enteringParty)
  local happinessBefore = save.pikachuHappiness
  local moodBefore = save.pikachuMood
  replaceSequence(source, sourceOut)
  replaceSequence(target, targetOut)
  applyPrepared(enteringParty, prepared)

  if leavingParty and type(context.afterLeaveParty) == "function" then
    ok, reason = pcall(context.afterLeaveParty, leavingParty)
    if not ok then
      replaceSequence(source, sourceBefore)
      replaceSequence(target, targetBefore)
      if enteringParty then
        enteringParty.stats, enteringParty.hp = enterBefore.stats, enterBefore.hp
      end
      save.pikachuHappiness, save.pikachuMood = happinessBefore, moodBefore
      return nil, "party deposit effect failed: " .. tostring(reason)
    end
  end

  return true, targetMon and "swap" or "transfer"
end

return Transaction
