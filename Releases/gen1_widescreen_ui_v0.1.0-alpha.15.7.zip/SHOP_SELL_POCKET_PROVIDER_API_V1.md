# Shop Sell Pocket Provider API v1

Widescreen version floor: `gen1_widescreen_ui >= 0.1.0-alpha.15.3 <0.2.0`.

This optional, one-owner contract lets an inventory mod such as Modern Bag
classify the native Pokemart SELL list into pockets. Widescreen owns the
640x360 pocket tabs, filtering and left/right focus. The engine remains the
sole owner of prices, quantities, money, inventory mutation, sale callbacks
and shop messages.

## Exports

- `shopSellPocketProviderApiVersion == 1`
- `registerShopSellPocketProvider(spec)`
- `unregisterShopSellPocketProvider(owner)`
- `activeShopSellPocketProviderOwner()`
- `invokeShopSellPocketProviderAction(actionId, game, state, ...)`

Registration is deterministic. A second owner is rejected; registering the
same owner replaces its descriptor.

```lua
local ok, reason = widescreen.exports.registerShopSellPocketProvider({
  owner = "gen1_widescreen_modern_bag",
  apiVersion = 1,
  snapshot = function(game, context)
    return {
      schemaVersion = 1,
      pockets = {
        { id = "medicine", label = "MEDICINE" },
        { id = "balls", label = "BALLS" },
        { id = "items", label = "ITEMS" },
      },
      selectedPocketId = "medicine",
      itemPocketById = {
        POTION = "medicine",
        POKE_BALL = "balls",
        NUGGET = "items",
      },
    }
  end,
  actions = {
    pocketLeft = function(game, context) end,
    pocketRight = function(game, context) end,
  },
})
```

## Immutable context

`snapshot` and actions receive a newly allocated semantic context:

```lua
{
  mode = "sell",
  items = {
    { itemId = "POTION", label = "POTION", count = 4, sellable = true },
  },
}
```

It never contains the Bag, shop row table, save inventory, prices or mutation
callbacks. Every listed item ID must map to one declared pocket. Invalid or
throwing providers are isolated, logged once per distinct fault and ignored;
the complete native SELL list is restored.

## Input and sale restrictions

- Left/right invoke `pocketLeft`/`pocketRight`, then request a fresh snapshot.
- Up/down, A and B continue through the native `ListMenu`.
- Quantity up/down changes by one; right/left changes by ten.
- Technical Machines are always visible when their pocket is selected but are
  rejected before the native sale callback. This restriction applies with or
  without Modern Bag. HMs and key items retain the engine's existing block.

The provider must not sort prices, complete sales, alter quantities or mutate
inventory. Those are explicit non-goals of this API.
