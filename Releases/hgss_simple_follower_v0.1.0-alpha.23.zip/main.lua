-- HGSS Simple Follower v0.1.0-alpha.23
-- One selectable party follower. No PokePC, Followers EX, or Wilds runtime
-- ownership is used here; Wilds may remain installed with its follower count 0.

local SPECIES = {
  "BULBASAUR","IVYSAUR","VENUSAUR","CHARMANDER","CHARMELEON","CHARIZARD",
  "SQUIRTLE","WARTORTLE","BLASTOISE","CATERPIE","METAPOD","BUTTERFREE",
  "WEEDLE","KAKUNA","BEEDRILL","PIDGEY","PIDGEOTTO","PIDGEOT","RATTATA",
  "RATICATE","SPEAROW","FEAROW","EKANS","ARBOK","PIKACHU","RAICHU",
  "SANDSHREW","SANDSLASH","NIDORAN_F","NIDORINA","NIDOQUEEN","NIDORAN_M",
  "NIDORINO","NIDOKING","CLEFAIRY","CLEFABLE","VULPIX","NINETALES",
  "JIGGLYPUFF","WIGGLYTUFF","ZUBAT","GOLBAT","ODDISH","GLOOM","VILEPLUME",
  "PARAS","PARASECT","VENONAT","VENOMOTH","DIGLETT","DUGTRIO","MEOWTH",
  "PERSIAN","PSYDUCK","GOLDUCK","MANKEY","PRIMEAPE","GROWLITHE","ARCANINE",
  "POLIWAG","POLIWHIRL","POLIWRATH","ABRA","KADABRA","ALAKAZAM","MACHOP",
  "MACHOKE","MACHAMP","BELLSPROUT","WEEPINBELL","VICTREEBEL","TENTACOOL",
  "TENTACRUEL","GEODUDE","GRAVELER","GOLEM","PONYTA","RAPIDASH","SLOWPOKE",
  "SLOWBRO","MAGNEMITE","MAGNETON","FARFETCHD","DODUO","DODRIO","SEEL",
  "DEWGONG","GRIMER","MUK","SHELLDER","CLOYSTER","GASTLY","HAUNTER",
  "GENGAR","ONIX","DROWZEE","HYPNO","KRABBY","KINGLER","VOLTORB",
  "ELECTRODE","EXEGGCUTE","EXEGGUTOR","CUBONE","MAROWAK","HITMONLEE",
  "HITMONCHAN","LICKITUNG","KOFFING","WEEZING","RHYHORN","RHYDON","CHANSEY",
  "TANGELA","KANGASKHAN","HORSEA","SEADRA","GOLDEEN","SEAKING","STARYU",
  "STARMIE","MR_MIME","SCYTHER","JYNX","ELECTABUZZ","MAGMAR","PINSIR",
  "TAUROS","MAGIKARP","GYARADOS","LAPRAS","DITTO","EEVEE","VAPOREON",
  "JOLTEON","FLAREON","PORYGON","OMANYTE","OMASTAR","KABUTO","KABUTOPS",
  "AERODACTYL","SNORLAX","ARTICUNO","ZAPDOS","MOLTRES","DRATINI","DRAGONAIR",
  "DRAGONITE","MEWTWO","MEW",
}

local DEX = {}
for dex, species in ipairs(SPECIES) do DEX[species] = dex end

return function(mod)
  local Game = require("src.core.Game")
  local Assets = require("src.render.Assets")
  local PaletteFX = require("src.render.PaletteFX")
  local NPC = require("src.world.NPC")
  local Collision = require("src.world.Collision")
  local OverworldState = require("src.world.OverworldController")
  local PikachuFollower = require("src.world.PikachuFollower")
  local Strings = require("src.core.Strings")
  local TextBox = require("src.render.TextBox")
  local Sound = require("src.core.Sound")
  local Stats = require("src.pokemon.Stats")

  local SPRITE_ID = "SPRITE_HGSS_SIMPLE_FOLLOWER"
  local PROVIDER_SPRITE_ID = "SPRITE_HGSS_OVERWORLD_PROVIDER"
  local NPC_INDEX = 239
  local STATE_KEY = "hgssSimpleFollower"
  local FOLLOW_BEHIND = "behind"
  local FOLLOW_FREE = "free_nearby"
  local EMERGENCY_DISTANCE = 10
  local EMERGENCY_GRACE_TICKS = 45
  local FREE_CATCHUP_DISTANCE = 4
  local FREE_INITIAL_PAUSE_MIN = 60
  local FREE_INITIAL_PAUSE_MAX = 120
  local FREE_PAUSE_MIN = 120
  local FREE_PAUSE_MAX = 240
  local DIRECTIONS = { "up", "right", "down", "left" }
  local FRAME_STAND = { down = 0, up = 1, left = 2, right = 2 }
  local FRAME_WALK = { down = 3, up = 4, left = 5, right = 5 }

  if mod.options and mod.options.define then
    mod.options:define({
      {
        key = "follow_style",
        type = "choice",
        label = "FOLLOW STYLE",
        default = FOLLOW_BEHIND,
        choices = {
          { "Follow Behind", FOLLOW_BEHIND },
          { "Free Nearby", FOLLOW_FREE },
        },
        help = "Choose exact trail following or calm movement near the player.",
      },
      {
        key = "follower_count",
        type = "choice",
        label = "FOLLOWERS",
        default = "1",
        choices = {
          { "One", "1" },
          { "Two", "2" },
          { "Three", "3" },
        },
        help = "Show the selected Pokemon plus healthy party companions.",
      },
    })
  end

  local function followStyle()
    if not (mod.options and mod.options.get) then return FOLLOW_BEHIND end
    local ok, value = pcall(mod.options.get, mod.options, "follow_style")
    if ok and value == FOLLOW_FREE then return FOLLOW_FREE end
    return FOLLOW_BEHIND
  end

  local function followerLimit()
    if not (mod.options and mod.options.get) then return 1 end
    local ok, value = pcall(mod.options.get, mod.options, "follower_count")
    value = ok and tonumber(value) or 1
    if value ~= 2 and value ~= 3 then return 1 end
    return value
  end

  -- Tests may inject mod.rng. Production uses Love's seeded RNG and never a
  -- wall clock, keeping movement reproducible under a mocked random source.
  local function randomInt(low, high)
    local source = type(mod.rng) == "function" and mod.rng
      or (love and love.math and love.math.random) or math.random
    local ok, value = pcall(source, low, high)
    value = ok and math.floor(tonumber(value) or low) or low
    return math.max(low, math.min(high, value))
  end

  local function isShiny(mon)
    if type(mon) ~= "table" then return false end
    local shinyMod = mod.find and mod:find("gen1_shiny_system")
    local use = shinyMod and shinyMod.exports
      and shinyMod.exports.shouldUseShinyArt
    if type(use) == "function" then
      local ok, value = pcall(use, mon)
      if ok then return value and true or false end
    end
    if mon.shiny == true then return true end
    return Stats.isShiny and Stats.isShiny(mon.dvs) and true or false
  end

  local function speciesKey(monOrSpecies)
    local value = type(monOrSpecies) == "table" and monOrSpecies.species
      or monOrSpecies
    if type(value) ~= "string" then return nil, "species must be a string" end
    local key = value:upper()
    if not DEX[key] then return nil, "unknown Gen 1 species: " .. tostring(value) end
    return key
  end

  local function assetPath(species, shiny)
    local dex = assert(DEX[species])
    return mod.assets:path(string.format(shiny and "shiny_%03d.png"
      or "follower_%03d.png", dex))
  end

  -- Dramatic Shape's stock billboard builder measures Gen 1 overworld sheets
  -- as 16x96.  Keep a matching per-species proxy as the definition image,
  -- while resolveImage() supplies the native 32x192 texture.  Because the
  -- billboards use normalized UVs, even the stock path then samples every
  -- complete 32x32 frame instead of the tiny upper-left fragment.
  local function proxyPath(species)
    local dex = assert(DEX[species])
    return mod.assets:path(string.format("proxy_%03d.png", dex))
  end

  -- NPC.new needs a registered sprite definition, but the live entity is
  -- immediately given the 32x32 renderer below. This placeholder never draws.
  local followerPlaceholder = {
    id = SPRITE_ID,
    image = proxyPath("CHARMANDER"),
    frames = 6,
    walker = true,
    trueColor = true,
    hgssSimpleFollower = true,
  }
  local providerPlaceholder = {
    id = PROVIDER_SPRITE_ID,
    image = proxyPath("CHARMANDER"),
    frames = 6,
    walker = true,
    trueColor = true,
    frameWidth = 32,
    frameHeight = 32,
    hgssOverworldSprite = true,
  }
  local providerDefinitionReady = false
  pcall(function()
    if mod.content.sprites:get(SPRITE_ID) then
      mod.content.sprites:patch(SPRITE_ID, followerPlaceholder)
    else
      mod.content.sprites:register(SPRITE_ID, followerPlaceholder)
    end
    if mod.content.sprites:get(PROVIDER_SPRITE_ID) then
      mod.content.sprites:patch(PROVIDER_SPRITE_ID, providerPlaceholder)
    else
      mod.content.sprites:register(PROVIDER_SPRITE_ID, providerPlaceholder)
    end
    providerDefinitionReady = mod.content.sprites:get(PROVIDER_SPRITE_ID) ~= nil
  end)

  local imageCache = {}
  local function overworldImage(species, shiny)
    local key = species .. (shiny and "#S" or "#N")
    if not imageCache[key] then
      local ok, image = pcall(Assets.image, assetPath(species, shiny))
      if not (ok and image) then
        return nil, "unavailable overworld artwork for " .. species
      end
      local dimensionsOk, width, height = pcall(image.getDimensions, image)
      if not dimensionsOk or width ~= 32 or height ~= 192 then
        return nil, string.format("invalid overworld sheet for %s: expected 32x192",
          species)
      end
      local filterOk = pcall(image.setFilter, image, "nearest", "nearest")
      if not filterOk then return nil, "could not set nearest filtering for " .. species end
      if image.setWrap then pcall(image.setWrap, image, "clamp", "clamp") end
      imageCache[key] = image
    end
    return imageCache[key]
  end
  Assets.register(function() imageCache = {} end)

  -- A native 32x32 sheet renderer. The feet retain the stock 16x16 entity
  -- anchor while the artwork extends eight pixels sideways and sixteen up.
  local OverworldSprite = {}
  OverworldSprite.__index = OverworldSprite

  function OverworldSprite.new(mon, species, shiny, providerOptions)
    local self = setmetatable({}, OverworldSprite)
    self.mon = type(mon) == "table" and mon or nil
    self.species = species
    self.shiny = shiny and true or false
    self.owner = providerOptions and providerOptions.owner or mod.id
    self.role = providerOptions and providerOptions.role or "follower"
    local provider = providerOptions ~= nil
    self.def = {
      id = provider and PROVIDER_SPRITE_ID or SPRITE_ID,
      image = proxyPath(self.species),
      frames = 6,
      walker = true,
      trueColor = true,
      frameWidth = 32,
      frameHeight = 32,
    }
    if provider then
      self.def.hgssOverworldSprite = true
    else
      self.def.hgssSimpleFollower = true
    end
    local image, reason = overworldImage(self.species, self.shiny)
    if not image then return nil, reason end
    self.image = image
    self.quads = {}
    for frame = 0, 5 do
      self.quads[frame] = love.graphics.newQuad(0, frame * 32, 32, 32, 32, 192)
    end
    return self
  end

  function OverworldSprite:resolveImage()
    return self.image
  end

  function OverworldSprite:draw(px, py, camX, camY, facing, walkPhase, stepFlip)
    local frame = ((walkPhase == 1) and FRAME_WALK or FRAME_STAND)[facing] or 0
    local flip = facing == "right"
      or (walkPhase == 1 and stepFlip and (facing == "up" or facing == "down"))
    local scale = 1
    local x = math.floor(px - camX) - 8
    local y = math.floor(py - camY) - 20
    love.graphics.setColor(1, 1, 1, 1)
    if flip then
      love.graphics.draw(self.image, self.quads[frame], x + 32, y, 0, -scale, scale)
    else
      love.graphics.draw(self.image, self.quads[frame], x, y, 0, scale, scale)
    end
    if PaletteFX and PaletteFX.markTrueColor then
      PaletteFX.markTrueColor(x, y, 32, 32)
    end
    local shinyMod = mod.find and mod:find("gen1_shiny_system")
    local draw = shinyMod and shinyMod.exports
      and shinyMod.exports.drawFollowerSparkles
    if type(draw) == "function" and self.mon and self.role == "follower" then
      pcall(draw, self.mon, x, y, 32, 32)
    end
  end

  local function createOverworldSprite(monOrSpecies, options)
    if not providerDefinitionReady then
      return nil, "provider sprite definition is unavailable"
    end
    if type(options) ~= "table" or type(options.owner) ~= "string"
        or options.owner == "" then
      return nil, "options.owner must be a non-empty string"
    end
    if options.role ~= nil and (type(options.role) ~= "string" or options.role == "") then
      return nil, "options.role must be a non-empty string when supplied"
    end
    local species, reason = speciesKey(monOrSpecies)
    if not species then return nil, reason end
    return OverworldSprite.new(monOrSpecies, species, isShiny(monOrSpecies), {
      owner = options.owner,
      role = options.role or "overworld",
    })
  end

  local function healthy(mon)
    return type(mon) == "table" and (tonumber(mon.hp) or 0) > 0
  end

  -- OT + DVs are stable across party reordering and evolution. The slot is
  -- retained as a fast path but is never treated as the Pokemon's identity.
  local function monKey(mon)
    if type(mon) ~= "table" then return nil end
    local dvs = mon.dvs
    if type(dvs) == "table" then
      dvs = table.concat({
        tostring(dvs.attack or dvs.atk or -1),
        tostring(dvs.defense or dvs.def or -1),
        tostring(dvs.speed or dvs.spd or -1),
        tostring(dvs.special or dvs.spc or -1),
      }, ".")
    end
    return tostring(mon.otId or mon.ot or -1) .. ":" .. tostring(dvs or -1)
  end

  local function saveState(game)
    if not (game and game.save) then return nil end
    game.save[STATE_KEY] = game.save[STATE_KEY] or { enabled = false }
    return game.save[STATE_KEY]
  end

  local function firstHealthy(party)
    for slot, mon in ipairs(party or {}) do
      if healthy(mon) then return mon, slot end
    end
    return nil
  end

  local function selectedMon(game)
    local state = saveState(game)
    if not (state and state.enabled) then return nil end
    local party = game.save.party or {}
    local key = state.selectedKey
    local slot = tonumber(state.selectedSlot)
    if key and slot and party[slot] and monKey(party[slot]) == key then
      return party[slot], slot
    end
    if key then
      for index, mon in ipairs(party) do
        if monKey(mon) == key then
          state.selectedSlot = index
          return mon, index
        end
      end
    end
    return nil
  end

  -- This is also the fainting/deposit failover path. Once replacement occurs,
  -- the replacement becomes the saved selection and does not switch back later.
  local function activeMon(game)
    local state = saveState(game)
    if not (state and state.enabled) then return nil end
    local mon, slot = selectedMon(game)
    if healthy(mon) then return mon, slot end
    mon, slot = firstHealthy(game.save.party)
    if mon then
      state.selectedKey = monKey(mon)
      state.selectedSlot = slot
      state.lastFailover = true
      return mon, slot
    end
    return nil
  end

  local function selectMon(game, mon)
    if not healthy(mon) then return false end
    local state = saveState(game)
    local party = game.save.party or {}
    for slot, candidate in ipairs(party) do
      if candidate == mon then
        state.enabled = true
        state.selectedKey = monKey(mon)
        state.selectedSlot = slot
        state.lastFailover = false
        return true
      end
    end
    return false
  end

  local function followerEnabled(game)
    local state = saveState(game)
    return state and state.enabled == true
  end

  local function activeMons(game)
    local primary = activeMon(game)
    if not primary then return {} end
    local out, used = { primary }, { [monKey(primary)] = true }
    for _, mon in ipairs(game.save.party or {}) do
      local key = monKey(mon)
      if #out >= followerLimit() then break end
      if healthy(mon) and not used[key] then
        out[#out + 1] = mon
        used[key] = true
      end
    end
    return out
  end

  local function findFollowers(ow)
    local out = {}
    for _, npc in ipairs(ow and ow.npcs or {}) do
      if npc.hgssSimpleFollower then out[#out + 1] = npc end
    end
    table.sort(out, function(a, b)
      return (a.hgssFollowerRank or 99) < (b.hgssFollowerRank or 99)
    end)
    return out
  end

  local function filterList(list, predicate)
    local out = {}
    for _, value in ipairs(list or {}) do
      if predicate(value) then out[#out + 1] = value end
    end
    return out
  end

  local function removeFollower(ow)
    if not ow then return end
    ow.npcs = filterList(ow.npcs, function(npc) return not npc.hgssSimpleFollower end)
    ow.entities = filterList(ow.entities, function(entity) return not entity.hgssSimpleFollower end)
    ow.hgssSimpleTrail = nil
    ow.hgssSimpleFree = nil
  end

  local function removeStockPikachu(ow)
    if not ow then return end
    ow.npcs = filterList(ow.npcs, function(npc)
      return not (npc and npc.pikachuFollower and not npc.hgssSimpleFollower)
    end)
    ow.entities = filterList(ow.entities, function(entity)
      return not (entity and entity.pikachuFollower and not entity.hgssSimpleFollower)
    end)
  end

  -- The follower may spawn only on the cell directly behind the player. The
  -- synthetic entity is passable and may temporarily occupy a coordinate just
  -- outside the destination map during a seamless connection: the engine puts
  -- the player there too while completing the cross-map step.
  local function followerSpawnCell(ow, mon, rank)
    local p = ow.player
    local pending = ow.hgssSimplePendingOffsets
    local preserved = followStyle() == FOLLOW_FREE and pending
      and pending[monKey(mon)]
    if preserved and pending then pending[monKey(mon)] = nil end

    local function baseSafe(x, y)
      local map = ow.map
      local occupied = false
      local seen = {}
      for _, list in ipairs({ ow.entities or {}, ow.npcs or {} }) do
        for _, entity in ipairs(list) do
          if entity ~= p and not seen[entity] then
            seen[entity] = true
            if (entity.cellX == x and entity.cellY == y)
                or (entity.targetX == x and entity.targetY == y) then
              occupied = true
              break
            end
          end
        end
        if occupied then break end
      end
      local scripted = false
      for _, key in ipairs({ "triggers", "stepTriggers", "coordEvents", "events" }) do
        for _, trigger in pairs(type(map.def and map.def[key]) == "table"
            and map.def[key] or {}) do
          if type(trigger) == "table" and tonumber(trigger.x) == x
              and tonumber(trigger.y) == y then scripted = true break end
        end
        if scripted then break end
      end
      return map:inBounds(x, y) and map:isWalkableCell(x, y) and not occupied
          and not (p.targetX == x and p.targetY == y)
          and not (map.warpAtCell and map:warpAtCell(x, y))
          and not (map.isWarpTileCell and map:isWarpTileCell(x, y))
          and not (map.isDoorTileCell and map:isDoorTileCell(x, y))
          and not (map.signAtCell and map:signAtCell(x, y)) and not scripted
    end

    local function safe(x, y)
      if not baseSafe(x, y) then return false end
      local queue = { { x = p.cellX, y = p.cellY } }
      local head, visited = 1, { [p.cellX .. ":" .. p.cellY] = true }
      while head <= #queue and head <= 128 do
        local node = queue[head]
        head = head + 1
        for _, direction in ipairs(DIRECTIONS) do
          local delta = Collision.DELTA[direction]
          local nx, ny = node.x + delta[1], node.y + delta[2]
          local key = nx .. ":" .. ny
          if not visited[key] and baseSafe(nx, ny) then
            local probe = { cellX = node.x, cellY = node.y, passable = true }
            if Collision.canMove(ow.map, ow.entities, probe, direction) then
              if nx == x and ny == y then return true end
              visited[key] = true
              queue[#queue + 1] = { x = nx, y = ny }
            end
          end
        end
      end
      return false
    end

    if preserved then
      local x, y = p.cellX + preserved.x, p.cellY + preserved.y
      if safe(x, y) then return x, y end
    end

    local forward = Collision.DELTA[p.facing or "down"] or Collision.DELTA.down
    local right = { -forward[2], forward[1] }
    local offsets
    if followStyle() == FOLLOW_FREE then
      offsets = {
        { -forward[1], -forward[2] },
        { -forward[1] * 2, -forward[2] * 2 },
        { -forward[1] + right[1], -forward[2] + right[2] },
        { -forward[1] - right[1], -forward[2] - right[2] },
        { right[1], right[2] },
        { -right[1], -right[2] },
      }
    else
      offsets = { { -forward[1] * rank, -forward[2] * rank } }
    end
    local start = math.max(1, math.min(#offsets, rank))
    for offset = 0, #offsets - 1 do
      local cell = offsets[((start + offset - 1) % #offsets) + 1]
      local x, y = p.cellX + cell[1], p.cellY + cell[2]
      if safe(x, y) then return x, y end
    end
    if followStyle() == FOLLOW_FREE then return nil, nil end
    local fallback = offsets[start]
    return p.cellX + fallback[1], p.cellY + fallback[2]
  end

  local function makeFollower(game, ow, mon, rank)
    local x, y = followerSpawnCell(ow, mon, rank)
    if x == nil or y == nil then return nil end
    local npc = NPC.new(game.data, ow.map.id, {
      index = NPC_INDEX + rank - 1,
      name = "HGSS_SIMPLE_FOLLOWER_" .. tostring(rank),
      sprite = SPRITE_ID,
      movement = "STAY",
      range = "NONE",
      x = x,
      y = y,
    })
    npc.hgssSimpleFollower = true
    npc.hgssFollowerRank = rank
    npc.pikachuFollower = false
    npc.passable = true
    npc.facing = ow.player.facing or "down"
    npc.monKey = monKey(mon)
    npc.monSpecies = mon.species
    npc.monShiny = isShiny(mon)
    local species = assert(speciesKey(mon))
    npc.sprite = assert(OverworldSprite.new(mon, species, isShiny(mon)))
    npc.walkPhase = function(self)
      if self.moving then return NPC.walkPhase(self) end
      return 0
    end
    table.insert(ow.npcs, npc)
    -- Flat rendering follows entity-list order. The 32px follower card can
    -- overlap the trainer even from an adjacent tile, so insert it before the
    -- player to keep the follower visually behind the trainer.
    local playerIndex
    for index, entity in ipairs(ow.entities or {}) do
      if entity == ow.player then playerIndex = index break end
    end
    table.insert(ow.entities, playerIndex or (#ow.entities + 1), npc)
    return npc
  end

  local function ledgeStep(game, ow, cx, cy, direction)
    local delta = Collision.DELTA[direction]
    if not delta then return false end
    local fx, fy = cx + delta[1], cy + delta[2]
    local lx, ly = cx + delta[1] * 2, cy + delta[2] * 2
    if not (ow.map:inBounds(fx, fy) and ow.map:inBounds(lx, ly)) then return false end
    local standing = ow.map:cellTile(cx, cy)
    local front = ow.map:cellTile(fx, fy)
    for _, ledge in ipairs(game.data.field.ledges or {}) do
      if (ledge.tileset or "OVERWORLD") == ow.map.def.tileset
        and ledge.facing == direction and ledge.input == direction
        and ledge.standingTile == standing and ledge.ledgeTile == front then
        return true
      end
    end
    return false
  end

  local function place(npc, x, y)
    npc.cellX, npc.cellY = x, y
    npc.px, npc.py = x * 16, y * 16
    npc.targetX, npc.targetY = nil, nil
    npc.goalX, npc.goalY = nil, nil
    npc.moving, npc.hopStep = false, nil
    npc.progress = 0
    npc.hgssFarTicks = 0
  end

  local function hiddenByTravel(game, ow)
    local p = ow and ow.player
    return not p or game.save.onBike or p.onBike or p.surfing or p.fishing
  end

  local function manhattan(ax, ay, bx, by)
    return math.abs(ax - bx) + math.abs(ay - by)
  end

  local function scriptedCell(map, x, y)
    local def = map and map.def
    if type(def) ~= "table" then return false end
    for _, key in ipairs({ "triggers", "stepTriggers", "coordEvents", "events" }) do
      for _, trigger in pairs(type(def[key]) == "table" and def[key] or {}) do
        if type(trigger) == "table" and tonumber(trigger.x) == x
            and tonumber(trigger.y) == y then
          return true
        end
      end
    end
    return false
  end

  local function occupiedByAnyone(ow, npc, x, y)
    local seen = {}
    for _, list in ipairs({ ow.entities or {}, ow.npcs or {} }) do
      for _, entity in ipairs(list) do
        if entity ~= npc and not seen[entity] then
          seen[entity] = true
          if (entity.cellX == x and entity.cellY == y)
              or (entity.targetX == x and entity.targetY == y) then
            return true
          end
        end
      end
    end
    return false
  end

  local function legalFreeCell(ow, npc, x, y)
    local map, player = ow.map, ow.player
    if not map:inBounds(x, y) or not map:isWalkableCell(x, y) then return false end
    if map.warpAtCell and map:warpAtCell(x, y) then return false end
    if map.isWarpTileCell and map:isWarpTileCell(x, y) then return false end
    if map.isDoorTileCell and map:isDoorTileCell(x, y) then return false end
    if map.signAtCell and map:signAtCell(x, y) then return false end
    if scriptedCell(map, x, y) then return false end
    if (player.cellX == x and player.cellY == y)
        or (player.targetX == x and player.targetY == y) then return false end
    return not occupiedByAnyone(ow, npc, x, y)
  end

  local function canFreeStep(game, ow, mover, npc, direction)
    local delta = Collision.DELTA[direction]
    if not delta then return false end
    local tx, ty = mover.cellX + delta[1], mover.cellY + delta[2]
    if not legalFreeCell(ow, npc, tx, ty) then return false end
    -- Free wandering never improvises a ledge hop. Strict trail mode retains
    -- the audited player-ledged path below.
    if ledgeStep(game, ow, mover.cellX, mover.cellY, direction) then return false end
    return Collision.canMove(ow.map, ow.entities, mover, direction) and true or false
  end

  local function firstPathStep(game, ow, npc, goalX, goalY)
    if npc.cellX == goalX and npc.cellY == goalY then return false end
    local queue = { { x = npc.cellX, y = npc.cellY } }
    local head, visited = 1, { [npc.cellX .. ":" .. npc.cellY] = true }
    while head <= #queue and head <= 256 do
      local node = queue[head]
      head = head + 1
      for _, direction in ipairs(DIRECTIONS) do
        local delta = Collision.DELTA[direction]
        local nx, ny = node.x + delta[1], node.y + delta[2]
        local key = nx .. ":" .. ny
        if not visited[key] then
          local probe = { cellX = node.x, cellY = node.y, passable = true }
          if canFreeStep(game, ow, probe, npc, direction) then
            local first = node.first or direction
            if nx == goalX and ny == goalY then return first end
            visited[key] = true
            queue[#queue + 1] = { x = nx, y = ny, first = first }
          end
        end
      end
    end
    return nil
  end

  local function nearbyCandidates(ow, npc, minDistance, maxDistance)
    local out, player = {}, ow.player
    for y = player.cellY - maxDistance, player.cellY + maxDistance do
      for x = player.cellX - maxDistance, player.cellX + maxDistance do
        local distance = manhattan(x, y, player.cellX, player.cellY)
        if distance >= minDistance and distance <= maxDistance
            and not (x == npc.cellX and y == npc.cellY)
            and legalFreeCell(ow, npc, x, y) then
          out[#out + 1] = { x = x, y = y }
        end
      end
    end
    return out
  end

  local function companionWeight(player, cell)
    local forward = Collision.DELTA[player.facing or "down"] or Collision.DELTA.down
    local dx, dy = cell.x - player.cellX, cell.y - player.cellY
    local facingOffset = dx * forward[1] + dy * forward[2]
    local weight = facingOffset < 0 and 7 or facingOffset == 0 and 3 or 1
    -- Adjacent positions read more like walking alongside the player than a
    -- follower continually tracing the edge of its allowed envelope.
    if math.abs(dx) + math.abs(dy) == 1 then weight = weight + 1 end
    return weight
  end

  local function weightedCandidateIndex(player, candidates)
    local total = 0
    for _, candidate in ipairs(candidates) do
      candidate.weight = companionWeight(player, candidate)
      total = total + candidate.weight
    end
    local roll = randomInt(1, total)
    for index, candidate in ipairs(candidates) do
      roll = roll - candidate.weight
      if roll <= 0 then return index end
    end
    return #candidates
  end

  local function chooseReachableGoal(game, ow, npc, minDistance, maxDistance)
    local candidates = nearbyCandidates(ow, npc, minDistance, maxDistance)
    if #candidates == 0 then return nil end
    local start = weightedCandidateIndex(ow.player, candidates)
    for offset = 0, #candidates - 1 do
      local candidate = candidates[((start + offset - 1) % #candidates) + 1]
      local direction = firstPathStep(game, ow, npc, candidate.x, candidate.y)
      if direction then return candidate.x, candidate.y, direction end
    end
    return nil
  end

  local function playerStepFrames(ow)
    return ow.player.stepFramesCur or ow.player.stepFrames or 16
  end

  local function playerMotionActive(ow)
    return ow.player.moving or ow.player.stepLanded
      or ow.player.targetX ~= nil or ow.player.targetY ~= nil
  end

  local function followerStepFrames(ow, slowExploration)
    local frames = playerStepFrames(ow)
    return slowExploration and not playerMotionActive(ow)
      and math.max(frames + 1, frames * 2) or frames
  end

  local function beginFreeStep(game, ow, npc, direction, slowExploration)
    if not canFreeStep(game, ow, npc, npc, direction) then return false end
    local delta = Collision.DELTA[direction]
    npc.facing = direction
    npc.targetX, npc.targetY = npc.cellX + delta[1], npc.cellY + delta[2]
    npc.hopStep = nil
    npc.stepFrames = followerStepFrames(ow, slowExploration)
    npc.moving, npc.progress = true, 0
    npc:update(ow.map, ow.entities)
    return true
  end

  local function tickFreeFollower(game, ow, npc)
    if npc.moving then return end
    local player = ow.player
    local distance = manhattan(npc.cellX, npc.cellY, player.cellX, player.cellY)
    local outside = not ow.map:inBounds(npc.cellX, npc.cellY)

    if outside then
      local candidates = nearbyCandidates(ow, npc, 1, 2)
      if #candidates > 0 then
        local cell = candidates[weightedCandidateIndex(player, candidates)]
        place(npc, cell.x, cell.y)
      end
      npc.hgssSimpleFree = nil
      return
    end

    if distance > EMERGENCY_DISTANCE then
      npc.hgssFarTicks = (npc.hgssFarTicks or 0) + 1
      if npc.hgssFarTicks > EMERGENCY_GRACE_TICKS then
        local candidates = nearbyCandidates(ow, npc, 1, 2)
        if #candidates > 0 then
          local cell = candidates[weightedCandidateIndex(player, candidates)]
          place(npc, cell.x, cell.y)
        end
        npc.hgssSimpleFree = nil
        return
      end
    else
      npc.hgssFarTicks = 0
    end

    local state = npc.hgssSimpleFree
    if not state then
      state = { wait = randomInt(FREE_INITIAL_PAUSE_MIN, FREE_INITIAL_PAUSE_MAX) }
      npc.hgssSimpleFree = state
    end

    local catchup = distance > FREE_CATCHUP_DISTANCE
    if catchup then
      state.goalX, state.goalY, state.wait = nil, nil, 0
      local gx, gy, direction = chooseReachableGoal(game, ow, npc, 1, 2)
      if direction then
        state.goalX, state.goalY = gx, gy
        state.catchup = true
        beginFreeStep(game, ow, npc, direction, false)
      end
      return
    end

    if state.goalX and (not legalFreeCell(ow, npc, state.goalX, state.goalY)) then
      state.goalX, state.goalY = nil, nil
      state.catchup = nil
    end
    if state.goalX and npc.cellX == state.goalX and npc.cellY == state.goalY then
      state.goalX, state.goalY = nil, nil
      state.wait = randomInt(FREE_PAUSE_MIN, FREE_PAUSE_MAX)
    end
    if not state.goalX then
      if state.wait > 0 then
        state.wait = state.wait - 1
        return
      end
      local gx, gy, direction = chooseReachableGoal(game, ow, npc, 1, 2)
      if not direction then
        state.wait = FREE_INITIAL_PAUSE_MIN
        return
      end
      state.goalX, state.goalY = gx, gy
      state.catchup = nil
      beginFreeStep(game, ow, npc, direction, true)
      return
    end
    local direction = firstPathStep(game, ow, npc, state.goalX, state.goalY)
    if not direction or not beginFreeStep(game, ow, npc, direction,
        not state.catchup) then
      state.goalX, state.goalY = nil, nil
      state.wait = FREE_INITIAL_PAUSE_MIN
    end
  end

  local function rememberFreeFormation(ow, npc)
    local playerX = ow.player.targetX or ow.player.cellX
    local playerY = ow.player.targetY or ow.player.cellY
    local followerX = npc.targetX or npc.cellX
    local followerY = npc.targetY or npc.cellY
    local dx, dy = followerX - playerX, followerY - playerY
    local distance = math.abs(dx) + math.abs(dy)
    if distance >= 1 and distance <= 2 then
      npc.hgssSimpleLastOffset = { x = dx, y = dy }
    end
  end

  local function tickBehindFollower(game, ow, npc, source)
    local player = ow.player
    source = source or player
    local trail = npc.hgssSimpleTrail
    if not trail then
      trail = { x = source.cellX, y = source.cellY }
      npc.hgssSimpleTrail = trail
    end

    local destX = source.targetX or source.cellX
    local destY = source.targetY or source.cellY
    if destX ~= trail.x or destY ~= trail.y then
      local direction = destY > trail.y and "down" or destY < trail.y and "up"
        or destX > trail.x and "right" or "left"
      if trail.ledgeHop == direction then
        trail.ledgeHop = nil
        trail.x, trail.y = destX, destY
      else
        trail.ledgeHop = ledgeStep(game, ow, trail.x, trail.y, direction)
          and direction or nil
        npc.goalX, npc.goalY = trail.x, trail.y
        trail.x, trail.y = destX, destY
      end
    end

    if npc.moving then return end
    if not npc.goalX then return end
    local gx, gy = npc.goalX, npc.goalY
    if npc.cellX == gx and npc.cellY == gy then
      npc.goalX, npc.goalY = nil, nil
      return
    end
    local far = manhattan(npc.cellX, npc.cellY, gx, gy)
    if far > EMERGENCY_DISTANCE then
      place(npc, gx, gy)
      return
    end

    local direction
    if npc.cellX < gx then direction = "right"
    elseif npc.cellX > gx then direction = "left"
    elseif npc.cellY < gy then direction = "down"
    else direction = "up" end
    npc.facing = direction
    local delta = Collision.DELTA[direction]
    npc.targetX = npc.cellX + delta[1]
    npc.targetY = npc.cellY + delta[2]
    npc.hopStep = nil
    if ledgeStep(game, ow, npc.cellX, npc.cellY, direction) then
      npc.targetX = npc.cellX + delta[1] * 2
      npc.targetY = npc.cellY + delta[2] * 2
      npc.goalX, npc.goalY = npc.targetX, npc.targetY
      npc.hopStep = true
    end
    npc.stepFrames = playerStepFrames(ow)
    npc.moving = true
    npc.progress = 0
    npc:update(ow.map, ow.entities)
  end

  local function tickFollower(game, ow)
    if not (game and game.save and ow and ow.map and ow.player) then return end
    if followerEnabled(game) then removeStockPikachu(ow) end

    local mons = activeMons(game)
    if #mons == 0 or hiddenByTravel(game, ow) then
      removeFollower(ow)
      return
    end

    local followers = findFollowers(ow)
    local rosterInvalid, byRank = false, {}
    for _, npc in ipairs(followers) do
      local rank = tonumber(npc.hgssFollowerRank)
      if not rank or byRank[rank] or not mons[rank]
          or npc.monKey ~= monKey(mons[rank]) then
        rosterInvalid = true
        break
      end
      byRank[rank] = npc
    end
    if rosterInvalid then
      ow.hgssSimplePendingOffsets = ow.hgssSimplePendingOffsets or {}
      for _, npc in ipairs(followers) do
        if npc.hgssSimpleLastOffset then
          ow.hgssSimplePendingOffsets[npc.monKey] = npc.hgssSimpleLastOffset
        end
      end
      removeFollower(ow)
      followers, byRank = {}, {}
    end
    for rank, mon in ipairs(mons) do
      if not byRank[rank] then
        local npc = makeFollower(game, ow, mon, rank)
        if npc then
          followers[#followers + 1] = npc
          byRank[rank] = npc
        else break end
      end
    end
    table.sort(followers, function(a, b)
      return (a.hgssFollowerRank or 99) < (b.hgssFollowerRank or 99)
    end)

    for _, npc in ipairs(followers) do
      local rank = npc.hgssFollowerRank
      local mon = mons[rank]
      if mon and (npc.monSpecies ~= mon.species or npc.monShiny ~= isShiny(mon)) then
        npc.monSpecies = mon.species
        npc.monShiny = isShiny(mon)
        local species = assert(speciesKey(mon))
        npc.sprite = assert(OverworldSprite.new(mon, species, isShiny(mon)))
      end
    end

    if followStyle() == FOLLOW_FREE then
      ow.hgssSimpleTrail = nil
      ow.hgssSimpleFree = nil
      for _, npc in ipairs(followers) do
        npc.hgssSimpleTrail = nil
        tickFreeFollower(game, ow, npc)
        rememberFreeFormation(ow, npc)
      end
    else
      ow.hgssSimpleFree = nil
      for _, npc in ipairs(followers) do
        local rank = npc.hgssFollowerRank
        npc.hgssSimpleFree = nil
        tickBehindFollower(game, ow, npc, rank == 1 and ow.player
          or byRank[rank - 1] or ow.player)
      end
    end
  end

  local function displayName(game, mon)
    local def = game.data and game.data.pokemon and game.data.pokemon[mon.species]
    return mon.nickname or (def and def.name) or mon.species
  end

  local function followerMon(game, npc)
    for _, mon in ipairs(game.save and game.save.party or {}) do
      if monKey(mon) == npc.monKey then return mon end
    end
    return nil
  end

  local function showMessage(game, format, mon)
    if not (game and game.stack and TextBox and TextBox.new) then return end
    game.stack:push(TextBox.new(game, Strings(format, displayName(game, mon))))
  end

  local FOLLOWER_FLAVOR = {
    "%s is looking\naround.",
    "%s is watching\nyou closely.",
    "%s seems eager to\nkeep exploring.",
    "%s is sniffing\nthe air.",
    "%s looks pleased\nto be with you.",
    "%s is taking in\nthe surroundings.",
  }
  local CITY_FLAVOR = {
    "%s is curious\nabout this city.",
    "%s watches the\ntown bustle.",
    "%s seems excited\nby all the people.",
    "%s is studying\nevery street.",
  }

  local function interactWithFollower(game, ow, npc, mon)
    pcall(Sound.playCry, game.data, mon.species)
    local mapId = tostring(ow.map and ow.map.id or ""):upper()
    local pool = (mapId:find("CITY", 1, true) or mapId:find("TOWN", 1, true))
      and CITY_FLAVOR or FOLLOWER_FLAVOR
    showMessage(game, pool[randomInt(1, #pool)], mon)
  end

  -- Remove legacy Wilds/Followers menu rows from the composed list, then add
  -- this mod's single unambiguous action. Wild spawning itself is untouched.
  if mod.hooks and mod.hooks.wrap then
    mod.hooks:wrap("ui.party.submenu", function(next, game, items, mon, ctx)
      local out = next(game, items, mon, ctx)
      if type(out) ~= "table" or (ctx and ctx.battle) then return out end
      local cleaned = {}
      for _, row in ipairs(out) do
        local label = type(row) == "table" and tostring(row.label or ""):upper() or ""
        if label ~= "FOLLOWER" and label ~= "FOLLOWING" and label ~= "LEADER"
          and label ~= "FOLLOW" and label ~= "STOP FOLLOWING" then
          cleaned[#cleaned + 1] = row
        end
      end
      if not healthy(mon) then return cleaned end

      local current = activeMon(game)
      local isCurrent = current == mon
      cleaned[#cleaned + 1] = {
        label = Strings(isCurrent and "STOP FOLLOWING" or "FOLLOW"),
        onSelect = function(selected, selectedGame)
          if isCurrent then
            local state = saveState(selectedGame)
            state.enabled = false
            removeFollower(selectedGame.overworld)
            showMessage(selectedGame, "%s stopped\nfollowing you.", selected)
          elseif selectMon(selectedGame, selected) then
            removeFollower(selectedGame.overworld)
            tickFollower(selectedGame, selectedGame.overworld)
            pcall(Sound.play, selectedGame.data, "Swap")
            showMessage(selectedGame, "%s is now\nfollowing you!", selected)
          end
        end,
      }
      return cleaned
    end)
  end

  -- Install after lower-priority world owners (including Wilds), preserving
  -- their update behavior and adding only this entity at the end of the tick.
  local previous = rawget(OverworldState, "_hgssSimpleFollowerState")
  if previous and type(previous.restore) == "function" then pcall(previous.restore) end
  local originalUpdate = OverworldState.update
  local updateWrapper
  updateWrapper = function(self, dt, ...)
    local result = originalUpdate(self, dt, ...)
    local ok, err = pcall(tickFollower, Game, self)
    if not ok and mod.log then mod.log:error("Follower update failed: %s", tostring(err)) end
    return result
  end
  OverworldState.update = updateWrapper

  -- map.entered fires in the middle of a seamless connection, before the
  -- engine moves the player back into the seam-walk start cell. Spawn only
  -- after crossConnection finishes that rebase so the follower is calculated
  -- from the live player position rather than the intermediate landing cell.
  local originalCrossConnection = OverworldState.crossConnection
  local crossConnectionWrapper
  if type(originalCrossConnection) == "function" then
    crossConnectionWrapper = function(self, ...)
      local result = originalCrossConnection(self, ...)
      if result then
        local ok, err = pcall(tickFollower, Game, self)
        if not ok and mod.log then
          mod.log:error("Follower connection sync failed: %s", tostring(err))
        end
      end
      return result
    end
    OverworldState.crossConnection = crossConnectionWrapper
  end

  -- The synthetic follower owns a small self-contained interaction instead of
  -- asking the map-text system to resolve a text id that does not exist.
  local originalInteract = OverworldState.interact
  local interactWrapper
  interactWrapper = function(self, ...)
    local p = self.player
    if p then
      local x, y = p:facingCell()
      local npc = self:npcAtCell(x, y)
      if npc and npc.hgssSimpleFollower then
        local mon = followerMon(Game, npc)
        if mon then interactWithFollower(Game, self, npc, mon) end
        return
      end
    end
    return originalInteract(self, ...)
  end
  OverworldState.interact = interactWrapper

  -- Dramatic Shape: a real 32x32 centered card instead of its stock 16x16
  -- billboard. This changes visual geometry only, never collision or maps.
  local voxelInstalls = {}
  local function installVoxelRenderer(modId)
    local renderer = type(mod.find) == "function" and mod:find(modId)
    local lib = renderer and renderer.exports and renderer.exports.lib
    if not lib and Game and Game.mods and Game.mods.exports
        and Game.mods.exports[modId] then
      lib = Game.mods.exports[modId].lib
    end
    if not (lib and lib.require) then return false end
    local SB = lib.require("SpriteBillboards")
    local Voxel3D = lib.require("Voxel3D")
    if not (SB and Voxel3D) then return false end
    local installed = voxelInstalls[SB]
    if installed and SB.mesh == installed.mesh then return true end
    local originalMesh, originalShadow = SB.mesh, SB.shadowQuad
    local cache = {}

    local function build(def, frame)
      local image = Assets.image(def.image)
      local iw, ih = image:getDimensions()
      -- UVs are normalized against the 16x96 proxy. resolveImage() replaces
      -- that proxy with the native 32x192 texture at draw time.
      local fy = math.max(0, math.min(5, math.floor(tonumber(frame) or 0))) * 16
      local vertices = {
        { -8, 0, 0, 0.05 / iw, (fy + 15.95) / ih, 1 },
        { 24, 0, 0, 15.95 / iw, (fy + 15.95) / ih, 1 },
        { 24, 32, 0, 15.95 / iw, (fy + 0.05) / ih, 1 },
        { -8, 32, 0, 0.05 / iw, (fy + 0.05) / ih, 1 },
      }
      local indices = {}
      Voxel3D.pushQuad(indices, 0)
      return Voxel3D.newMesh(vertices, indices)
    end

    local function customMesh(nextMesh, def, frame)
      if not (def and (def.id == SPRITE_ID or def.id == PROVIDER_SPRITE_ID
          or def.hgssSimpleFollower or def.hgssOverworldSprite)) then
        return nextMesh(def, frame)
      end
      local key = tostring(def.image) .. "#" .. tostring(frame or 0)
      if cache[key] == nil then
        local ok, mesh = pcall(build, def, frame)
        cache[key] = ok and mesh or false
      end
      return cache[key] or nextMesh(def, frame)
    end

    local meshWrapper = function(def, frame) return customMesh(originalMesh, def, frame) end
    local shadowWrapper = function(def, frame) return customMesh(originalShadow, def, frame) end
    SB.mesh = meshWrapper
    SB.shadowQuad = shadowWrapper
    SB._hgssSimpleFollowerMesh = meshWrapper
    voxelInstalls[SB] = {
      mesh = meshWrapper,
      restore = function()
      if SB.mesh == meshWrapper then SB.mesh = originalMesh end
      if SB.shadowQuad == shadowWrapper then SB.shadowQuad = originalShadow end
      if SB._hgssSimpleFollowerMesh == meshWrapper then SB._hgssSimpleFollowerMesh = nil end
      cache = {}
      end,
    }
    return true
  end

  local function installVoxelRenderers()
    local any = false
    for _, id in ipairs({ "DRAMATIC_SHAPE", "BATTLE_ART_VOXEL_FORK" }) do
      local ok, installed = pcall(installVoxelRenderer, id)
      if ok and installed then any = true end
    end
    return any
  end
  pcall(installVoxelRenderers)

  if mod.events and mod.events.on then
    mod.events:on("mods.loaded", function() pcall(installVoxelRenderers) end)
    mod.events:on("game.ready", function()
      if Game and Game.overworld then
        Game.overworld.hgssSimplePendingOffsets = nil
        removeFollower(Game.overworld)
        pcall(installVoxelRenderers)
        pcall(tickFollower, Game, Game.overworld)
      end
    end)
    mod.events:on("map.entered", function(payload)
      if Game and Game.overworld then
        local ow = Game.overworld
        ow.hgssSimplePendingOffsets = {}
        if followStyle() == FOLLOW_FREE then
          for _, npc in ipairs(findFollowers(ow)) do
            local offset = npc.hgssSimpleLastOffset
            if offset then
              ow.hgssSimplePendingOffsets[npc.monKey] = { x = offset.x, y = offset.y }
            end
          end
        end
        removeFollower(ow)
        pcall(installVoxelRenderers)
        if not (payload and payload.via == "connection") then
          pcall(tickFollower, Game, ow)
        end
      end
    end)
    mod.events:on("battle.ended", function()
      if Game and Game.overworld then pcall(tickFollower, Game, Game.overworld) end
    end)
    mod.events:on("mod.options_changed", function(payload)
      if not (payload and payload.mod == mod.id
          and (payload.key == "follow_style" or payload.key == "follower_count")) then
        return
      end
      local ow = Game and Game.overworld
      if ow then
        for _, npc in ipairs(findFollowers(ow)) do
          place(npc, npc.cellX, npc.cellY)
          npc.hgssSimpleTrail = nil
          npc.hgssSimpleFree = nil
          npc.hgssSimpleLastOffset = nil
        end
        ow.hgssSimpleTrail = nil
        ow.hgssSimpleFree = nil
        ow.hgssSimplePendingOffsets = nil
      end
    end)
  end

  local runtimeState = {}
  runtimeState.restore = function()
    if OverworldState.update == updateWrapper then OverworldState.update = originalUpdate end
    if crossConnectionWrapper and OverworldState.crossConnection == crossConnectionWrapper then
      OverworldState.crossConnection = originalCrossConnection
    end
    if OverworldState.interact == interactWrapper then OverworldState.interact = originalInteract end
    for _, installed in pairs(voxelInstalls) do
      if installed.restore then pcall(installed.restore) end
    end
    voxelInstalls = {}
    if rawget(OverworldState, "_hgssSimpleFollowerState") == runtimeState then
      rawset(OverworldState, "_hgssSimpleFollowerState", nil)
    end
    if Game and Game.overworld then
      Game.overworld.hgssSimpleTrail = nil
      Game.overworld.hgssSimpleFree = nil
      Game.overworld.hgssSimplePendingOffsets = nil
    end
  end
  rawset(OverworldState, "_hgssSimpleFollowerState", runtimeState)

  mod.exports.activeMon = activeMon
  mod.exports.select = selectMon
  mod.exports.stop = function(game)
    local state = saveState(game)
    if state then state.enabled = false end
    removeFollower(game and game.overworld)
  end
  mod.exports.tick = tickFollower
  mod.exports.monKey = monKey
  mod.exports.spriteSize = 32
  mod.exports.overworldSpriteApiVersion = 1
  mod.exports.overworldSpriteDefinitionId = PROVIDER_SPRITE_ID
  mod.exports.createOverworldSprite = createOverworldSprite
  mod.exports.restore = runtimeState.restore

  if mod.log then
    mod.log:info("HGSS Simple Follower loaded (free-nearby movement and interactions)")
  end
end
